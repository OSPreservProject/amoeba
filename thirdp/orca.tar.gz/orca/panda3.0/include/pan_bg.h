/*
%(c) copyright 1995 by the Vrije Universiteit, Amsterdam, The Netherlands.
%For full copyright and restrictions on use see the file COPYRIGHT in the
%top level of the Panda distribution.
 */

#ifndef __PAN_BG_H__
#define __PAN_BG_H__

/*
Experimental. Please use the group module for group communication.
This group module provides a single group joined by all platforms.

This module depends upon:
\begin{itemize}
\item the system module
\item the system configuration
\end{itemize}
*/

#include "pan_sys.h"

/*
\section{Initialization and termination}
*/

void pan_bg_init(int *argc, char **argv);
/*
Initializes the group module.
*/

void pan_bg_finish(void);
/* 
Finishes all group communication. All platforms will have received all
messages after this call returns.
*/

void pan_bg_end(void);
/*
Terminates the group module. No ports may be registered when this call
is made.
*/

/*
\section{Ports}

{\em Ports} provide a destination to address messages. Each
higher-level module that uses the BG module registers a port. The
ports have to be registered in a total order on all platforms. A
server can register an asynchronous handler routine for a port it
registered.  Messages for this port will than be forwarded to the
corresponding handler routine. Another option is a blocking receive
call performed by the receiving thread.

Every message that will be sent or received gets a {\em ticket}
number. This ticket number is used in split-phase send and receive
operations.
*/

typedef int (*pan_bg_receive_f)(void *data, int size, int len);
/* 
Group receive handler type. The receive function gets as arguments a
pointer to the received data, the size of the data buffer, and the
actual length of the data received.

The receive function returns a boolean specifying whether the data
buffer is kept at the receive function level (1) or can be reused at
the group level (0). If the buffer is kept at the receive function
level, it must be released with pan\_free. An exception is the message
that will be received on the sending platform, which is the same as
the message that is sent. On the sending platform, the receive
function may only return 1.

The group guarantees that size - len $>=$ pan\_bg\_trailer().

{\bf IMPORTANT}: The upcall is not allowed to block on a condition
synchronization, only on short-term mutex synchronization
(lock/unlock).  */


int pan_bg_register_port(pan_bg_receive_f receive);
/*
Register a port at the bg layer. The port number can be used to
address servers. The receive function will handle the upcall
containing the message.
*/
 
void pan_bg_free_port(int port);
/*
Free this port.
*/

/* 
\section{Sending and Receiving}
*/

int pan_bg_trailer(void);
/* 
Returns the space that the sender has to reserve for a trailer after
the user data. The group layer uses this space to add information for
demultiplexing.  The data in the buffer where the trailer will be put
may not be accessed during a call to send. The original data in this
area is restored when the send call is finished.
*/
 
int pan_bg_send(int port, void *data, int len);
/* 
Sends a message to all destinations at port number {\em port}. This
function returns a {\em ticket}, which must be used to synchronize on
(see pan\_bg\_finish\_send). On the sending platform, an upcall is
made with as arguments the data pointer {\em data} and length {\em
len}.
*/

void pan_bg_finish_send(int ticket);
/* 
Wait for send to finish. A send is finished when it is locally
delivered. The ticket returned by pan\_bg\_send must be passed as
parameter. It is not allowed to use the ticket after this call.
*/

int pan_bg_poll_send(int ticket);
/* 
Poll whether send is finished. The ticket returned by pan\_bg\_send must
be passed as parameter. Returns 1 if ready, 0 otherwise. It is not
allowed to use the ticket if the poll returns 1.
*/

void pan_bg_async_send(int ticket);
/* 
Do not synchronize on ticket. The ticket returned by pan\_bg\_send
must be passed as parameter. It is not allowed to use the ticket after
this call. The user is responsible not to change the message data
until it is locally delivered.
*/

#endif /* \_\_PAN\_BG\_H\_\_ */

/*
%Local Variables:
%c-block-comments-indent-p: 5
%c-comment-leader: ""
%End:
*/
