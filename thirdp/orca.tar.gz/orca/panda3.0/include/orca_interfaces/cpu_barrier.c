#include <interface.h>

extern void pan_barrier(void);

void
f_CpuBarrier__sync(void)
{
    pan_barrier();
}
