#include <interface.h>

extern void pan_stats_reset(void);

void
f_PandaStatistics__reset(void)
{
    pan_stats_reset();
}

void
f_PandaStatistics__print_reset(void)
{
    pan_stats_print_reset();
}

void
f_PandaStatistics__stop(void)
{
    pan_stats_stop();
}

void
f_PandaStatistics__start(void)
{
    pan_stats_start();
}
