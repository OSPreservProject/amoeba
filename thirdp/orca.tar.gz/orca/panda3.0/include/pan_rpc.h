/*
%(c) copyright 1995 by the Vrije Universiteit, Amsterdam, The Netherlands.
%For full copyright and restrictions on use see the file COPYRIGHT in the
%top level of the Panda distribution.
 */

#ifndef __PANDA_RPC_H__
#define __PANDA_RPC_H__

/*
The RPC module provides reliable RPC with at-most-once semantics.

This module depends upon:
\begin{itemize}
\item the system module
\item the message passing module
\end{itemize}
*/

#include "pan_sys.h"
#include "pan_mp.h"

typedef int (*pan_rpc_handler_f)(int ticket, void *request, int size, int len);
/* 
RPC request handler type. The receive function gets as arguments a
ticket for the reply message, a pointer to the request data, the size
of the request data buffer, and the length of the request data.

The request handler function returns a boolean specifying whether the
data buffer is kept at the handler function level (1) or can be reused
at the RPC level (0). If the buffer is kept at the handler function
level, it must be released with pan\_free.

The RPC layer guarantees that size - len $>=$
MAX(pan\_rpc\_request\_trailer(), pan\_rpc\_reply\_trailer())

{\bf IMPORTANT}: The upcall is not allowed to block on a condition
synchronization, only on short-term mutex synchronization
(lock/unlock). Furthermore, multiple instances of the upcall can be
active at the same time.
*/


void pan_rpc_init(int *argc, char *argv[]);
/*
Initializes the RPC module.
*/

void pan_rpc_end(void);
/*
Releases all resources held by the RPC module.
*/

void pan_rpc_register(pan_rpc_handler_f handler);
/* 
Registers the request handler function. The registration must be
performed before pan\_start is called.
*/

int pan_rpc_request_trailer(void);
/* 
Returns the space that the sender has to reserve for a trailer after
the user request data. The data in the buffer where the trailer will
be put may not be accessed during a call to pan\_rpc\_trans. The
original data in this area is restored when the pan\_rpc\_trans call is
finished.
*/

int pan_rpc_reply_trailer(void);
/* 
Returns the space that the sender has to reserve for a trailer after
the user reply data. The data in the buffer where the trailer will be
put may not be accessed during a call to pan\_rpc\_reply. The original
data in this area is restored when the pan\_rpc\_reply call is finished.
*/

void pan_rpc_trans(int dest, void *request, int req_len,
		   void **reply, int *rep_size, int *rep_len);
/* 
Sends request message request with length req\_len to destination
dest. The call blocks until a reply is received. The reply message
will be put in reply, with reply buffer size rep\_size and reply length
rep\_len. The reply has to be released with pan\_free.
*/

void pan_rpc_reply(int ticket, void *reply, int len);
/* 
Sends a reply message to the originator of the request message with
ticket ticket. The reply message will be cleared with pan\_free.
*/

#endif /* \_\_PANDA\_RPC\_H\_\_ */


/*
%Local Variables:
%c-block-comments-indent-p: 5
%c-comment-leader: ""
%End:
*/
