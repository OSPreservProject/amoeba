#ifndef __PAN_CLUSTER_H__
#define __PAN_CLUSTER_H__

/*
 * If the panda architecture is a cluster machine, these functions describe
 * the cluster lay-out.
 */

int pan_cluster_nr(void);
/* The number of clusters */

int pan_cluster_of(int cpu);
/* The cluster cpu {\em cpu} belongs to. */

int pan_cluster_coordinator(int cluster);
/* The coordinator of cluster {\em cluster} */

void pan_cluster_migrate_seq(int new_server);
/* Migrate the sequencer to the cluster of {\em new\_server} */


#endif
