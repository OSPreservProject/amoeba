/*
%(c) copyright 1995 by the Vrije Universiteit, Amsterdam, The Netherlands.
%For full copyright and restrictions on use see the file COPYRIGHT in the
%top level of the Panda distribution.
 */

#ifndef __PAN_MODULE_H__
#define __PAN_MODULE_H__

/*
System configuration parameters are passed as compile-time
flags. These compile-time flags are defined in {\tt pan\_conf.h} that
corresponds to the library that contains the system layer. This header
file can be found in the same directory as the library.
*/

#include "pan_conf.h"

/*
Panda defines the following flags:
\begin{description}
\item[PAN\_UNICAST\_PACKET/PAN\_MULTICAST\_PACKET]
If defined, it gives the maximum unicast/multicast packet size that
the system layer primitives can send/receive. If not defined, the
system layer does not impose a limit on the packet size.

\item[PAN\_UNICAST\_RELIABLE]
Defined if unicast is reliable.

\item[PAN\_UNICAST\_FIFO]
Defined if 2 unicasts from the same platform are always received in
the order in which they were sent.

\item[PAN\_MULTICAST\_RELIABLE]
Defined if multicast is reliable.

\item[PAN\_MULTICAST\_FIFO]
Defined if 2 unicasts from the same platform are always received in
the order in which they were sent.

\item[PAN\_MULTICAST\_TOTAL]
Defined if all multicasts in the system are always received in the same 
order on all platforms. This does not have to imply PAN\_MULTICAST\_FIFO.

\item[PAN\_POLL]
Defined if the system layer needs calls to pan\_poll to function
correctly.
\end{description}
*/


#ifdef MIN
#undef MIN
#endif
#define MIN(x, y) ((x) < (y) ? (x) : (y))

#ifdef MAX
#undef MAX
#endif
#define MAX(x, y) ((x) > (y) ? (x) : (y))

/* 
\section{Constants}
*/
#ifdef PAN_UNICAST_PACKET 
#ifdef PAN_MULTICAST_PACKET
#define PAN_PACKET_SIZE MIN(PAN_UNICAST_PACKET, PAN_MULTICAST_PACKET)
#else
#define PAN_PACKET_SIZE PAN_UNICAST_PACKET
#endif
#else  /* !PAN\_UNICAST\_PACKET */
#ifdef PAN_MULTICAST_PACKET
#define PAN_PACKET_SIZE PAN_MULTICAST_PACKET
#endif
#endif /* PAN\_UNICAST\_PACKET */



#endif /* \_\_PAN\_MODULE\_H\_\_ */
