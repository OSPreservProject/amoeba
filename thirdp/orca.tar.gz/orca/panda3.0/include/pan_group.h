/*
%(c) copyright 1995 by the Vrije Universiteit, Amsterdam, The Netherlands.
%For full copyright and restrictions on use see the file COPYRIGHT in the
%top level of the Panda distribution.
*/

#ifndef __PANDA_GROUP_H__
#define __PANDA_GROUP_H__

/*
   The group module provides reliable, totally ordered group
   communication with one static group. All hosts become member of the group
   upon startup after the call to pan\_group\_init; the group is left on
   shut-down from the call to pan\_group\_end.

   This module depends upon:
   \begin{itemize}
   \item the system module
   \item the system configuration
   \end{itemize}
*/

#include "pan_sys.h"


void pan_group_init(int *argc, char *argv[]);
/*
    Start the group.
*/

void pan_group_end(void);
/*
    Finish the group.
*/

int pan_group_trailer(void);
/*
    Returns the space that the sender must reserve for a trailer after the
    user data in each message. The group layer uses this space for internal
    information exchange.
*/

int pan_group_register_port(int (*receive)(void *data, int size, int len));
/*
   Register a port with corresponding receiver function. Messages sent to the
   port number returned by this call will be handled
   through subsequent calls of {\em receive}. Message handling for the group is
   single-threaded and totally ordered.
   The receive function returns a boolean specifying whether the data buffer is
   kept at the receive function level (1) or can be reused at the system level
   (0). If the buffer is kept at the receive function level, it must be
   released with pan\_free.
   The message is also delivered at home in the total order. A home message
   is a pointer to the sent message, not a copy. A sent message cannot be
   be touched before it has been delivered via the receive path.
   All ports must be registered before the call to pan\_start. All ports
   must be registered by all members in the same order.
*/

void pan_group_send(int port, void *data, int len);
/*
   Sends message {\em data} to port {\em port} of the group. Messages sent by
   pan\_group\_send will be delivered in total order to all members.
   The message is delivered at home as a pointer to the message sent.
   Only after delivery, it can be reused or cleared.
*/


#endif /* \_\_PANDA\_GROUP\_H\_\_ */

/*
%Local Variables:
%c-block-comments-indent-p: 5
%c-comment-leader: ""
%End:
*/
