/*
%(c) copyright 1995 by the Vrije Universiteit, Amsterdam, The Netherlands.
%For full copyright and restrictions on use see the file COPYRIGHT in the
%top level of the Panda distribution.
 */

#ifndef __PAN_CC_H__
#define __PAN_CC_H__

#include "pan_sys.h"
#include <limits.h>

#define MAX_PROCS        ( 64)

#define WORD_BITS   (sizeof(unsigned) * CHAR_BIT)
#define PROC_WORDS  ((MAX_PROCS - 1) / WORD_BITS + 1)

#define PAN_CC_MAX_STATE (6 * sizeof(int))

typedef struct pan_cc_sched *pan_cc_sched_p;

/* Initialization and termination */
void pan_cc_init(int *argc, char **argv);
void pan_cc_finish(void);
void pan_cc_end(void);

/* Data descriptors */
typedef struct pan_cc_data *pan_cc_data_p;

typedef unsigned int pan_cc_set_t[PROC_WORDS];

typedef int  (*pan_cc_presend_f)(pan_cc_data_p data, void *state);
typedef void (*pan_cc_send_f)(void *buf, pan_cc_data_p data, void *state);
typedef void (*pan_cc_recv_f)(void *buf, int len, 
			      pan_cc_data_p data, void *state);

typedef char pan_cc_state_t[PAN_CC_MAX_STATE];
typedef struct pan_cc_default {
    void *ptr;
    int   len;
} pan_cc_default_t, *pan_cc_default_p;

typedef struct pan_cc_data {
    pan_cc_presend_f    send_prepare;
    pan_cc_send_f       send_func;
    pan_cc_recv_f       recv_func;
    pan_cc_state_t      state;
} pan_cc_data_t;

/* Schedule creation */
typedef void (*pan_cc_comp_f)(void *state);

extern pan_cc_set_t pan_cc_all;
extern pan_cc_set_t pan_cc_me;

pan_cc_sched_p pan_cc_sched_create(pan_cc_set_t procset);
void           pan_cc_sched_destroy(pan_cc_sched_p sched);

int  pan_cc_sched_send(pan_cc_sched_p sched, int pid, int data);
void pan_cc_sched_receive(pan_cc_sched_p sched, int pid, int sid);
void pan_cc_sched_compute(pan_cc_sched_p sched, int pid, pan_cc_comp_f comp);

void pan_cc_sched_finish(pan_cc_sched_p sched, int compress);

void pan_cc_sched_exec(pan_cc_sched_p sched, pan_cc_data_t data[],
		       void *state);
void pan_cc_sched_dump(pan_cc_sched_p sched);

/* Default MPI operations */
typedef void (*pan_cc_op)(void *d1, void *d2, int size);

void pan_cc_barrier(void);
void pan_cc_bcast(void *buffer, int count, int root);
void pan_cc_gather(void *sendbuf, int sendcount, 
		   void *recvbuf, int recvcount, int root);
void pan_cc_gatherv(void *sendbuf, int sendcount, 
		    void *recvbuf, int *recvcounts, int *displs, int root);
void pan_cc_scatter(void *sendbuf, int sendcount, 
		    void *recvbuf, int recvcount, int root);
void pan_cc_scatterv(void *sendbuf, int *sendcounts, int *displs,
		     void *recvbuf, int recvcount, int root);
void pan_cc_allgather(void *sendbuf, int sendcount, 
		      void *recvbuf, int recvcount);
void pan_cc_allgatherv(void *sendbuf, int sendcount, 
		       void *recvbuf, int *recvcounts, int *displs);
void pan_cc_alltoall(void *sendbuf, int sendcount, 
		      void *recvbuf, int recvcount);
void pan_cc_alltoallv(void *sendbuf, int *sendcounts, int *sdispls,
		      void *recvbuf, int *recvcounts, int *rdispls);
void pan_cc_reduce(void *sendbuf, void *recvbuf, int count, 
		   pan_cc_op op, int root);
void pan_cc_allreduce(void *sendbuf, void *recvbuf, int count, 
		      pan_cc_op op);
void pan_cc_reduce_scatter(void *sendbuf, void *recvbuf, int *recvcounts,
			   pan_cc_op op);
void pan_cc_scan(void *sendbuf, void *recvbuf, int count, pan_cc_op op);


/* LogP schedule generation utilities */

typedef struct pan_cc_reduce_tree {
    unsigned int dest;
} pan_cc_reduce_tree_t;

typedef struct pan_cc_gather_tree {
    unsigned int dest;
    unsigned int len;
} pan_cc_gather_tree_t;

void pan_cc_logp_sync(pan_cc_sched_p sched, pan_cc_set_t set, int data);
void pan_cc_logp_reduce(pan_cc_reduce_tree_t tree[], int P, int size);
void pan_cc_logp_gather(pan_cc_gather_tree_t tree[], int P, int size);


#endif /* __PAN_CC_H__ */
