/*
%(c) copyright 1995 by the Vrije Universiteit, Amsterdam, The Netherlands.
%For full copyright and restrictions on use see the file COPYRIGHT in the
%top level of the Panda distribution.
*/

#ifndef __PANDA_SYSTEM_LAYER__
#define __PANDA_SYSTEM_LAYER__


/* 
This header file defines the Panda system layer interface, that puts
an abstract layer on top of an existing operating system. The
implementation of the system layer must provide the functions
presented here WITHOUT MODIFYING THIS FILE!!! This way it is
guaranteed that all implementations on top of it are architecture
independent.

To allow Panda to be both portable and efficient, it is important that
the Panda modules make best use of the primitived provided by the
underlying platform (i.e., the operating system and
hardware). Therefore, the semantics of the operations defined in the
system layer are not fixed, but depend on what the underlying system
provides. Panda distinguishes three important areas in which these
systems differ:

\begin{itemize} 
\item The low-level communication primitives may either be reliable or
unreliable.
\item The underlying system may provide message ordering guarantees.
\item Some systems support arbitrarily-sized messages, but others
impose an upper bound on message size (so fragmentation and reassembly
are required for larger messages).
\end{itemize}
The semantics of a particular implementation of a system layer are
stored in {\em pan_conf.h}, which is located together in the same
directory as the Panda library. This include file is included in {\em
pan_module.h}, which must be included by all Panda modules that want
to exploit system properties.

Naming convention: All names that are externally visible have to be
prefixed with '{\em pan}'. The names that are supposed not to be used
by the higher layers start with '{\em pan\_sys\/}'. All modules
layered on top of the system module should have names like '{\em
pan\_xxx\_name}', where {\em xxx} is the unique name of the module.
*/

/* 
\section{Type Definitions} 

All Panda system interface type are pointers to structures. This allows an
implementation to provide its own types, without requiring these types to be
known to the upper layers. All types have there own {\em create} and 
{\em clear} routines.
*/


typedef struct pan_thread   *pan_thread_p;
typedef struct pan_time     *pan_time_p;
typedef struct pan_mutex    *pan_mutex_p;
typedef struct pan_cond     *pan_cond_p;
typedef struct pan_pset     *pan_pset_p;
typedef struct pan_sap      *pan_sap_p;
typedef struct pan_key      *pan_key_p;
typedef void               (*pan_thread_func_p)(void *arg);


/*
\section{System Interface} 

The system interface provides the basic functions to start and stop
the application, and to get information on the number of platforms and
the own platform identifier. It also provides a function to poll the
system layer for asynchronous events. This function is architecture
dependent, and should only be called when PAN\_POLL is defined.
*/

void pan_init(int *argc, char *argv[]); 
/*
Initializes the Panda layer and joins the platforms that run the same
application. The argument list must be passed directly from the main
function. After this call, the main function can parse its own
arguments. The arguments used by Panda are removed from the list.
*/

void pan_end(void);
/*
Releases all resources held by the system layer.
*/

void pan_start(void);
/*
Starts the receive daemon. Before this call is made, all network
service access points have to be initialized. After this call,
incoming messages will be handled.
*/

int pan_nr_platforms(void);
/*
Returns the number of platforms.
*/

int pan_my_pid(void);
/*
Returns the platform identification number for this platform. The
number will always be in the range of 0 up to pan\_nr\_platforms().
*/

void pan_poll(void);
/*
Allows the system layer to synchronously handle asynchronous events.
*/

/*
\section{Threads Interface} 

The threads interface provides a Cthreads/pthreads alike thread
interface.  A thread data type gets an thread of control with {\em
pan\_thread\_create}.
*/

pan_thread_p pan_thread_create(pan_thread_func_p func, void *arg, 
			       long stacksize, int priority, int detach, 
			       char *name);
/* 
Create a new thread, and start an execution which calls function {\em
func} with argument {\em arg}. The stack size and priority of the new
thread are set to {\em stacksize} and {\em priority}. A value of 0
denotes the default value for both the stack size. The default
stack size is architecture dependent. The {\em detach} argument
specifies whether a thread will be joined in the future or not. A 0
means that the user will join this thread; a 1 means that the thread
resources can be removed on exit. The character string {\em name} is
used for debugging and tracing.
*/

void pan_thread_clear(pan_thread_p thread);
/* 
Clear thread {\em thread}. This function may only be called after {\em
thread\/} is joined. Detached threads are cleared by the system layer
when they call pan\_thread\_exit.
*/

void pan_thread_exit(void);
/*
Terminates the current execution. This function must be called when a
thread exits from its main function.
*/

void pan_thread_join(pan_thread_p thread);
/*
Join the execution associated with {\em thread}. The call blocks until
the corresponding execution calls pan\_thread\_exit. The execution
associated with {\em thread\/} must have been started with {\em
detach\/} value 0.
*/

void pan_thread_yield(void);
/*
Tries to run another runnable thread with equal priority. The calling
thread will be halted and made runnable, so that it may be
rescheduled.
*/

pan_thread_p pan_thread_self(void);
/*
Returns the thread pointer of the calling thread.
*/

int pan_thread_getprio(void);
/*
Returns the priority of the calling thread.
*/

int pan_thread_setprio(int priority);
/*
Changes the priority of the calling thread to {\em priority}. It
returns the old priority of the thread. Higher values imply a higher
priority. 
*/

int pan_thread_minprio(void);
/*
Returns the minimum priority a thread may have.
*/

int pan_thread_maxprio(void);
/*
Returns the maximum priority a thread may have.
*/

/* 
\section{Time Interface} 

The time interface provides a common abstraction to the system time. A
user can only create a new absolute time by taking the current time and
adding a relative time to it.
*/

pan_time_p pan_time_create(void);
/*
Create a new time structure.
*/

void pan_time_clear(pan_time_p time);
/*
Clears time structure {\em time}.
*/

void pan_time_copy(pan_time_p to, pan_time_p from);
/*
Copy time value of {\em from} into {\em to}.
*/

void pan_time_get(pan_time_p now);
/*
Get the current time in time structure {\em time}.
*/

void pan_time_set(pan_time_p time, long seconds, unsigned long nanoseconds);
/*
Set time structure {\em time} to {\em seconds} seconds and {\em
nanoseconds} nanoseconds.
*/

int pan_time_cmp(pan_time_p t1, pan_time_p t2);
/*
Compares time structures {\em t1} and {\em t2}. Returns -1 if {\em
t1\/} $<$ {\em t2\/}, 1 if {\em t1\/} $>$ {\em t2\/}, and 0 if
{\em t1\/} $=$ {\em t2\/}.
*/

void pan_time_add(pan_time_p res, pan_time_p delta);
/*
Add time {\em delta} to {\em res}.
*/

void pan_time_sub(pan_time_p res, pan_time_p delta);
/*
Substract time {\em delta} from {\em res}.
*/

void pan_time_mul(pan_time_p res, int nr);
/*
Multiply time {\em res} by {\em nr}.
*/

void pan_time_div(pan_time_p res, int nr);
/*
Divide time {\em res} by {\em nr}.
*/

void pan_time_mulf(pan_time_p res, double nr);
/*
Multiply time {\em res} by {\em nr}.
*/


void pan_time_d2t(pan_time_p t, double d);
/*
Convert {\em double d} (in seconds) to {\em pan\_time\_p t}.
*/

double pan_time_t2d(pan_time_p t);
/*
Convert {\em pan\_time\_p t} to seconds.
*/

int  pan_time_delta(pan_time_p t1, pan_time_p t2, long *d);
/* 
Subtract two opaque time values, and if the absolute difference is is
less than one second, store the difference in nanoseconds in {\em d}
and return 1. Otherwise, return 0.
*/

void pan_time_delay(double microsec);

extern pan_time_p pan_time_infinity;
extern pan_time_p pan_time_zero;
/*
t = $\inf$ and t = 0, respectively
*/

int pan_time_size(void);
/*
Returns the size of a marshalled time.
*/
 
void pan_time_marshall(pan_time_p p, void *buffer);
/*
Marshalls time {\em p} in {\em buffer}. {\em buffer} should
be at least {\em pan\_time\_size bytes}.
*/
 
void pan_time_unmarshall(pan_time_p p, void *buffer);
/*
Unmarshalls {\em buffer} to time {\em p}.
*/


/* 
\section{Monitor Interface} 

Panda provides mutexes for critical region synchronization. The usage of
mutexes is strictly limited to critical sections, because the semantics
of message handling depends on this behavior. For long-term synchronization,
Panda provides an interface to condition variables. Note that in contrary
to the pthreads interface, Panda strictly associates a lock with a
condition variable when it is created.
*/

pan_mutex_p pan_mutex_create(void);
/*
Create a new mutex.
*/

void pan_mutex_clear(pan_mutex_p mutex);
/*
Clear mutex {\em mutex}.
*/

void pan_mutex_lock(pan_mutex_p mutex);
/*
Tries to lock {\em mutex} and blocks until it succeeds. Acquiring a
lock twice before releasing it by the same thread may result in a
deadlock.
*/

void pan_mutex_unlock(pan_mutex_p mutex);
/*
Unlocks {\em mutex}, and gives other threads the opportunity to lock
it.
*/

int pan_mutex_trylock(pan_mutex_p mutex);
/*
Tries to lock {\em mutex}. It returns 1 if it succeeds, 0 if {\em
mutex} is already locked.
*/

pan_cond_p pan_cond_create(pan_mutex_p mutex);
/*
Create a new condition variable associated with {\em mutex\/}.
*/

void pan_cond_clear(pan_cond_p cond);
/*
Clear condition variable {\em cond}.
*/

void pan_cond_wait(pan_cond_p cond);
/*
Blocks on condition variable {\em cond}. It atomically unlocks the
associated mutex, which should have been locked by the calling thread.
After being signaled, {\em mutex} is locked again by the calling
thread, and the calling thread is unblocked.
*/

int pan_cond_timedwait(pan_cond_p cond, pan_time_p abstime);
/*
Blocks on condition variable {\em cond}. It atomically unlocks the
associated mutex, which should have been locked by the calling thread.
After being signaled or after absolute time has passed {\em abstime},
{\em mutex} is locked again by the calling thread, and the calling
thread is unblocked. On being signaled, pan\_cond\_timedwait returns
1, on timeout it returns 0. It is not allowed to update {\em abstime} 
during this call.
*/

void pan_cond_signal(pan_cond_p cond);
/*
Unblocks at least one of the threads that are blocked on {\em cond}.
If no threads are blocked on {\em cond} nothing happens. The
associated mutex must be locked.
*/

void pan_cond_broadcast(pan_cond_p cond);
/*
Like pan\_cond\_signal, except that it unblocks all threads that are
blocked on {\em cond}. The associated mutex must be locked.
*/



/*
\section{Platform Set Interface} 

Platform sets are used to address multiple platforms for multicast
operations.
*/

pan_pset_p pan_pset_create(void);
/*
Create a new platform set.
*/

void pan_pset_clear(pan_pset_p pset);
/*
Clear platform set {\em pset}.
*/

int pan_pset_isempty(pan_pset_p pset);
/*
Returns 1 if platform set {\em pset} is empty, 0 otherwise.
*/

void pan_pset_add(pan_pset_p pset, int pid);
/*
Add platform {\em pid} to platform set {\em pset}.
*/

void pan_pset_del(pan_pset_p pset, int pid);
/*
Delete platform {\em pid} from platform set {\em pset}.
*/

void pan_pset_fill(pan_pset_p pset);
/*
Changes platform set {\em pset} to a platform set that contains all
platforms (0 up to pan\_nr\_platforms()).
*/

int pan_pset_find(pan_pset_p pset, int pid_offset);
/*
Return the first platform identifier in {\em pset\/}, starting from
platform identifier {\em pid\_offset\/}. If no platform identfier is
found, -1 is returned.
*/

void pan_pset_empty(pan_pset_p pset);
/*
Changes platform set {\em pset} to a platform set that contains none
of the platforms.
*/

void pan_pset_copy(pan_pset_p pset, pan_pset_p copy);
/*
Makes a copy of platform set {\em pset} in platform set {\em copy}.
*/

int pan_pset_ismember(pan_pset_p pset, int pid);
/*
Returns 1 if platform {\em pid} is in platform set {\em pset}, 0
otherwise.
*/

int pan_pset_size(void);
/*
Returns the size of a marshalled platform set.
*/

void pan_pset_marshall(pan_pset_p pset, void *buffer);
/*
Marshalls platform set {\em pset} in {\em buffer}. {\em buffer} should
be at least {\em pan\_pset\_size bytes}.
*/

void pan_pset_unmarshall(pan_pset_p pset, void *buffer);
/*
Unmarshalls {\em buffer} to platform set {\em pset}.
*/

int pan_pset_nr_members(pan_pset_p pset);
/*
Returns the number of members of platform set {\em pset}
*/

/*
\section{Network Service Access Point Interface} 

To allow multiple higher-level communication modules to be added,
Panda uses a two level naming scheme. The first level is the platform
identifier (or platform set for multicast operations), which specifies
the destination platform(s). The second level is the network service
access point, which identifies the service a fragment is destinated
for. Every higher-level module that does communication creates one or
more access points. To facilitate addressing, all network service
access points have to be acquired before {\em pan\_start} is called,
so all access points are acquired in the same order on all
platforms. The sap specifies the upcall function to be used.
*/

typedef int (*pan_receive_f)(void *data, int size, int len);
/*
Network service access point receive handler type. The receive function
gets as arguments a pointer to the received data, the size of
the data buffer, and the actual length of the data received. 

The receive function returns a boolean specifying whether the data
buffer is kept at the receive function level (1) or can be reused at
the system level (0). If the buffer is kept at the receive function
level, it must be released with pan\_free. An exception to this rule
is the local upcall in pan\_multicast. Since the data pointer passed
to pan_multicast is delivered, the receive handler function may only
return 1 on the sender side.

The system layer guarantees that size - len $>=$ pan\_sap\_trailer(sap). 

{\bf IMPORTANT}: The upcall is not allowed to block on a condition
synchronization, only on short-term mutex synchronization
(lock/unlock).  Furthermore, multiple instances of the upcall may be
active at the same time.  */

#define PAN_SAP_UNICAST   0x01
#define PAN_SAP_MULTICAST 0x02

pan_sap_p pan_sap_create(pan_receive_f receive, int flags);
/* 
Create a new network service access point. Data received on this sap
are handled with an upcall to {\em receive}. {\em flags\/} specifies
the type of communication {\em sap\/} is going to be used for
(PAN\_SAP\_UNICAST, PAN\_SAP\_MULTICAST).
*/

void pan_sap_clear(pan_sap_p sap);
/* 
Clear network service access point {\em sap}.
*/

int pan_sap_trailer(pan_sap_p sap);
/* 
Returns the space that the sender has to reserve for a trailer after
the user data. The system layer uses this space to add information for
demultiplexing and routing.  The data in the buffer where the trailer
will be put may not be accessed during a call to
unicast/multicast. The original data in this area is restored when the
send call returns.
*/

int pan_sap_id(pan_sap_p sap);
/* 
Return a globally unique identifier for sap. The identifiers are
numbered consecutively starting from 0.
*/

pan_sap_p pan_sap_locate(int id);
/* 
Return the sap with globally unique identifier id.
*/

/* 
\section{Communication Interface}

The communication interface provides a unicast and a multicast
version.  The primitives get as argument a pointer to a buffer. The
{\em len} specifies the length of the data in the message that has to
be sent.  Every buffer has to reserve some space for a trailer that
the system layer adds to the message (see pan\_sap\_trailer()).

If PAN\_UNICAST\_PACKET is defined, the system layer limits the length
of a unicast packet to this value. In that case, {\em len} is limited
to PAN\_UNICAST\_PACKET - pan\_sap\_trailer(). The same applies to
multicast.

{\bf IMPORTANT}:To avoid deadlock, it is not allowed to have locks
granted while performing a send call.
*/

void pan_unicast(int dest, pan_sap_p sap, void *data, int len);
/* 
Send data {\em data} of length {\em len} to destination {\em dest}. It
is illegal to send to the sending platform.  The data is sent to
network service access point {\em sap}.
*/

void pan_multicast(pan_pset_p pset, pan_sap_p sap, void *data, int len);
/* 
Send data {\em data} of length {\em len} to destinations specified in
platform set {\em pset\/}. The data is sent to the network service
access point {\em sap}. On the sending platform, an upcall is made
with as argument the data pointer {\em data} and length {\em
len}. This data may not be modified until it is delivered.
*/


/*
\section{Malloc Interface} 

Multithread safe versions of these routines should be provided by the
system layer. Furthermore, we provide Panda versions that check for
memory overflow.
*/

#include <stdlib.h>

void *pan_malloc(size_t size);
void *pan_calloc(size_t nelem, size_t elsize);
void *pan_realloc(void *ptr, size_t size);
void  pan_free(void *ptr);


/* 
\section{Glocal Memory Interface} 
*/

pan_key_p pan_key_create(void);
/*
Create a new glocal memory key
*/

void pan_key_clear(pan_key_p key);
/*
Clear glocal memory key {\em key}
*/

void pan_key_setspecific(pan_key_p key, void *ptr);
/*
Set the thread specific data of the current thread corresponding with
key {\em key} to {\em ptr}.
*/

void *pan_key_getspecific(pan_key_p key);
/*
Retrieve the thread specific data of the current thread corresponding
with key {\em key}.
*/


/*
\section{Debugging and tuning support}
*/

void pan_panic(const char *, ...);
/* 
Prints an error message and stops the system.
 */

/*
Print the arguments of {\em pan\_panic} as in a printf call, then halt
the panda program.
*/

#endif	/* \_\_PANDA\_SYSTEM\_LAYER\_\_ */

/*
%Local Variables:
%c-block-comments-indent-p: 5
%c-comment-leader: ""
%End:
*/
