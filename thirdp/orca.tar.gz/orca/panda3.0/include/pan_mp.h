/* 
%(c) copyright 1995 by the Vrije Universiteit, Amsterdam, The Netherlands.
%For full copyright and restrictions on use see the file COPYRIGHT in the
%top level of the Panda distribution.
*/

#ifndef __PAN_MP_H__
#define __PAN_MP_H__

/*
The message module provides reliable message passing.

This module depends upon:
\begin{itemize}
\item the system module 
\item the system configuration
\end{itemize}
*/


#include "pan_sys.h"

/* 
\section{Initialization and Termination}
*/

void pan_mp_init(int *argc, char *argv[]);
/*
Initializes the message passing module.
*/

void pan_mp_end(void);
/*
Releases all resources held by the message passing module. No ports
may be registered when this call is made.
*/

/*
\section{Ports}

{\em Ports} provide a destination to address messages. Each
higher-level module that uses the MP module registers a port. The
ports have to be registered in a total order on all platforms. A
server can register an asynchronous handler routine for a port it
registered.  Messages for this port will than be forwarded to the
corresponding handler routine. Another option is a blocking receive
call performed by the receiving thread.

Every message that will be sent or received gets a {\em ticket}
number. This ticket number is used in split-phase send and receive
operations.
*/

typedef int (*pan_mp_receive_f)(void *data, int size, int len);
/*
Message passing receive handler type. The receive function gets as
arguments a pointer to the received data, the size of the data buffer,
and the actual length of the data received.

The receive function returns a boolean specifying whether the data
buffer is kept at the receive function level (1) or can be reused at
the system level (0). If the buffer is kept at the receive function
level, it must be released with pan\_free.

The message passing layer guarantees that size - len $>=$
pan\_mp\_trailer(). 

{\bf IMPORTANT}: The upcall is not allowed to block on a condition
synchronization, only on short-term mutex synchronization
(lock/unlock). Furthermore, multiple instances of the upcall can be
active at the same time.
*/

int pan_mp_register_port(pan_mp_receive_f receive);
/*
Register a port at the MP layer. The port number can be used to
address servers. If {\em receive} is NULL, a receiving thread has to
call pan\_mp\_receive to get messages from this port. Otherwise, the
handler function will handle the upcall containing the message.
*/

void pan_mp_free_port(int port);
/*
Free this port. If some threads are blocked in a receive call on this
port, they get an upcall with a NULL data pointer.
*/

/* 
\section{Sending and Receiving}

The message passing interface provides reliable unicast primitves.
The primitives get as argument a pointer to a buffer. The {\em len}
specifies the length of the data in the message that has to be sent.
Every buffer has to reserve some space for a trailer that the message
passing layer adds to the message (see pan\_mp\_trailer()).
*/

int pan_mp_trailer(void);
/*
Returns the space that the sender has to reserve for a trailer after
the user data. The message passing layer uses this space to add
information for demultiplexing.  The data in the buffer where the
trailer will be put may not be accessed during a call to send. The
original data in this area is restored when the send call is finished.
*/

typedef enum {PAN_MP_NORMAL, PAN_MP_DELAYED, PAN_MP_EXTERNAL} pan_mp_ack_t;
/* 
Describes the kind of acknowledgement that is required for a send
operation. For the implementation on unreliable, this changes the
communication behavior.

PAN\_MP\_NORMAL:  Acknowledge message immediately
PAN\_MP\_DELAYED: Try to acknowledge message with next message sent from
                the receiver. After a timeout, a normal
                acknowledgement is sent.
PAN\_MP\_EXTERNAL:The message is acknowledged explicitly when the sender
                knows that the message must have arrived.
*/

int pan_mp_send(int cpu, int port, void *data, int len, pan_mp_ack_t ack);
/* 
Sends message data with length len to the given destination. A
destination consists of a platform id and a port number. This function
returns a {\em ticket}, which must be used to synchronize on (see
pan\_mp\_finish\_send or pan\_mp\_ack\_send).
*/

void pan_mp_async_send(int ticket, void (*upcall)(void *arg), void *arg);
/* 
Send message asynchronously. Upcall function upcall will be called
when the message is guaranteed to be delivered with arg as
argument. It is not allowed to make calls to finish\_send or poll\_send
with ticket as argument after this call.
*/

void pan_mp_finish_send(int ticket);
/* 
Wait for send to finish. The message may not have been sent with
PAN\_MP\_EXTERNAL. The ticket returned by pan\_mp\_send must be passed
as parameter. It is not allowed to use ticket after this call.
*/

int pan_mp_poll_send(int ticket);
/* 
Poll whether send is finished. The message may not have been sent with
PAN\_MP\_EXTERNAL. The ticket returned by pan\_mp\_message\_send must be
passed as parameter. Returns 1 if ready, 0 otherwise. After the poll
returns 1, ticket may not be used anymore.
*/

void pan_mp_ack_send(int ticket);
/* 
Acknowledge a send operation. The message must have been sent with
PAN\_MP\_EXTERNAL. The ticket returned by pan\_mp\_send must be passed as
parameter.
*/

#define PAN_MP_DIRECT_PORT  0

int pan_mp_receive(int port);
/* 
Receive a message. This function returns a {\em ticket} that must be
used to synchronize on (see pan\_mp\_finish\_receive). If a receive is
done on PAN\_MP\_DIRECT\_PORT, the ticket number serves as a one-time
pseudoport number, and can be passed to other machines to address this
receive call.
*/

void *pan_mp_finish_receive(int ticket, int *size, int *len);
/* 
Wait for receive to finish. The ticket returned by pan\_mp\_receive
must be passed as parameter. The function returns a message buffer
with size size and length len, which must be cleared by the caller
with pan\_free. If the port is freed during the call to
pan\_mp\_finish\_receive, a NULL message is returned.
*/

int pan_mp_poll_receive(int ticket);
/*
Poll whether receive is finished. The ticket returned by
pan\_mp\_receive must be passed as parameter. Returns 1 if ready, 0
otherwise.
*/

void pan_mp_expect(int pid);
/* 
Tell the MP module that we expect a message from processor pid that
should arrive soon. The MP module can use this as a
hint. Experimental.
*/

#endif /* \_\_PAN\_MP\_H\_\_ */

/*
%Local Variables:
%c-block-comments-indent-p: 5
%c-comment-leader: ""
%End:
*/
