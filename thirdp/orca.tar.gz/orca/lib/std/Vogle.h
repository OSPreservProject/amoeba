/* Produced by the Orca-to-C compiler */

/* Orca-to-C compiler, main branch, date: Tue Jun 30 16:56:47 MET DST 1998. */

#ifndef Vogle____SEEN
#define Vogle____SEEN
extern tp_dscr td_Vogle__Vogle;
typedef t_object t_Vogle__Vogle;
extern tp_dscr td_Vogle__BackBuffer;
typedef t_integer t_Vogle__BackBuffer;
extern tp_dscr td_Vogle__Circle;
typedef t_integer t_Vogle__Circle;
extern tp_dscr td_Vogle__Circle_Seg;
typedef t_integer t_Vogle__Circle_Seg;
extern tp_dscr td_Vogle__Clear;
typedef t_integer t_Vogle__Clear;
extern tp_dscr td_Vogle__Color;
typedef t_integer t_Vogle__Color;
extern tp_dscr td_Vogle__DrawStr;
typedef t_integer t_Vogle__DrawStr;
extern tp_dscr td_Vogle__Exit;
typedef t_integer t_Vogle__Exit;
extern tp_dscr td_Vogle__Init;
typedef t_integer t_Vogle__Init;
extern tp_dscr td_Vogle__Line;
typedef t_integer t_Vogle__Line;
extern tp_dscr td_Vogle__MapColor;
typedef t_integer t_Vogle__MapColor;
extern tp_dscr td_Vogle__Ortho;
typedef t_integer t_Vogle__Ortho;
extern tp_dscr td_Vogle__Point;
typedef t_integer t_Vogle__Point;
extern tp_dscr td_Vogle__PrefPosition;
typedef t_integer t_Vogle__PrefPosition;
extern tp_dscr td_Vogle__PrefSize;
typedef t_integer t_Vogle__PrefSize;
extern tp_dscr td_Vogle__Rect;
typedef t_integer t_Vogle__Rect;
extern tp_dscr td_Vogle__SwapBuffers;
typedef t_integer t_Vogle__SwapBuffers;
extern tp_dscr td_Vogle__VsetFlush;
typedef t_integer t_Vogle__VsetFlush;
extern tp_dscr td_Vogle__Vflush;
typedef t_integer t_Vogle__Vflush;
extern int sz_Vogle__Vogle(t_Vogle__Vogle *);
#ifdef PANDA4
extern pan_iovec_p ma_Vogle__Vogle(pan_iovec_p , t_Vogle__Vogle *);
void um_Vogle__Vogle(void *, t_Vogle__Vogle *);
#else
extern char *ma_Vogle__Vogle(char *, t_Vogle__Vogle *);
extern char *um_Vogle__Vogle(char *, t_Vogle__Vogle *);
#endif
void free_Vogle__Vogle(void *);
void ass_Vogle__Vogle(void *a, void *b);
extern char *fn_Vogle__Vogle;
t_boolean or_Vogle__BackBuffer(t_Vogle__Vogle *v__obj);
void or_Vogle__Circle(t_Vogle__Vogle *v__obj, t_integer v_col, t_boolean v_polyfill, t_real v_x, t_real v_y, t_real v_radius);
void or_Vogle__Circle_Seg(t_Vogle__Vogle *v__obj, t_integer v_col, t_boolean v_polyfill, t_integer v_nsegs, t_real v_x, t_real v_y, t_real v_radius);
void or_Vogle__Clear(t_Vogle__Vogle *v__obj, t_integer v_col);
void or_Vogle__Color(t_Vogle__Vogle *v__obj, t_integer v_col);
void or_Vogle__DrawStr(t_Vogle__Vogle *v__obj, t_integer v_col, t_real v_x, t_real v_y, t_string *v_str);
void or_Vogle__Exit(t_Vogle__Vogle *v__obj);
void or_Vogle__Init(t_Vogle__Vogle *v__obj);
void or_Vogle__Line(t_Vogle__Vogle *v__obj, t_integer v_col, t_real v_x1, t_real v_y1, t_real v_x2, t_real v_y2);
void or_Vogle__MapColor(t_Vogle__Vogle *v__obj, t_integer v_index, t_integer v_red, t_integer v_green, t_integer v_blue);
void or_Vogle__Ortho(t_Vogle__Vogle *v__obj, t_real v_left, t_real v_right, t_real v_bottom, t_real v_top);
void or_Vogle__Point(t_Vogle__Vogle *v__obj, t_integer v_col, t_real v_x, t_real v_y);
void or_Vogle__PrefPosition(t_Vogle__Vogle *v__obj, t_integer v_x, t_integer v_y);
void or_Vogle__PrefSize(t_Vogle__Vogle *v__obj, t_integer v_width, t_integer v_height);
void or_Vogle__Rect(t_Vogle__Vogle *v__obj, t_integer v_col, t_boolean v_polyfill, t_real v_x1, t_real v_y1, t_real v_x2, t_real v_y2);
void or_Vogle__SwapBuffers(t_Vogle__Vogle *v__obj);
void or_Vogle__VsetFlush(t_Vogle__Vogle *v__obj, t_boolean v_yesno);
void or_Vogle__Vflush(t_Vogle__Vogle *v__obj);
void init_t_Vogle__Vogle(t_Vogle__Vogle *v__obj, char *obj_name);
void ini_Vogle__Vogle(void);
#endif
