/* Produced by the Orca-to-C compiler */

/* Orca-to-C compiler, main branch, date: Tue Jun 30 16:56:47 MET DST 1998. */

#ifndef trace____SEEN
#define trace____SEEN
extern char *fn_trace__trace;
t_integer f_trace__set_level(t_integer v_level);
void f_trace__flush(void);
#define ini_trace__trace()	/* nothing */
#endif
