/* Produced by the Orca-to-C compiler */

/* Orca-to-C compiler, main branch, date: Tue Jun 30 16:56:47 MET DST 1998. */

#include <interface.h>
#include "Vogle.h"
#include "Xd.h"
#include "VTypes.h"
static tp_dscr td_Vogle__2;
typedef t_integer t_Vogle__2;
static par_dscr fa_Vogle__2[] = {
	{ OUT, &td_Vogle__Vogle, ass_Vogle__Vogle, free_Vogle__Vogle}
};
static tp_dscr td_Vogle__2 = { FUNCTION, sizeof(t_Vogle__2), 0, 0, 1, fa_Vogle__2};
static tp_dscr td_Vogle__3;
typedef t_integer t_Vogle__3;
static par_dscr fa_Vogle__3[] = {
	{ IN, &td_Vogle__Vogle, ass_Vogle__Vogle, free_Vogle__Vogle}
};
static tp_dscr td_Vogle__3 = { FUNCTION, sizeof(t_Vogle__3), 0, 0, 1, fa_Vogle__3};
static par_dscr fa_Vogle__BackBuffer[] = {
	{ OUT, &td_boolean, ass_enum, 0}
};
tp_dscr td_Vogle__BackBuffer = { FUNCTION, sizeof(t_Vogle__BackBuffer), 0, 0, 1, fa_Vogle__BackBuffer};
static par_dscr fa_Vogle__Circle[] = {
	{ IN, &td_integer, ass_integer, 0},
	{ IN, &td_boolean, ass_enum, 0},
	{ IN, &td_real, ass_real, 0},
	{ IN, &td_real, ass_real, 0},
	{ IN, &td_real, ass_real, 0}
};
tp_dscr td_Vogle__Circle = { FUNCTION, sizeof(t_Vogle__Circle), 0, 0, 5, fa_Vogle__Circle};
static par_dscr fa_Vogle__Circle_Seg[] = {
	{ IN, &td_integer, ass_integer, 0},
	{ IN, &td_boolean, ass_enum, 0},
	{ IN, &td_integer, ass_integer, 0},
	{ IN, &td_real, ass_real, 0},
	{ IN, &td_real, ass_real, 0},
	{ IN, &td_real, ass_real, 0}
};
tp_dscr td_Vogle__Circle_Seg = { FUNCTION, sizeof(t_Vogle__Circle_Seg), 0, 0, 6, fa_Vogle__Circle_Seg};
static par_dscr fa_Vogle__Clear[] = {
	{ IN, &td_integer, ass_integer, 0}
};
tp_dscr td_Vogle__Clear = { FUNCTION, sizeof(t_Vogle__Clear), 0, 0, 1, fa_Vogle__Clear};
static par_dscr fa_Vogle__Color[] = {
	{ IN, &td_integer, ass_integer, 0}
};
tp_dscr td_Vogle__Color = { FUNCTION, sizeof(t_Vogle__Color), 0, 0, 1, fa_Vogle__Color};
static par_dscr fa_Vogle__DrawStr[] = {
	{ IN, &td_integer, ass_integer, 0},
	{ IN, &td_real, ass_real, 0},
	{ IN, &td_real, ass_real, 0},
	{ IN, &td_string, ass_string, free_string}
};
tp_dscr td_Vogle__DrawStr = { FUNCTION, sizeof(t_Vogle__DrawStr), 0, 0, 4, fa_Vogle__DrawStr};
static par_dscr fa_Vogle__Exit[] = {
	{ 0, 0, 0, 0}
};
tp_dscr td_Vogle__Exit = { FUNCTION, sizeof(t_Vogle__Exit), 0, 0, 0, fa_Vogle__Exit};
static par_dscr fa_Vogle__Init[] = {
	{ 0, 0, 0, 0}
};
tp_dscr td_Vogle__Init = { FUNCTION, sizeof(t_Vogle__Init), 0, 0, 0, fa_Vogle__Init};
static par_dscr fa_Vogle__Line[] = {
	{ IN, &td_integer, ass_integer, 0},
	{ IN, &td_real, ass_real, 0},
	{ IN, &td_real, ass_real, 0},
	{ IN, &td_real, ass_real, 0},
	{ IN, &td_real, ass_real, 0}
};
tp_dscr td_Vogle__Line = { FUNCTION, sizeof(t_Vogle__Line), 0, 0, 5, fa_Vogle__Line};
static par_dscr fa_Vogle__MapColor[] = {
	{ IN, &td_integer, ass_integer, 0},
	{ IN, &td_integer, ass_integer, 0},
	{ IN, &td_integer, ass_integer, 0},
	{ IN, &td_integer, ass_integer, 0}
};
tp_dscr td_Vogle__MapColor = { FUNCTION, sizeof(t_Vogle__MapColor), 0, 0, 4, fa_Vogle__MapColor};
static par_dscr fa_Vogle__Ortho[] = {
	{ IN, &td_real, ass_real, 0},
	{ IN, &td_real, ass_real, 0},
	{ IN, &td_real, ass_real, 0},
	{ IN, &td_real, ass_real, 0}
};
tp_dscr td_Vogle__Ortho = { FUNCTION, sizeof(t_Vogle__Ortho), 0, 0, 4, fa_Vogle__Ortho};
static par_dscr fa_Vogle__Point[] = {
	{ IN, &td_integer, ass_integer, 0},
	{ IN, &td_real, ass_real, 0},
	{ IN, &td_real, ass_real, 0}
};
tp_dscr td_Vogle__Point = { FUNCTION, sizeof(t_Vogle__Point), 0, 0, 3, fa_Vogle__Point};
static par_dscr fa_Vogle__PrefPosition[] = {
	{ IN, &td_integer, ass_integer, 0},
	{ IN, &td_integer, ass_integer, 0}
};
tp_dscr td_Vogle__PrefPosition = { FUNCTION, sizeof(t_Vogle__PrefPosition), 0, 0, 2, fa_Vogle__PrefPosition};
static par_dscr fa_Vogle__PrefSize[] = {
	{ IN, &td_integer, ass_integer, 0},
	{ IN, &td_integer, ass_integer, 0}
};
tp_dscr td_Vogle__PrefSize = { FUNCTION, sizeof(t_Vogle__PrefSize), 0, 0, 2, fa_Vogle__PrefSize};
static par_dscr fa_Vogle__Rect[] = {
	{ IN, &td_integer, ass_integer, 0},
	{ IN, &td_boolean, ass_enum, 0},
	{ IN, &td_real, ass_real, 0},
	{ IN, &td_real, ass_real, 0},
	{ IN, &td_real, ass_real, 0},
	{ IN, &td_real, ass_real, 0}
};
tp_dscr td_Vogle__Rect = { FUNCTION, sizeof(t_Vogle__Rect), 0, 0, 6, fa_Vogle__Rect};
static par_dscr fa_Vogle__SwapBuffers[] = {
	{ 0, 0, 0, 0}
};
tp_dscr td_Vogle__SwapBuffers = { FUNCTION, sizeof(t_Vogle__SwapBuffers), 0, 0, 0, fa_Vogle__SwapBuffers};
static par_dscr fa_Vogle__VsetFlush[] = {
	{ IN, &td_boolean, ass_enum, 0}
};
tp_dscr td_Vogle__VsetFlush = { FUNCTION, sizeof(t_Vogle__VsetFlush), 0, 0, 1, fa_Vogle__VsetFlush};
static par_dscr fa_Vogle__Vflush[] = {
	{ 0, 0, 0, 0}
};
tp_dscr td_Vogle__Vflush = { FUNCTION, sizeof(t_Vogle__Vflush), 0, 0, 0, fa_Vogle__Vflush};
static tp_dscr td_Vogle__Draw;
typedef t_integer t_Vogle__Draw;
static par_dscr fa_Vogle__Draw[] = {
	{ IN, &td_real, ass_real, 0},
	{ IN, &td_real, ass_real, 0}
};
static tp_dscr td_Vogle__Draw = { FUNCTION, sizeof(t_Vogle__Draw), 0, 0, 2, fa_Vogle__Draw};
static tp_dscr td_Vogle__1;
typedef struct t_Vogle__1 {
	int dummy; /* no fields ? */
} t_Vogle__1;
static fld_dscr rf_Vogle__1[] = {
{ 0, 0}
};
static tp_dscr td_Vogle__1 = { RECORD, sizeof(t_Vogle__1), 4, 0, 0, rf_Vogle__1};
#undef init_t_Vogle__1
#define init_t_Vogle__1(p, s) { \
	}
static int cmp_Vogle__1(void *aa, void *bb) {
    t_Vogle__1 *a=aa; t_Vogle__1 *b=bb;
    return 1;
}
static void ass_Vogle__1(void *dd, void *ss) {
    t_Vogle__1 *dst = dd, *src = ss;
    if (dst == src) return;
}
static int or__Vogle__READ_(t_object *v_obj, void **v__args) {
    init_t_Vogle__Vogle((t_object *) (v__args[0]), "result");
    ass_Vogle__1(((t_object *) (v__args[0]))->o_fields, v_obj->o_fields);
    return 0;
}
static int ow__Vogle__WRITE_(t_object *v_obj, void **v__args) {
    ass_Vogle__1(v_obj->o_fields, ((t_object *) (v__args[0]))->o_fields);
    return 0;
}
t_boolean or_Vogle__BackBuffer(t_Vogle__Vogle *v__obj);
static int or__Vogle__BackBuffer(t_object *v_obj, void **v__args) {
    *((t_boolean *) v__args[0]) = or_Vogle__BackBuffer(v_obj);
    return 0;
}
void or_Vogle__Circle(t_Vogle__Vogle *v__obj, t_integer v_col, t_boolean v_polyfill, t_real v_x, t_real v_y, t_real v_radius);
static int or__Vogle__Circle(t_object *v_obj, void **v__args) {
    or_Vogle__Circle(v_obj,*((t_integer *) v__args[0]), *((t_boolean *) v__args[1]), *((t_real *) v__args[2]), *((t_real *) v__args[3]), *((t_real *) v__args[4]));
    return 0;
}
void or_Vogle__Circle_Seg(t_Vogle__Vogle *v__obj, t_integer v_col, t_boolean v_polyfill, t_integer v_nsegs, t_real v_x, t_real v_y, t_real v_radius);
static int or__Vogle__Circle_Seg(t_object *v_obj, void **v__args) {
    or_Vogle__Circle_Seg(v_obj,*((t_integer *) v__args[0]), *((t_boolean *) v__args[1]), *((t_integer *) v__args[2]), *((t_real *) v__args[3]), *((t_real *) v__args[4]), *((t_real *) v__args[5]));
    return 0;
}
void or_Vogle__Clear(t_Vogle__Vogle *v__obj, t_integer v_col);
static int or__Vogle__Clear(t_object *v_obj, void **v__args) {
    or_Vogle__Clear(v_obj,*((t_integer *) v__args[0]));
    return 0;
}
void or_Vogle__Color(t_Vogle__Vogle *v__obj, t_integer v_col);
static int or__Vogle__Color(t_object *v_obj, void **v__args) {
    or_Vogle__Color(v_obj,*((t_integer *) v__args[0]));
    return 0;
}
void or_Vogle__DrawStr(t_Vogle__Vogle *v__obj, t_integer v_col, t_real v_x, t_real v_y, t_string *v_str);
static int or__Vogle__DrawStr(t_object *v_obj, void **v__args) {
    or_Vogle__DrawStr(v_obj,*((t_integer *) v__args[0]), *((t_real *) v__args[1]), *((t_real *) v__args[2]), v__args[3]);
    return 0;
}
void or_Vogle__Exit(t_Vogle__Vogle *v__obj);
static int or__Vogle__Exit(t_object *v_obj, void **v__args) {
    or_Vogle__Exit(v_obj);
    return 0;
}
void or_Vogle__Init(t_Vogle__Vogle *v__obj);
static int or__Vogle__Init(t_object *v_obj, void **v__args) {
    or_Vogle__Init(v_obj);
    return 0;
}
void or_Vogle__Line(t_Vogle__Vogle *v__obj, t_integer v_col, t_real v_x1, t_real v_y1, t_real v_x2, t_real v_y2);
static int or__Vogle__Line(t_object *v_obj, void **v__args) {
    or_Vogle__Line(v_obj,*((t_integer *) v__args[0]), *((t_real *) v__args[1]), *((t_real *) v__args[2]), *((t_real *) v__args[3]), *((t_real *) v__args[4]));
    return 0;
}
void or_Vogle__MapColor(t_Vogle__Vogle *v__obj, t_integer v_index, t_integer v_red, t_integer v_green, t_integer v_blue);
static int or__Vogle__MapColor(t_object *v_obj, void **v__args) {
    or_Vogle__MapColor(v_obj,*((t_integer *) v__args[0]), *((t_integer *) v__args[1]), *((t_integer *) v__args[2]), *((t_integer *) v__args[3]));
    return 0;
}
void or_Vogle__Ortho(t_Vogle__Vogle *v__obj, t_real v_left, t_real v_right, t_real v_bottom, t_real v_top);
static int or__Vogle__Ortho(t_object *v_obj, void **v__args) {
    or_Vogle__Ortho(v_obj,*((t_real *) v__args[0]), *((t_real *) v__args[1]), *((t_real *) v__args[2]), *((t_real *) v__args[3]));
    return 0;
}
void or_Vogle__Point(t_Vogle__Vogle *v__obj, t_integer v_col, t_real v_x, t_real v_y);
static int or__Vogle__Point(t_object *v_obj, void **v__args) {
    or_Vogle__Point(v_obj,*((t_integer *) v__args[0]), *((t_real *) v__args[1]), *((t_real *) v__args[2]));
    return 0;
}
void or_Vogle__PrefPosition(t_Vogle__Vogle *v__obj, t_integer v_x, t_integer v_y);
static int or__Vogle__PrefPosition(t_object *v_obj, void **v__args) {
    or_Vogle__PrefPosition(v_obj,*((t_integer *) v__args[0]), *((t_integer *) v__args[1]));
    return 0;
}
void or_Vogle__PrefSize(t_Vogle__Vogle *v__obj, t_integer v_width, t_integer v_height);
static int or__Vogle__PrefSize(t_object *v_obj, void **v__args) {
    or_Vogle__PrefSize(v_obj,*((t_integer *) v__args[0]), *((t_integer *) v__args[1]));
    return 0;
}
void or_Vogle__Rect(t_Vogle__Vogle *v__obj, t_integer v_col, t_boolean v_polyfill, t_real v_x1, t_real v_y1, t_real v_x2, t_real v_y2);
static int or__Vogle__Rect(t_object *v_obj, void **v__args) {
    or_Vogle__Rect(v_obj,*((t_integer *) v__args[0]), *((t_boolean *) v__args[1]), *((t_real *) v__args[2]), *((t_real *) v__args[3]), *((t_real *) v__args[4]), *((t_real *) v__args[5]));
    return 0;
}
void or_Vogle__SwapBuffers(t_Vogle__Vogle *v__obj);
static int or__Vogle__SwapBuffers(t_object *v_obj, void **v__args) {
    or_Vogle__SwapBuffers(v_obj);
    return 0;
}
void or_Vogle__VsetFlush(t_Vogle__Vogle *v__obj, t_boolean v_yesno);
static int or__Vogle__VsetFlush(t_object *v_obj, void **v__args) {
    or_Vogle__VsetFlush(v_obj,*((t_boolean *) v__args[0]));
    return 0;
}
void or_Vogle__Vflush(t_Vogle__Vogle *v__obj);
static int or__Vogle__Vflush(t_object *v_obj, void **v__args) {
    or_Vogle__Vflush(v_obj);
    return 0;
}
static void or_Vogle__Draw(t_Vogle__Vogle *v__obj, t_real v_x, t_real v_y);
static int or__Vogle__Draw(t_object *v_obj, void **v__args) {
    or_Vogle__Draw(v_obj,*((t_real *) v__args[0]), *((t_real *) v__args[1]));
    return 0;
}
#ifdef PANDA4
static int sz_call_Vogle__READ_(void **argv) {
	int sz = 0;
	return sz;
}
static pan_iovec_p ma_call_Vogle__READ_(pan_iovec_p p, void **argv) {
	return p;
}
static void um_call_Vogle__READ_(void *p, void ***ap) {
	struct {
		void *av[1];
		t_Vogle__Vogle arg1;
	} *argstruct;
	argstruct = m_malloc(sizeof(*argstruct));
	*ap = argstruct->av;
	argstruct->av[0] = &(argstruct->arg1);
	memset(&(argstruct->arg1), 0, sizeof(t_Vogle__Vogle));
}
static int sz_ret_Vogle__READ_(void **argv) {
	int sz = 0;
	sz += sz_Vogle__Vogle(argv[0]);
	return sz;
}
static pan_iovec_p ma_ret_Vogle__READ_(pan_iovec_p p, void **argv) {
	p = ma_Vogle__Vogle(p, argv[0]);
	return p;
}
static void um_ret_Vogle__READ_(void *p, void **argv) {
	free_Vogle__Vogle(argv[0]);
	um_Vogle__Vogle(p, argv[0]);
}
#else
static int sz_call_Vogle__READ_(void **argv) {
	int sz = 0;
	return sz;
}
static char *ma_call_Vogle__READ_(char *p, void **argv) {
	return p;
}
static char *um_call_Vogle__READ_(char *p, void ***ap) {
	struct {
		void *av[1];
		t_Vogle__Vogle arg1;
	} *argstruct;
	argstruct = m_malloc(sizeof(*argstruct));
	*ap = argstruct->av;
	argstruct->av[0] = &(argstruct->arg1);
	memset(&(argstruct->arg1), 0, sizeof(t_Vogle__Vogle));
	return p;
}
static int sz_ret_Vogle__READ_(void **argv) {
	int sz = 0;
	sz += sz_Vogle__Vogle(argv[0]);
	return sz;
}
static char *ma_ret_Vogle__READ_(char *p, void **argv) {
	p = ma_Vogle__Vogle(p, argv[0]);
	free_Vogle__Vogle(argv[0]);
	m_free((void *) argv);
	return p;
}
static char *um_ret_Vogle__READ_(char *p, void **argv) {
	free_Vogle__Vogle(argv[0]);
	p = um_Vogle__Vogle(p, argv[0]);
	return p;
}
#endif
static void fr_ret_Vogle__READ_(void **argv) {
	free_Vogle__Vogle(argv[0]);
	m_free((void *) argv);
}
#ifdef PANDA4
static int sz_call_Vogle__WRITE_(void **argv) {
	int sz = 0;
	sz += sz_Vogle__Vogle(argv[0]);
	return sz;
}
static pan_iovec_p ma_call_Vogle__WRITE_(pan_iovec_p p, void **argv) {
	p = ma_Vogle__Vogle(p, argv[0]);
	return p;
}
static void um_call_Vogle__WRITE_(void *p, void ***ap) {
	struct {
		void *av[1];
		t_Vogle__Vogle arg1;
	} *argstruct;
	argstruct = m_malloc(sizeof(*argstruct));
	*ap = argstruct->av;
	argstruct->av[0] = &(argstruct->arg1);
	um_Vogle__Vogle(p, &(argstruct->arg1));
}
static int sz_ret_Vogle__WRITE_(void **argv) {
	int sz = 0;
	return sz;
}
static pan_iovec_p ma_ret_Vogle__WRITE_(pan_iovec_p p, void **argv) {
	return p;
}
static void um_ret_Vogle__WRITE_(void *p, void **argv) {
}
#else
static int sz_call_Vogle__WRITE_(void **argv) {
	int sz = 0;
	sz += sz_Vogle__Vogle(argv[0]);
	return sz;
}
static char *ma_call_Vogle__WRITE_(char *p, void **argv) {
	p = ma_Vogle__Vogle(p, argv[0]);
	return p;
}
static char *um_call_Vogle__WRITE_(char *p, void ***ap) {
	struct {
		void *av[1];
		t_Vogle__Vogle arg1;
	} *argstruct;
	argstruct = m_malloc(sizeof(*argstruct));
	*ap = argstruct->av;
	argstruct->av[0] = &(argstruct->arg1);
	p = um_Vogle__Vogle(p, &(argstruct->arg1));
	return p;
}
static int sz_ret_Vogle__WRITE_(void **argv) {
	int sz = 0;
	return sz;
}
static char *ma_ret_Vogle__WRITE_(char *p, void **argv) {
	free_Vogle__Vogle(argv[0]);
	m_free((void *) argv);
	return p;
}
static char *um_ret_Vogle__WRITE_(char *p, void **argv) {
	return p;
}
#endif
static void fr_ret_Vogle__WRITE_(void **argv) {
	free_Vogle__Vogle(argv[0]);
	m_free((void *) argv);
}
#ifdef PANDA4
static int sz_call_Vogle__BackBuffer(void **argv) {
	int sz = 0;
	return sz;
}
static pan_iovec_p ma_call_Vogle__BackBuffer(pan_iovec_p p, void **argv) {
	return p;
}
static void um_call_Vogle__BackBuffer(void *p, void ***ap) {
	struct {
		void *av[1];
		t_boolean result;
	} *argstruct;
	argstruct = m_malloc(sizeof(*argstruct));
	*ap = argstruct->av;
	argstruct->av[0] = &(argstruct->result);
}
static int sz_ret_Vogle__BackBuffer(void **argv) {
	int sz = 0;
	sz++;
	return sz;
}
static pan_iovec_p ma_ret_Vogle__BackBuffer(pan_iovec_p p, void **argv) {
	p->data = argv[0];
	p->len = sizeof(t_boolean);
	p++;
	return p;
}
static void um_ret_Vogle__BackBuffer(void *p, void **argv) {
	pan_msg_consume(p, argv[0], sizeof(t_boolean));
}
#else
static int sz_call_Vogle__BackBuffer(void **argv) {
	int sz = 0;
	return sz;
}
static char *ma_call_Vogle__BackBuffer(char *p, void **argv) {
	return p;
}
static char *um_call_Vogle__BackBuffer(char *p, void ***ap) {
	struct {
		void *av[1];
		t_boolean result;
	} *argstruct;
	argstruct = m_malloc(sizeof(*argstruct));
	*ap = argstruct->av;
	argstruct->av[0] = &(argstruct->result);
	return p;
}
static int sz_ret_Vogle__BackBuffer(void **argv) {
	int sz = 0;
	sz += sizeof(t_boolean);
	return sz;
}
static char *ma_ret_Vogle__BackBuffer(char *p, void **argv) {
	memcpy(p, argv[0], sizeof(t_boolean));
	p += sizeof(t_boolean);
	m_free((void *) argv);
	return p;
}
static char *um_ret_Vogle__BackBuffer(char *p, void **argv) {
	memcpy(argv[0], p, sizeof(t_boolean));
	p += sizeof(t_boolean);
	return p;
}
#endif
static void fr_ret_Vogle__BackBuffer(void **argv) {
	m_free((void *) argv);
}
#ifdef PANDA4
static int sz_call_Vogle__Circle(void **argv) {
	int sz = 0;
	sz++;
	sz++;
	sz++;
	sz++;
	sz++;
	return sz;
}
static pan_iovec_p ma_call_Vogle__Circle(pan_iovec_p p, void **argv) {
	p->data = argv[0];
	p->len = sizeof(t_integer);
	p++;
	p->data = argv[1];
	p->len = sizeof(t_boolean);
	p++;
	p->data = argv[2];
	p->len = sizeof(t_real);
	p++;
	p->data = argv[3];
	p->len = sizeof(t_real);
	p++;
	p->data = argv[4];
	p->len = sizeof(t_real);
	p++;
	return p;
}
static void um_call_Vogle__Circle(void *p, void ***ap) {
	struct {
		void *av[5];
		t_integer arg1;
		t_boolean arg2;
		t_real arg3;
		t_real arg4;
		t_real arg5;
	} *argstruct;
	argstruct = m_malloc(sizeof(*argstruct));
	*ap = argstruct->av;
	argstruct->av[0] = &(argstruct->arg1);
	pan_msg_consume(p, &(argstruct->arg1), sizeof(t_integer));
	argstruct->av[1] = &(argstruct->arg2);
	pan_msg_consume(p, &(argstruct->arg2), sizeof(t_boolean));
	argstruct->av[2] = &(argstruct->arg3);
	pan_msg_consume(p, &(argstruct->arg3), sizeof(t_real));
	argstruct->av[3] = &(argstruct->arg4);
	pan_msg_consume(p, &(argstruct->arg4), sizeof(t_real));
	argstruct->av[4] = &(argstruct->arg5);
	pan_msg_consume(p, &(argstruct->arg5), sizeof(t_real));
}
static int sz_ret_Vogle__Circle(void **argv) {
	int sz = 0;
	return sz;
}
static pan_iovec_p ma_ret_Vogle__Circle(pan_iovec_p p, void **argv) {
	return p;
}
static void um_ret_Vogle__Circle(void *p, void **argv) {
}
#else
static int sz_call_Vogle__Circle(void **argv) {
	int sz = 0;
	sz += sizeof(t_integer);
	sz += sizeof(t_boolean);
	sz += sizeof(t_real);
	sz += sizeof(t_real);
	sz += sizeof(t_real);
	return sz;
}
static char *ma_call_Vogle__Circle(char *p, void **argv) {
	memcpy(p, argv[0], sizeof(t_integer));
	p += sizeof(t_integer);
	memcpy(p, argv[1], sizeof(t_boolean));
	p += sizeof(t_boolean);
	memcpy(p, argv[2], sizeof(t_real));
	p += sizeof(t_real);
	memcpy(p, argv[3], sizeof(t_real));
	p += sizeof(t_real);
	memcpy(p, argv[4], sizeof(t_real));
	p += sizeof(t_real);
	return p;
}
static char *um_call_Vogle__Circle(char *p, void ***ap) {
	struct {
		void *av[5];
		t_integer arg1;
		t_boolean arg2;
		t_real arg3;
		t_real arg4;
		t_real arg5;
	} *argstruct;
	argstruct = m_malloc(sizeof(*argstruct));
	*ap = argstruct->av;
	argstruct->av[0] = &(argstruct->arg1);
	memcpy(&(argstruct->arg1), p, sizeof(t_integer));
	p += sizeof(t_integer);
	argstruct->av[1] = &(argstruct->arg2);
	memcpy(&(argstruct->arg2), p, sizeof(t_boolean));
	p += sizeof(t_boolean);
	argstruct->av[2] = &(argstruct->arg3);
	memcpy(&(argstruct->arg3), p, sizeof(t_real));
	p += sizeof(t_real);
	argstruct->av[3] = &(argstruct->arg4);
	memcpy(&(argstruct->arg4), p, sizeof(t_real));
	p += sizeof(t_real);
	argstruct->av[4] = &(argstruct->arg5);
	memcpy(&(argstruct->arg5), p, sizeof(t_real));
	p += sizeof(t_real);
	return p;
}
static int sz_ret_Vogle__Circle(void **argv) {
	int sz = 0;
	return sz;
}
static char *ma_ret_Vogle__Circle(char *p, void **argv) {
	m_free((void *) argv);
	return p;
}
static char *um_ret_Vogle__Circle(char *p, void **argv) {
	return p;
}
#endif
static void fr_ret_Vogle__Circle(void **argv) {
	m_free((void *) argv);
}
#ifdef PANDA4
static int sz_call_Vogle__Circle_Seg(void **argv) {
	int sz = 0;
	sz++;
	sz++;
	sz++;
	sz++;
	sz++;
	sz++;
	return sz;
}
static pan_iovec_p ma_call_Vogle__Circle_Seg(pan_iovec_p p, void **argv) {
	p->data = argv[0];
	p->len = sizeof(t_integer);
	p++;
	p->data = argv[1];
	p->len = sizeof(t_boolean);
	p++;
	p->data = argv[2];
	p->len = sizeof(t_integer);
	p++;
	p->data = argv[3];
	p->len = sizeof(t_real);
	p++;
	p->data = argv[4];
	p->len = sizeof(t_real);
	p++;
	p->data = argv[5];
	p->len = sizeof(t_real);
	p++;
	return p;
}
static void um_call_Vogle__Circle_Seg(void *p, void ***ap) {
	struct {
		void *av[6];
		t_integer arg1;
		t_boolean arg2;
		t_integer arg3;
		t_real arg4;
		t_real arg5;
		t_real arg6;
	} *argstruct;
	argstruct = m_malloc(sizeof(*argstruct));
	*ap = argstruct->av;
	argstruct->av[0] = &(argstruct->arg1);
	pan_msg_consume(p, &(argstruct->arg1), sizeof(t_integer));
	argstruct->av[1] = &(argstruct->arg2);
	pan_msg_consume(p, &(argstruct->arg2), sizeof(t_boolean));
	argstruct->av[2] = &(argstruct->arg3);
	pan_msg_consume(p, &(argstruct->arg3), sizeof(t_integer));
	argstruct->av[3] = &(argstruct->arg4);
	pan_msg_consume(p, &(argstruct->arg4), sizeof(t_real));
	argstruct->av[4] = &(argstruct->arg5);
	pan_msg_consume(p, &(argstruct->arg5), sizeof(t_real));
	argstruct->av[5] = &(argstruct->arg6);
	pan_msg_consume(p, &(argstruct->arg6), sizeof(t_real));
}
static int sz_ret_Vogle__Circle_Seg(void **argv) {
	int sz = 0;
	return sz;
}
static pan_iovec_p ma_ret_Vogle__Circle_Seg(pan_iovec_p p, void **argv) {
	return p;
}
static void um_ret_Vogle__Circle_Seg(void *p, void **argv) {
}
#else
static int sz_call_Vogle__Circle_Seg(void **argv) {
	int sz = 0;
	sz += sizeof(t_integer);
	sz += sizeof(t_boolean);
	sz += sizeof(t_integer);
	sz += sizeof(t_real);
	sz += sizeof(t_real);
	sz += sizeof(t_real);
	return sz;
}
static char *ma_call_Vogle__Circle_Seg(char *p, void **argv) {
	memcpy(p, argv[0], sizeof(t_integer));
	p += sizeof(t_integer);
	memcpy(p, argv[1], sizeof(t_boolean));
	p += sizeof(t_boolean);
	memcpy(p, argv[2], sizeof(t_integer));
	p += sizeof(t_integer);
	memcpy(p, argv[3], sizeof(t_real));
	p += sizeof(t_real);
	memcpy(p, argv[4], sizeof(t_real));
	p += sizeof(t_real);
	memcpy(p, argv[5], sizeof(t_real));
	p += sizeof(t_real);
	return p;
}
static char *um_call_Vogle__Circle_Seg(char *p, void ***ap) {
	struct {
		void *av[6];
		t_integer arg1;
		t_boolean arg2;
		t_integer arg3;
		t_real arg4;
		t_real arg5;
		t_real arg6;
	} *argstruct;
	argstruct = m_malloc(sizeof(*argstruct));
	*ap = argstruct->av;
	argstruct->av[0] = &(argstruct->arg1);
	memcpy(&(argstruct->arg1), p, sizeof(t_integer));
	p += sizeof(t_integer);
	argstruct->av[1] = &(argstruct->arg2);
	memcpy(&(argstruct->arg2), p, sizeof(t_boolean));
	p += sizeof(t_boolean);
	argstruct->av[2] = &(argstruct->arg3);
	memcpy(&(argstruct->arg3), p, sizeof(t_integer));
	p += sizeof(t_integer);
	argstruct->av[3] = &(argstruct->arg4);
	memcpy(&(argstruct->arg4), p, sizeof(t_real));
	p += sizeof(t_real);
	argstruct->av[4] = &(argstruct->arg5);
	memcpy(&(argstruct->arg5), p, sizeof(t_real));
	p += sizeof(t_real);
	argstruct->av[5] = &(argstruct->arg6);
	memcpy(&(argstruct->arg6), p, sizeof(t_real));
	p += sizeof(t_real);
	return p;
}
static int sz_ret_Vogle__Circle_Seg(void **argv) {
	int sz = 0;
	return sz;
}
static char *ma_ret_Vogle__Circle_Seg(char *p, void **argv) {
	m_free((void *) argv);
	return p;
}
static char *um_ret_Vogle__Circle_Seg(char *p, void **argv) {
	return p;
}
#endif
static void fr_ret_Vogle__Circle_Seg(void **argv) {
	m_free((void *) argv);
}
#ifdef PANDA4
static int sz_call_Vogle__Clear(void **argv) {
	int sz = 0;
	sz++;
	return sz;
}
static pan_iovec_p ma_call_Vogle__Clear(pan_iovec_p p, void **argv) {
	p->data = argv[0];
	p->len = sizeof(t_integer);
	p++;
	return p;
}
static void um_call_Vogle__Clear(void *p, void ***ap) {
	struct {
		void *av[1];
		t_integer arg1;
	} *argstruct;
	argstruct = m_malloc(sizeof(*argstruct));
	*ap = argstruct->av;
	argstruct->av[0] = &(argstruct->arg1);
	pan_msg_consume(p, &(argstruct->arg1), sizeof(t_integer));
}
static int sz_ret_Vogle__Clear(void **argv) {
	int sz = 0;
	return sz;
}
static pan_iovec_p ma_ret_Vogle__Clear(pan_iovec_p p, void **argv) {
	return p;
}
static void um_ret_Vogle__Clear(void *p, void **argv) {
}
#else
static int sz_call_Vogle__Clear(void **argv) {
	int sz = 0;
	sz += sizeof(t_integer);
	return sz;
}
static char *ma_call_Vogle__Clear(char *p, void **argv) {
	memcpy(p, argv[0], sizeof(t_integer));
	p += sizeof(t_integer);
	return p;
}
static char *um_call_Vogle__Clear(char *p, void ***ap) {
	struct {
		void *av[1];
		t_integer arg1;
	} *argstruct;
	argstruct = m_malloc(sizeof(*argstruct));
	*ap = argstruct->av;
	argstruct->av[0] = &(argstruct->arg1);
	memcpy(&(argstruct->arg1), p, sizeof(t_integer));
	p += sizeof(t_integer);
	return p;
}
static int sz_ret_Vogle__Clear(void **argv) {
	int sz = 0;
	return sz;
}
static char *ma_ret_Vogle__Clear(char *p, void **argv) {
	m_free((void *) argv);
	return p;
}
static char *um_ret_Vogle__Clear(char *p, void **argv) {
	return p;
}
#endif
static void fr_ret_Vogle__Clear(void **argv) {
	m_free((void *) argv);
}
#ifdef PANDA4
static int sz_call_Vogle__Color(void **argv) {
	int sz = 0;
	sz++;
	return sz;
}
static pan_iovec_p ma_call_Vogle__Color(pan_iovec_p p, void **argv) {
	p->data = argv[0];
	p->len = sizeof(t_integer);
	p++;
	return p;
}
static void um_call_Vogle__Color(void *p, void ***ap) {
	struct {
		void *av[1];
		t_integer arg1;
	} *argstruct;
	argstruct = m_malloc(sizeof(*argstruct));
	*ap = argstruct->av;
	argstruct->av[0] = &(argstruct->arg1);
	pan_msg_consume(p, &(argstruct->arg1), sizeof(t_integer));
}
static int sz_ret_Vogle__Color(void **argv) {
	int sz = 0;
	return sz;
}
static pan_iovec_p ma_ret_Vogle__Color(pan_iovec_p p, void **argv) {
	return p;
}
static void um_ret_Vogle__Color(void *p, void **argv) {
}
#else
static int sz_call_Vogle__Color(void **argv) {
	int sz = 0;
	sz += sizeof(t_integer);
	return sz;
}
static char *ma_call_Vogle__Color(char *p, void **argv) {
	memcpy(p, argv[0], sizeof(t_integer));
	p += sizeof(t_integer);
	return p;
}
static char *um_call_Vogle__Color(char *p, void ***ap) {
	struct {
		void *av[1];
		t_integer arg1;
	} *argstruct;
	argstruct = m_malloc(sizeof(*argstruct));
	*ap = argstruct->av;
	argstruct->av[0] = &(argstruct->arg1);
	memcpy(&(argstruct->arg1), p, sizeof(t_integer));
	p += sizeof(t_integer);
	return p;
}
static int sz_ret_Vogle__Color(void **argv) {
	int sz = 0;
	return sz;
}
static char *ma_ret_Vogle__Color(char *p, void **argv) {
	m_free((void *) argv);
	return p;
}
static char *um_ret_Vogle__Color(char *p, void **argv) {
	return p;
}
#endif
static void fr_ret_Vogle__Color(void **argv) {
	m_free((void *) argv);
}
#ifdef PANDA4
static int sz_call_Vogle__DrawStr(void **argv) {
	int sz = 0;
	sz++;
	sz++;
	sz++;
	sz += sz_string(argv[3]);
	return sz;
}
static pan_iovec_p ma_call_Vogle__DrawStr(pan_iovec_p p, void **argv) {
	p->data = argv[0];
	p->len = sizeof(t_integer);
	p++;
	p->data = argv[1];
	p->len = sizeof(t_real);
	p++;
	p->data = argv[2];
	p->len = sizeof(t_real);
	p++;
	p = ma_string(p, argv[3]);
	return p;
}
static void um_call_Vogle__DrawStr(void *p, void ***ap) {
	struct {
		void *av[4];
		t_integer arg1;
		t_real arg2;
		t_real arg3;
		t_string arg4;
	} *argstruct;
	argstruct = m_malloc(sizeof(*argstruct));
	*ap = argstruct->av;
	argstruct->av[0] = &(argstruct->arg1);
	pan_msg_consume(p, &(argstruct->arg1), sizeof(t_integer));
	argstruct->av[1] = &(argstruct->arg2);
	pan_msg_consume(p, &(argstruct->arg2), sizeof(t_real));
	argstruct->av[2] = &(argstruct->arg3);
	pan_msg_consume(p, &(argstruct->arg3), sizeof(t_real));
	argstruct->av[3] = &(argstruct->arg4);
	um_string(p, &(argstruct->arg4));
}
static int sz_ret_Vogle__DrawStr(void **argv) {
	int sz = 0;
	return sz;
}
static pan_iovec_p ma_ret_Vogle__DrawStr(pan_iovec_p p, void **argv) {
	return p;
}
static void um_ret_Vogle__DrawStr(void *p, void **argv) {
}
#else
static int sz_call_Vogle__DrawStr(void **argv) {
	int sz = 0;
	sz += sizeof(t_integer);
	sz += sizeof(t_real);
	sz += sizeof(t_real);
	sz += sz_string(argv[3]);
	return sz;
}
static char *ma_call_Vogle__DrawStr(char *p, void **argv) {
	memcpy(p, argv[0], sizeof(t_integer));
	p += sizeof(t_integer);
	memcpy(p, argv[1], sizeof(t_real));
	p += sizeof(t_real);
	memcpy(p, argv[2], sizeof(t_real));
	p += sizeof(t_real);
	p = ma_string(p, argv[3]);
	return p;
}
static char *um_call_Vogle__DrawStr(char *p, void ***ap) {
	struct {
		void *av[4];
		t_integer arg1;
		t_real arg2;
		t_real arg3;
		t_string arg4;
	} *argstruct;
	argstruct = m_malloc(sizeof(*argstruct));
	*ap = argstruct->av;
	argstruct->av[0] = &(argstruct->arg1);
	memcpy(&(argstruct->arg1), p, sizeof(t_integer));
	p += sizeof(t_integer);
	argstruct->av[1] = &(argstruct->arg2);
	memcpy(&(argstruct->arg2), p, sizeof(t_real));
	p += sizeof(t_real);
	argstruct->av[2] = &(argstruct->arg3);
	memcpy(&(argstruct->arg3), p, sizeof(t_real));
	p += sizeof(t_real);
	argstruct->av[3] = &(argstruct->arg4);
	p = um_string(p, &(argstruct->arg4));
	return p;
}
static int sz_ret_Vogle__DrawStr(void **argv) {
	int sz = 0;
	return sz;
}
static char *ma_ret_Vogle__DrawStr(char *p, void **argv) {
	free_string(argv[3]);
	m_free((void *) argv);
	return p;
}
static char *um_ret_Vogle__DrawStr(char *p, void **argv) {
	return p;
}
#endif
static void fr_ret_Vogle__DrawStr(void **argv) {
	free_string(argv[3]);
	m_free((void *) argv);
}
#ifdef PANDA4
static int sz_call_Vogle__Exit(void **argv) {
	int sz = 0;
	return sz;
}
static pan_iovec_p ma_call_Vogle__Exit(pan_iovec_p p, void **argv) {
	return p;
}
static void um_call_Vogle__Exit(void *p, void ***ap) {
	*ap = 0;
}
static int sz_ret_Vogle__Exit(void **argv) {
	int sz = 0;
	return sz;
}
static pan_iovec_p ma_ret_Vogle__Exit(pan_iovec_p p, void **argv) {
	return p;
}
static void um_ret_Vogle__Exit(void *p, void **argv) {
}
#else
static int sz_call_Vogle__Exit(void **argv) {
	int sz = 0;
	return sz;
}
static char *ma_call_Vogle__Exit(char *p, void **argv) {
	return p;
}
static char *um_call_Vogle__Exit(char *p, void ***ap) {
	*ap = 0;
	return p;
}
static int sz_ret_Vogle__Exit(void **argv) {
	int sz = 0;
	return sz;
}
static char *ma_ret_Vogle__Exit(char *p, void **argv) {
	m_free((void *) argv);
	return p;
}
static char *um_ret_Vogle__Exit(char *p, void **argv) {
	return p;
}
#endif
static void fr_ret_Vogle__Exit(void **argv) {
	m_free((void *) argv);
}
#ifdef PANDA4
static int sz_call_Vogle__Init(void **argv) {
	int sz = 0;
	return sz;
}
static pan_iovec_p ma_call_Vogle__Init(pan_iovec_p p, void **argv) {
	return p;
}
static void um_call_Vogle__Init(void *p, void ***ap) {
	*ap = 0;
}
static int sz_ret_Vogle__Init(void **argv) {
	int sz = 0;
	return sz;
}
static pan_iovec_p ma_ret_Vogle__Init(pan_iovec_p p, void **argv) {
	return p;
}
static void um_ret_Vogle__Init(void *p, void **argv) {
}
#else
static int sz_call_Vogle__Init(void **argv) {
	int sz = 0;
	return sz;
}
static char *ma_call_Vogle__Init(char *p, void **argv) {
	return p;
}
static char *um_call_Vogle__Init(char *p, void ***ap) {
	*ap = 0;
	return p;
}
static int sz_ret_Vogle__Init(void **argv) {
	int sz = 0;
	return sz;
}
static char *ma_ret_Vogle__Init(char *p, void **argv) {
	m_free((void *) argv);
	return p;
}
static char *um_ret_Vogle__Init(char *p, void **argv) {
	return p;
}
#endif
static void fr_ret_Vogle__Init(void **argv) {
	m_free((void *) argv);
}
#ifdef PANDA4
static int sz_call_Vogle__Line(void **argv) {
	int sz = 0;
	sz++;
	sz++;
	sz++;
	sz++;
	sz++;
	return sz;
}
static pan_iovec_p ma_call_Vogle__Line(pan_iovec_p p, void **argv) {
	p->data = argv[0];
	p->len = sizeof(t_integer);
	p++;
	p->data = argv[1];
	p->len = sizeof(t_real);
	p++;
	p->data = argv[2];
	p->len = sizeof(t_real);
	p++;
	p->data = argv[3];
	p->len = sizeof(t_real);
	p++;
	p->data = argv[4];
	p->len = sizeof(t_real);
	p++;
	return p;
}
static void um_call_Vogle__Line(void *p, void ***ap) {
	struct {
		void *av[5];
		t_integer arg1;
		t_real arg2;
		t_real arg3;
		t_real arg4;
		t_real arg5;
	} *argstruct;
	argstruct = m_malloc(sizeof(*argstruct));
	*ap = argstruct->av;
	argstruct->av[0] = &(argstruct->arg1);
	pan_msg_consume(p, &(argstruct->arg1), sizeof(t_integer));
	argstruct->av[1] = &(argstruct->arg2);
	pan_msg_consume(p, &(argstruct->arg2), sizeof(t_real));
	argstruct->av[2] = &(argstruct->arg3);
	pan_msg_consume(p, &(argstruct->arg3), sizeof(t_real));
	argstruct->av[3] = &(argstruct->arg4);
	pan_msg_consume(p, &(argstruct->arg4), sizeof(t_real));
	argstruct->av[4] = &(argstruct->arg5);
	pan_msg_consume(p, &(argstruct->arg5), sizeof(t_real));
}
static int sz_ret_Vogle__Line(void **argv) {
	int sz = 0;
	return sz;
}
static pan_iovec_p ma_ret_Vogle__Line(pan_iovec_p p, void **argv) {
	return p;
}
static void um_ret_Vogle__Line(void *p, void **argv) {
}
#else
static int sz_call_Vogle__Line(void **argv) {
	int sz = 0;
	sz += sizeof(t_integer);
	sz += sizeof(t_real);
	sz += sizeof(t_real);
	sz += sizeof(t_real);
	sz += sizeof(t_real);
	return sz;
}
static char *ma_call_Vogle__Line(char *p, void **argv) {
	memcpy(p, argv[0], sizeof(t_integer));
	p += sizeof(t_integer);
	memcpy(p, argv[1], sizeof(t_real));
	p += sizeof(t_real);
	memcpy(p, argv[2], sizeof(t_real));
	p += sizeof(t_real);
	memcpy(p, argv[3], sizeof(t_real));
	p += sizeof(t_real);
	memcpy(p, argv[4], sizeof(t_real));
	p += sizeof(t_real);
	return p;
}
static char *um_call_Vogle__Line(char *p, void ***ap) {
	struct {
		void *av[5];
		t_integer arg1;
		t_real arg2;
		t_real arg3;
		t_real arg4;
		t_real arg5;
	} *argstruct;
	argstruct = m_malloc(sizeof(*argstruct));
	*ap = argstruct->av;
	argstruct->av[0] = &(argstruct->arg1);
	memcpy(&(argstruct->arg1), p, sizeof(t_integer));
	p += sizeof(t_integer);
	argstruct->av[1] = &(argstruct->arg2);
	memcpy(&(argstruct->arg2), p, sizeof(t_real));
	p += sizeof(t_real);
	argstruct->av[2] = &(argstruct->arg3);
	memcpy(&(argstruct->arg3), p, sizeof(t_real));
	p += sizeof(t_real);
	argstruct->av[3] = &(argstruct->arg4);
	memcpy(&(argstruct->arg4), p, sizeof(t_real));
	p += sizeof(t_real);
	argstruct->av[4] = &(argstruct->arg5);
	memcpy(&(argstruct->arg5), p, sizeof(t_real));
	p += sizeof(t_real);
	return p;
}
static int sz_ret_Vogle__Line(void **argv) {
	int sz = 0;
	return sz;
}
static char *ma_ret_Vogle__Line(char *p, void **argv) {
	m_free((void *) argv);
	return p;
}
static char *um_ret_Vogle__Line(char *p, void **argv) {
	return p;
}
#endif
static void fr_ret_Vogle__Line(void **argv) {
	m_free((void *) argv);
}
#ifdef PANDA4
static int sz_call_Vogle__MapColor(void **argv) {
	int sz = 0;
	sz++;
	sz++;
	sz++;
	sz++;
	return sz;
}
static pan_iovec_p ma_call_Vogle__MapColor(pan_iovec_p p, void **argv) {
	p->data = argv[0];
	p->len = sizeof(t_integer);
	p++;
	p->data = argv[1];
	p->len = sizeof(t_integer);
	p++;
	p->data = argv[2];
	p->len = sizeof(t_integer);
	p++;
	p->data = argv[3];
	p->len = sizeof(t_integer);
	p++;
	return p;
}
static void um_call_Vogle__MapColor(void *p, void ***ap) {
	struct {
		void *av[4];
		t_integer arg1;
		t_integer arg2;
		t_integer arg3;
		t_integer arg4;
	} *argstruct;
	argstruct = m_malloc(sizeof(*argstruct));
	*ap = argstruct->av;
	argstruct->av[0] = &(argstruct->arg1);
	pan_msg_consume(p, &(argstruct->arg1), sizeof(t_integer));
	argstruct->av[1] = &(argstruct->arg2);
	pan_msg_consume(p, &(argstruct->arg2), sizeof(t_integer));
	argstruct->av[2] = &(argstruct->arg3);
	pan_msg_consume(p, &(argstruct->arg3), sizeof(t_integer));
	argstruct->av[3] = &(argstruct->arg4);
	pan_msg_consume(p, &(argstruct->arg4), sizeof(t_integer));
}
static int sz_ret_Vogle__MapColor(void **argv) {
	int sz = 0;
	return sz;
}
static pan_iovec_p ma_ret_Vogle__MapColor(pan_iovec_p p, void **argv) {
	return p;
}
static void um_ret_Vogle__MapColor(void *p, void **argv) {
}
#else
static int sz_call_Vogle__MapColor(void **argv) {
	int sz = 0;
	sz += sizeof(t_integer);
	sz += sizeof(t_integer);
	sz += sizeof(t_integer);
	sz += sizeof(t_integer);
	return sz;
}
static char *ma_call_Vogle__MapColor(char *p, void **argv) {
	memcpy(p, argv[0], sizeof(t_integer));
	p += sizeof(t_integer);
	memcpy(p, argv[1], sizeof(t_integer));
	p += sizeof(t_integer);
	memcpy(p, argv[2], sizeof(t_integer));
	p += sizeof(t_integer);
	memcpy(p, argv[3], sizeof(t_integer));
	p += sizeof(t_integer);
	return p;
}
static char *um_call_Vogle__MapColor(char *p, void ***ap) {
	struct {
		void *av[4];
		t_integer arg1;
		t_integer arg2;
		t_integer arg3;
		t_integer arg4;
	} *argstruct;
	argstruct = m_malloc(sizeof(*argstruct));
	*ap = argstruct->av;
	argstruct->av[0] = &(argstruct->arg1);
	memcpy(&(argstruct->arg1), p, sizeof(t_integer));
	p += sizeof(t_integer);
	argstruct->av[1] = &(argstruct->arg2);
	memcpy(&(argstruct->arg2), p, sizeof(t_integer));
	p += sizeof(t_integer);
	argstruct->av[2] = &(argstruct->arg3);
	memcpy(&(argstruct->arg3), p, sizeof(t_integer));
	p += sizeof(t_integer);
	argstruct->av[3] = &(argstruct->arg4);
	memcpy(&(argstruct->arg4), p, sizeof(t_integer));
	p += sizeof(t_integer);
	return p;
}
static int sz_ret_Vogle__MapColor(void **argv) {
	int sz = 0;
	return sz;
}
static char *ma_ret_Vogle__MapColor(char *p, void **argv) {
	m_free((void *) argv);
	return p;
}
static char *um_ret_Vogle__MapColor(char *p, void **argv) {
	return p;
}
#endif
static void fr_ret_Vogle__MapColor(void **argv) {
	m_free((void *) argv);
}
#ifdef PANDA4
static int sz_call_Vogle__Ortho(void **argv) {
	int sz = 0;
	sz++;
	sz++;
	sz++;
	sz++;
	return sz;
}
static pan_iovec_p ma_call_Vogle__Ortho(pan_iovec_p p, void **argv) {
	p->data = argv[0];
	p->len = sizeof(t_real);
	p++;
	p->data = argv[1];
	p->len = sizeof(t_real);
	p++;
	p->data = argv[2];
	p->len = sizeof(t_real);
	p++;
	p->data = argv[3];
	p->len = sizeof(t_real);
	p++;
	return p;
}
static void um_call_Vogle__Ortho(void *p, void ***ap) {
	struct {
		void *av[4];
		t_real arg1;
		t_real arg2;
		t_real arg3;
		t_real arg4;
	} *argstruct;
	argstruct = m_malloc(sizeof(*argstruct));
	*ap = argstruct->av;
	argstruct->av[0] = &(argstruct->arg1);
	pan_msg_consume(p, &(argstruct->arg1), sizeof(t_real));
	argstruct->av[1] = &(argstruct->arg2);
	pan_msg_consume(p, &(argstruct->arg2), sizeof(t_real));
	argstruct->av[2] = &(argstruct->arg3);
	pan_msg_consume(p, &(argstruct->arg3), sizeof(t_real));
	argstruct->av[3] = &(argstruct->arg4);
	pan_msg_consume(p, &(argstruct->arg4), sizeof(t_real));
}
static int sz_ret_Vogle__Ortho(void **argv) {
	int sz = 0;
	return sz;
}
static pan_iovec_p ma_ret_Vogle__Ortho(pan_iovec_p p, void **argv) {
	return p;
}
static void um_ret_Vogle__Ortho(void *p, void **argv) {
}
#else
static int sz_call_Vogle__Ortho(void **argv) {
	int sz = 0;
	sz += sizeof(t_real);
	sz += sizeof(t_real);
	sz += sizeof(t_real);
	sz += sizeof(t_real);
	return sz;
}
static char *ma_call_Vogle__Ortho(char *p, void **argv) {
	memcpy(p, argv[0], sizeof(t_real));
	p += sizeof(t_real);
	memcpy(p, argv[1], sizeof(t_real));
	p += sizeof(t_real);
	memcpy(p, argv[2], sizeof(t_real));
	p += sizeof(t_real);
	memcpy(p, argv[3], sizeof(t_real));
	p += sizeof(t_real);
	return p;
}
static char *um_call_Vogle__Ortho(char *p, void ***ap) {
	struct {
		void *av[4];
		t_real arg1;
		t_real arg2;
		t_real arg3;
		t_real arg4;
	} *argstruct;
	argstruct = m_malloc(sizeof(*argstruct));
	*ap = argstruct->av;
	argstruct->av[0] = &(argstruct->arg1);
	memcpy(&(argstruct->arg1), p, sizeof(t_real));
	p += sizeof(t_real);
	argstruct->av[1] = &(argstruct->arg2);
	memcpy(&(argstruct->arg2), p, sizeof(t_real));
	p += sizeof(t_real);
	argstruct->av[2] = &(argstruct->arg3);
	memcpy(&(argstruct->arg3), p, sizeof(t_real));
	p += sizeof(t_real);
	argstruct->av[3] = &(argstruct->arg4);
	memcpy(&(argstruct->arg4), p, sizeof(t_real));
	p += sizeof(t_real);
	return p;
}
static int sz_ret_Vogle__Ortho(void **argv) {
	int sz = 0;
	return sz;
}
static char *ma_ret_Vogle__Ortho(char *p, void **argv) {
	m_free((void *) argv);
	return p;
}
static char *um_ret_Vogle__Ortho(char *p, void **argv) {
	return p;
}
#endif
static void fr_ret_Vogle__Ortho(void **argv) {
	m_free((void *) argv);
}
#ifdef PANDA4
static int sz_call_Vogle__Point(void **argv) {
	int sz = 0;
	sz++;
	sz++;
	sz++;
	return sz;
}
static pan_iovec_p ma_call_Vogle__Point(pan_iovec_p p, void **argv) {
	p->data = argv[0];
	p->len = sizeof(t_integer);
	p++;
	p->data = argv[1];
	p->len = sizeof(t_real);
	p++;
	p->data = argv[2];
	p->len = sizeof(t_real);
	p++;
	return p;
}
static void um_call_Vogle__Point(void *p, void ***ap) {
	struct {
		void *av[3];
		t_integer arg1;
		t_real arg2;
		t_real arg3;
	} *argstruct;
	argstruct = m_malloc(sizeof(*argstruct));
	*ap = argstruct->av;
	argstruct->av[0] = &(argstruct->arg1);
	pan_msg_consume(p, &(argstruct->arg1), sizeof(t_integer));
	argstruct->av[1] = &(argstruct->arg2);
	pan_msg_consume(p, &(argstruct->arg2), sizeof(t_real));
	argstruct->av[2] = &(argstruct->arg3);
	pan_msg_consume(p, &(argstruct->arg3), sizeof(t_real));
}
static int sz_ret_Vogle__Point(void **argv) {
	int sz = 0;
	return sz;
}
static pan_iovec_p ma_ret_Vogle__Point(pan_iovec_p p, void **argv) {
	return p;
}
static void um_ret_Vogle__Point(void *p, void **argv) {
}
#else
static int sz_call_Vogle__Point(void **argv) {
	int sz = 0;
	sz += sizeof(t_integer);
	sz += sizeof(t_real);
	sz += sizeof(t_real);
	return sz;
}
static char *ma_call_Vogle__Point(char *p, void **argv) {
	memcpy(p, argv[0], sizeof(t_integer));
	p += sizeof(t_integer);
	memcpy(p, argv[1], sizeof(t_real));
	p += sizeof(t_real);
	memcpy(p, argv[2], sizeof(t_real));
	p += sizeof(t_real);
	return p;
}
static char *um_call_Vogle__Point(char *p, void ***ap) {
	struct {
		void *av[3];
		t_integer arg1;
		t_real arg2;
		t_real arg3;
	} *argstruct;
	argstruct = m_malloc(sizeof(*argstruct));
	*ap = argstruct->av;
	argstruct->av[0] = &(argstruct->arg1);
	memcpy(&(argstruct->arg1), p, sizeof(t_integer));
	p += sizeof(t_integer);
	argstruct->av[1] = &(argstruct->arg2);
	memcpy(&(argstruct->arg2), p, sizeof(t_real));
	p += sizeof(t_real);
	argstruct->av[2] = &(argstruct->arg3);
	memcpy(&(argstruct->arg3), p, sizeof(t_real));
	p += sizeof(t_real);
	return p;
}
static int sz_ret_Vogle__Point(void **argv) {
	int sz = 0;
	return sz;
}
static char *ma_ret_Vogle__Point(char *p, void **argv) {
	m_free((void *) argv);
	return p;
}
static char *um_ret_Vogle__Point(char *p, void **argv) {
	return p;
}
#endif
static void fr_ret_Vogle__Point(void **argv) {
	m_free((void *) argv);
}
#ifdef PANDA4
static int sz_call_Vogle__PrefPosition(void **argv) {
	int sz = 0;
	sz++;
	sz++;
	return sz;
}
static pan_iovec_p ma_call_Vogle__PrefPosition(pan_iovec_p p, void **argv) {
	p->data = argv[0];
	p->len = sizeof(t_integer);
	p++;
	p->data = argv[1];
	p->len = sizeof(t_integer);
	p++;
	return p;
}
static void um_call_Vogle__PrefPosition(void *p, void ***ap) {
	struct {
		void *av[2];
		t_integer arg1;
		t_integer arg2;
	} *argstruct;
	argstruct = m_malloc(sizeof(*argstruct));
	*ap = argstruct->av;
	argstruct->av[0] = &(argstruct->arg1);
	pan_msg_consume(p, &(argstruct->arg1), sizeof(t_integer));
	argstruct->av[1] = &(argstruct->arg2);
	pan_msg_consume(p, &(argstruct->arg2), sizeof(t_integer));
}
static int sz_ret_Vogle__PrefPosition(void **argv) {
	int sz = 0;
	return sz;
}
static pan_iovec_p ma_ret_Vogle__PrefPosition(pan_iovec_p p, void **argv) {
	return p;
}
static void um_ret_Vogle__PrefPosition(void *p, void **argv) {
}
#else
static int sz_call_Vogle__PrefPosition(void **argv) {
	int sz = 0;
	sz += sizeof(t_integer);
	sz += sizeof(t_integer);
	return sz;
}
static char *ma_call_Vogle__PrefPosition(char *p, void **argv) {
	memcpy(p, argv[0], sizeof(t_integer));
	p += sizeof(t_integer);
	memcpy(p, argv[1], sizeof(t_integer));
	p += sizeof(t_integer);
	return p;
}
static char *um_call_Vogle__PrefPosition(char *p, void ***ap) {
	struct {
		void *av[2];
		t_integer arg1;
		t_integer arg2;
	} *argstruct;
	argstruct = m_malloc(sizeof(*argstruct));
	*ap = argstruct->av;
	argstruct->av[0] = &(argstruct->arg1);
	memcpy(&(argstruct->arg1), p, sizeof(t_integer));
	p += sizeof(t_integer);
	argstruct->av[1] = &(argstruct->arg2);
	memcpy(&(argstruct->arg2), p, sizeof(t_integer));
	p += sizeof(t_integer);
	return p;
}
static int sz_ret_Vogle__PrefPosition(void **argv) {
	int sz = 0;
	return sz;
}
static char *ma_ret_Vogle__PrefPosition(char *p, void **argv) {
	m_free((void *) argv);
	return p;
}
static char *um_ret_Vogle__PrefPosition(char *p, void **argv) {
	return p;
}
#endif
static void fr_ret_Vogle__PrefPosition(void **argv) {
	m_free((void *) argv);
}
#ifdef PANDA4
static int sz_call_Vogle__PrefSize(void **argv) {
	int sz = 0;
	sz++;
	sz++;
	return sz;
}
static pan_iovec_p ma_call_Vogle__PrefSize(pan_iovec_p p, void **argv) {
	p->data = argv[0];
	p->len = sizeof(t_integer);
	p++;
	p->data = argv[1];
	p->len = sizeof(t_integer);
	p++;
	return p;
}
static void um_call_Vogle__PrefSize(void *p, void ***ap) {
	struct {
		void *av[2];
		t_integer arg1;
		t_integer arg2;
	} *argstruct;
	argstruct = m_malloc(sizeof(*argstruct));
	*ap = argstruct->av;
	argstruct->av[0] = &(argstruct->arg1);
	pan_msg_consume(p, &(argstruct->arg1), sizeof(t_integer));
	argstruct->av[1] = &(argstruct->arg2);
	pan_msg_consume(p, &(argstruct->arg2), sizeof(t_integer));
}
static int sz_ret_Vogle__PrefSize(void **argv) {
	int sz = 0;
	return sz;
}
static pan_iovec_p ma_ret_Vogle__PrefSize(pan_iovec_p p, void **argv) {
	return p;
}
static void um_ret_Vogle__PrefSize(void *p, void **argv) {
}
#else
static int sz_call_Vogle__PrefSize(void **argv) {
	int sz = 0;
	sz += sizeof(t_integer);
	sz += sizeof(t_integer);
	return sz;
}
static char *ma_call_Vogle__PrefSize(char *p, void **argv) {
	memcpy(p, argv[0], sizeof(t_integer));
	p += sizeof(t_integer);
	memcpy(p, argv[1], sizeof(t_integer));
	p += sizeof(t_integer);
	return p;
}
static char *um_call_Vogle__PrefSize(char *p, void ***ap) {
	struct {
		void *av[2];
		t_integer arg1;
		t_integer arg2;
	} *argstruct;
	argstruct = m_malloc(sizeof(*argstruct));
	*ap = argstruct->av;
	argstruct->av[0] = &(argstruct->arg1);
	memcpy(&(argstruct->arg1), p, sizeof(t_integer));
	p += sizeof(t_integer);
	argstruct->av[1] = &(argstruct->arg2);
	memcpy(&(argstruct->arg2), p, sizeof(t_integer));
	p += sizeof(t_integer);
	return p;
}
static int sz_ret_Vogle__PrefSize(void **argv) {
	int sz = 0;
	return sz;
}
static char *ma_ret_Vogle__PrefSize(char *p, void **argv) {
	m_free((void *) argv);
	return p;
}
static char *um_ret_Vogle__PrefSize(char *p, void **argv) {
	return p;
}
#endif
static void fr_ret_Vogle__PrefSize(void **argv) {
	m_free((void *) argv);
}
#ifdef PANDA4
static int sz_call_Vogle__Rect(void **argv) {
	int sz = 0;
	sz++;
	sz++;
	sz++;
	sz++;
	sz++;
	sz++;
	return sz;
}
static pan_iovec_p ma_call_Vogle__Rect(pan_iovec_p p, void **argv) {
	p->data = argv[0];
	p->len = sizeof(t_integer);
	p++;
	p->data = argv[1];
	p->len = sizeof(t_boolean);
	p++;
	p->data = argv[2];
	p->len = sizeof(t_real);
	p++;
	p->data = argv[3];
	p->len = sizeof(t_real);
	p++;
	p->data = argv[4];
	p->len = sizeof(t_real);
	p++;
	p->data = argv[5];
	p->len = sizeof(t_real);
	p++;
	return p;
}
static void um_call_Vogle__Rect(void *p, void ***ap) {
	struct {
		void *av[6];
		t_integer arg1;
		t_boolean arg2;
		t_real arg3;
		t_real arg4;
		t_real arg5;
		t_real arg6;
	} *argstruct;
	argstruct = m_malloc(sizeof(*argstruct));
	*ap = argstruct->av;
	argstruct->av[0] = &(argstruct->arg1);
	pan_msg_consume(p, &(argstruct->arg1), sizeof(t_integer));
	argstruct->av[1] = &(argstruct->arg2);
	pan_msg_consume(p, &(argstruct->arg2), sizeof(t_boolean));
	argstruct->av[2] = &(argstruct->arg3);
	pan_msg_consume(p, &(argstruct->arg3), sizeof(t_real));
	argstruct->av[3] = &(argstruct->arg4);
	pan_msg_consume(p, &(argstruct->arg4), sizeof(t_real));
	argstruct->av[4] = &(argstruct->arg5);
	pan_msg_consume(p, &(argstruct->arg5), sizeof(t_real));
	argstruct->av[5] = &(argstruct->arg6);
	pan_msg_consume(p, &(argstruct->arg6), sizeof(t_real));
}
static int sz_ret_Vogle__Rect(void **argv) {
	int sz = 0;
	return sz;
}
static pan_iovec_p ma_ret_Vogle__Rect(pan_iovec_p p, void **argv) {
	return p;
}
static void um_ret_Vogle__Rect(void *p, void **argv) {
}
#else
static int sz_call_Vogle__Rect(void **argv) {
	int sz = 0;
	sz += sizeof(t_integer);
	sz += sizeof(t_boolean);
	sz += sizeof(t_real);
	sz += sizeof(t_real);
	sz += sizeof(t_real);
	sz += sizeof(t_real);
	return sz;
}
static char *ma_call_Vogle__Rect(char *p, void **argv) {
	memcpy(p, argv[0], sizeof(t_integer));
	p += sizeof(t_integer);
	memcpy(p, argv[1], sizeof(t_boolean));
	p += sizeof(t_boolean);
	memcpy(p, argv[2], sizeof(t_real));
	p += sizeof(t_real);
	memcpy(p, argv[3], sizeof(t_real));
	p += sizeof(t_real);
	memcpy(p, argv[4], sizeof(t_real));
	p += sizeof(t_real);
	memcpy(p, argv[5], sizeof(t_real));
	p += sizeof(t_real);
	return p;
}
static char *um_call_Vogle__Rect(char *p, void ***ap) {
	struct {
		void *av[6];
		t_integer arg1;
		t_boolean arg2;
		t_real arg3;
		t_real arg4;
		t_real arg5;
		t_real arg6;
	} *argstruct;
	argstruct = m_malloc(sizeof(*argstruct));
	*ap = argstruct->av;
	argstruct->av[0] = &(argstruct->arg1);
	memcpy(&(argstruct->arg1), p, sizeof(t_integer));
	p += sizeof(t_integer);
	argstruct->av[1] = &(argstruct->arg2);
	memcpy(&(argstruct->arg2), p, sizeof(t_boolean));
	p += sizeof(t_boolean);
	argstruct->av[2] = &(argstruct->arg3);
	memcpy(&(argstruct->arg3), p, sizeof(t_real));
	p += sizeof(t_real);
	argstruct->av[3] = &(argstruct->arg4);
	memcpy(&(argstruct->arg4), p, sizeof(t_real));
	p += sizeof(t_real);
	argstruct->av[4] = &(argstruct->arg5);
	memcpy(&(argstruct->arg5), p, sizeof(t_real));
	p += sizeof(t_real);
	argstruct->av[5] = &(argstruct->arg6);
	memcpy(&(argstruct->arg6), p, sizeof(t_real));
	p += sizeof(t_real);
	return p;
}
static int sz_ret_Vogle__Rect(void **argv) {
	int sz = 0;
	return sz;
}
static char *ma_ret_Vogle__Rect(char *p, void **argv) {
	m_free((void *) argv);
	return p;
}
static char *um_ret_Vogle__Rect(char *p, void **argv) {
	return p;
}
#endif
static void fr_ret_Vogle__Rect(void **argv) {
	m_free((void *) argv);
}
#ifdef PANDA4
static int sz_call_Vogle__SwapBuffers(void **argv) {
	int sz = 0;
	return sz;
}
static pan_iovec_p ma_call_Vogle__SwapBuffers(pan_iovec_p p, void **argv) {
	return p;
}
static void um_call_Vogle__SwapBuffers(void *p, void ***ap) {
	*ap = 0;
}
static int sz_ret_Vogle__SwapBuffers(void **argv) {
	int sz = 0;
	return sz;
}
static pan_iovec_p ma_ret_Vogle__SwapBuffers(pan_iovec_p p, void **argv) {
	return p;
}
static void um_ret_Vogle__SwapBuffers(void *p, void **argv) {
}
#else
static int sz_call_Vogle__SwapBuffers(void **argv) {
	int sz = 0;
	return sz;
}
static char *ma_call_Vogle__SwapBuffers(char *p, void **argv) {
	return p;
}
static char *um_call_Vogle__SwapBuffers(char *p, void ***ap) {
	*ap = 0;
	return p;
}
static int sz_ret_Vogle__SwapBuffers(void **argv) {
	int sz = 0;
	return sz;
}
static char *ma_ret_Vogle__SwapBuffers(char *p, void **argv) {
	m_free((void *) argv);
	return p;
}
static char *um_ret_Vogle__SwapBuffers(char *p, void **argv) {
	return p;
}
#endif
static void fr_ret_Vogle__SwapBuffers(void **argv) {
	m_free((void *) argv);
}
#ifdef PANDA4
static int sz_call_Vogle__VsetFlush(void **argv) {
	int sz = 0;
	sz++;
	return sz;
}
static pan_iovec_p ma_call_Vogle__VsetFlush(pan_iovec_p p, void **argv) {
	p->data = argv[0];
	p->len = sizeof(t_boolean);
	p++;
	return p;
}
static void um_call_Vogle__VsetFlush(void *p, void ***ap) {
	struct {
		void *av[1];
		t_boolean arg1;
	} *argstruct;
	argstruct = m_malloc(sizeof(*argstruct));
	*ap = argstruct->av;
	argstruct->av[0] = &(argstruct->arg1);
	pan_msg_consume(p, &(argstruct->arg1), sizeof(t_boolean));
}
static int sz_ret_Vogle__VsetFlush(void **argv) {
	int sz = 0;
	return sz;
}
static pan_iovec_p ma_ret_Vogle__VsetFlush(pan_iovec_p p, void **argv) {
	return p;
}
static void um_ret_Vogle__VsetFlush(void *p, void **argv) {
}
#else
static int sz_call_Vogle__VsetFlush(void **argv) {
	int sz = 0;
	sz += sizeof(t_boolean);
	return sz;
}
static char *ma_call_Vogle__VsetFlush(char *p, void **argv) {
	memcpy(p, argv[0], sizeof(t_boolean));
	p += sizeof(t_boolean);
	return p;
}
static char *um_call_Vogle__VsetFlush(char *p, void ***ap) {
	struct {
		void *av[1];
		t_boolean arg1;
	} *argstruct;
	argstruct = m_malloc(sizeof(*argstruct));
	*ap = argstruct->av;
	argstruct->av[0] = &(argstruct->arg1);
	memcpy(&(argstruct->arg1), p, sizeof(t_boolean));
	p += sizeof(t_boolean);
	return p;
}
static int sz_ret_Vogle__VsetFlush(void **argv) {
	int sz = 0;
	return sz;
}
static char *ma_ret_Vogle__VsetFlush(char *p, void **argv) {
	m_free((void *) argv);
	return p;
}
static char *um_ret_Vogle__VsetFlush(char *p, void **argv) {
	return p;
}
#endif
static void fr_ret_Vogle__VsetFlush(void **argv) {
	m_free((void *) argv);
}
#ifdef PANDA4
static int sz_call_Vogle__Vflush(void **argv) {
	int sz = 0;
	return sz;
}
static pan_iovec_p ma_call_Vogle__Vflush(pan_iovec_p p, void **argv) {
	return p;
}
static void um_call_Vogle__Vflush(void *p, void ***ap) {
	*ap = 0;
}
static int sz_ret_Vogle__Vflush(void **argv) {
	int sz = 0;
	return sz;
}
static pan_iovec_p ma_ret_Vogle__Vflush(pan_iovec_p p, void **argv) {
	return p;
}
static void um_ret_Vogle__Vflush(void *p, void **argv) {
}
#else
static int sz_call_Vogle__Vflush(void **argv) {
	int sz = 0;
	return sz;
}
static char *ma_call_Vogle__Vflush(char *p, void **argv) {
	return p;
}
static char *um_call_Vogle__Vflush(char *p, void ***ap) {
	*ap = 0;
	return p;
}
static int sz_ret_Vogle__Vflush(void **argv) {
	int sz = 0;
	return sz;
}
static char *ma_ret_Vogle__Vflush(char *p, void **argv) {
	m_free((void *) argv);
	return p;
}
static char *um_ret_Vogle__Vflush(char *p, void **argv) {
	return p;
}
#endif
static void fr_ret_Vogle__Vflush(void **argv) {
	m_free((void *) argv);
}
#ifdef PANDA4
static int sz_call_Vogle__Draw(void **argv) {
	int sz = 0;
	sz++;
	sz++;
	return sz;
}
static pan_iovec_p ma_call_Vogle__Draw(pan_iovec_p p, void **argv) {
	p->data = argv[0];
	p->len = sizeof(t_real);
	p++;
	p->data = argv[1];
	p->len = sizeof(t_real);
	p++;
	return p;
}
static void um_call_Vogle__Draw(void *p, void ***ap) {
	struct {
		void *av[2];
		t_real arg1;
		t_real arg2;
	} *argstruct;
	argstruct = m_malloc(sizeof(*argstruct));
	*ap = argstruct->av;
	argstruct->av[0] = &(argstruct->arg1);
	pan_msg_consume(p, &(argstruct->arg1), sizeof(t_real));
	argstruct->av[1] = &(argstruct->arg2);
	pan_msg_consume(p, &(argstruct->arg2), sizeof(t_real));
}
static int sz_ret_Vogle__Draw(void **argv) {
	int sz = 0;
	return sz;
}
static pan_iovec_p ma_ret_Vogle__Draw(pan_iovec_p p, void **argv) {
	return p;
}
static void um_ret_Vogle__Draw(void *p, void **argv) {
}
#else
static int sz_call_Vogle__Draw(void **argv) {
	int sz = 0;
	sz += sizeof(t_real);
	sz += sizeof(t_real);
	return sz;
}
static char *ma_call_Vogle__Draw(char *p, void **argv) {
	memcpy(p, argv[0], sizeof(t_real));
	p += sizeof(t_real);
	memcpy(p, argv[1], sizeof(t_real));
	p += sizeof(t_real);
	return p;
}
static char *um_call_Vogle__Draw(char *p, void ***ap) {
	struct {
		void *av[2];
		t_real arg1;
		t_real arg2;
	} *argstruct;
	argstruct = m_malloc(sizeof(*argstruct));
	*ap = argstruct->av;
	argstruct->av[0] = &(argstruct->arg1);
	memcpy(&(argstruct->arg1), p, sizeof(t_real));
	p += sizeof(t_real);
	argstruct->av[1] = &(argstruct->arg2);
	memcpy(&(argstruct->arg2), p, sizeof(t_real));
	p += sizeof(t_real);
	return p;
}
static int sz_ret_Vogle__Draw(void **argv) {
	int sz = 0;
	return sz;
}
static char *ma_ret_Vogle__Draw(char *p, void **argv) {
	m_free((void *) argv);
	return p;
}
static char *um_ret_Vogle__Draw(char *p, void **argv) {
	return p;
}
#endif
static void fr_ret_Vogle__Draw(void **argv) {
	m_free((void *) argv);
}
static op_dscr od_Vogle__Vogle[] = {
	{ or__Vogle__READ_, 0, &td_Vogle__2, 0, 0, "Vogle.READ_",
	  sz_call_Vogle__READ_, ma_call_Vogle__READ_, um_call_Vogle__READ_, sz_ret_Vogle__READ_, ma_ret_Vogle__READ_, um_ret_Vogle__READ_, fr_ret_Vogle__READ_},
	{ 0, ow__Vogle__WRITE_, &td_Vogle__3, 1, OP_PURE_WRITE, "Vogle.WRITE_",
	  sz_call_Vogle__WRITE_, ma_call_Vogle__WRITE_, um_call_Vogle__WRITE_, sz_ret_Vogle__WRITE_, ma_ret_Vogle__WRITE_, um_ret_Vogle__WRITE_, fr_ret_Vogle__WRITE_},
	{ or__Vogle__BackBuffer, 0, &td_Vogle__BackBuffer, 2, 0, "Vogle.BackBuffer",
	  sz_call_Vogle__BackBuffer, ma_call_Vogle__BackBuffer, um_call_Vogle__BackBuffer, sz_ret_Vogle__BackBuffer, ma_ret_Vogle__BackBuffer, um_ret_Vogle__BackBuffer, fr_ret_Vogle__BackBuffer},
	{ or__Vogle__Circle, 0, &td_Vogle__Circle, 3, OP_PURE_WRITE, "Vogle.Circle",
	  sz_call_Vogle__Circle, ma_call_Vogle__Circle, um_call_Vogle__Circle, sz_ret_Vogle__Circle, ma_ret_Vogle__Circle, um_ret_Vogle__Circle, fr_ret_Vogle__Circle},
	{ or__Vogle__Circle_Seg, 0, &td_Vogle__Circle_Seg, 4, OP_PURE_WRITE, "Vogle.Circle_Seg",
	  sz_call_Vogle__Circle_Seg, ma_call_Vogle__Circle_Seg, um_call_Vogle__Circle_Seg, sz_ret_Vogle__Circle_Seg, ma_ret_Vogle__Circle_Seg, um_ret_Vogle__Circle_Seg, fr_ret_Vogle__Circle_Seg},
	{ or__Vogle__Clear, 0, &td_Vogle__Clear, 5, OP_PURE_WRITE, "Vogle.Clear",
	  sz_call_Vogle__Clear, ma_call_Vogle__Clear, um_call_Vogle__Clear, sz_ret_Vogle__Clear, ma_ret_Vogle__Clear, um_ret_Vogle__Clear, fr_ret_Vogle__Clear},
	{ or__Vogle__Color, 0, &td_Vogle__Color, 6, OP_PURE_WRITE, "Vogle.Color",
	  sz_call_Vogle__Color, ma_call_Vogle__Color, um_call_Vogle__Color, sz_ret_Vogle__Color, ma_ret_Vogle__Color, um_ret_Vogle__Color, fr_ret_Vogle__Color},
	{ or__Vogle__DrawStr, 0, &td_Vogle__DrawStr, 7, OP_PURE_WRITE, "Vogle.DrawStr",
	  sz_call_Vogle__DrawStr, ma_call_Vogle__DrawStr, um_call_Vogle__DrawStr, sz_ret_Vogle__DrawStr, ma_ret_Vogle__DrawStr, um_ret_Vogle__DrawStr, fr_ret_Vogle__DrawStr},
	{ or__Vogle__Exit, 0, &td_Vogle__Exit, 8, OP_PURE_WRITE, "Vogle.Exit",
	  sz_call_Vogle__Exit, ma_call_Vogle__Exit, um_call_Vogle__Exit, sz_ret_Vogle__Exit, ma_ret_Vogle__Exit, um_ret_Vogle__Exit, fr_ret_Vogle__Exit},
	{ or__Vogle__Init, 0, &td_Vogle__Init, 9, OP_PURE_WRITE, "Vogle.Init",
	  sz_call_Vogle__Init, ma_call_Vogle__Init, um_call_Vogle__Init, sz_ret_Vogle__Init, ma_ret_Vogle__Init, um_ret_Vogle__Init, fr_ret_Vogle__Init},
	{ or__Vogle__Line, 0, &td_Vogle__Line, 10, OP_PURE_WRITE, "Vogle.Line",
	  sz_call_Vogle__Line, ma_call_Vogle__Line, um_call_Vogle__Line, sz_ret_Vogle__Line, ma_ret_Vogle__Line, um_ret_Vogle__Line, fr_ret_Vogle__Line},
	{ or__Vogle__MapColor, 0, &td_Vogle__MapColor, 11, OP_PURE_WRITE, "Vogle.MapColor",
	  sz_call_Vogle__MapColor, ma_call_Vogle__MapColor, um_call_Vogle__MapColor, sz_ret_Vogle__MapColor, ma_ret_Vogle__MapColor, um_ret_Vogle__MapColor, fr_ret_Vogle__MapColor},
	{ or__Vogle__Ortho, 0, &td_Vogle__Ortho, 12, OP_PURE_WRITE, "Vogle.Ortho",
	  sz_call_Vogle__Ortho, ma_call_Vogle__Ortho, um_call_Vogle__Ortho, sz_ret_Vogle__Ortho, ma_ret_Vogle__Ortho, um_ret_Vogle__Ortho, fr_ret_Vogle__Ortho},
	{ or__Vogle__Point, 0, &td_Vogle__Point, 13, OP_PURE_WRITE, "Vogle.Point",
	  sz_call_Vogle__Point, ma_call_Vogle__Point, um_call_Vogle__Point, sz_ret_Vogle__Point, ma_ret_Vogle__Point, um_ret_Vogle__Point, fr_ret_Vogle__Point},
	{ or__Vogle__PrefPosition, 0, &td_Vogle__PrefPosition, 14, OP_PURE_WRITE, "Vogle.PrefPosition",
	  sz_call_Vogle__PrefPosition, ma_call_Vogle__PrefPosition, um_call_Vogle__PrefPosition, sz_ret_Vogle__PrefPosition, ma_ret_Vogle__PrefPosition, um_ret_Vogle__PrefPosition, fr_ret_Vogle__PrefPosition},
	{ or__Vogle__PrefSize, 0, &td_Vogle__PrefSize, 15, OP_PURE_WRITE, "Vogle.PrefSize",
	  sz_call_Vogle__PrefSize, ma_call_Vogle__PrefSize, um_call_Vogle__PrefSize, sz_ret_Vogle__PrefSize, ma_ret_Vogle__PrefSize, um_ret_Vogle__PrefSize, fr_ret_Vogle__PrefSize},
	{ or__Vogle__Rect, 0, &td_Vogle__Rect, 16, OP_PURE_WRITE, "Vogle.Rect",
	  sz_call_Vogle__Rect, ma_call_Vogle__Rect, um_call_Vogle__Rect, sz_ret_Vogle__Rect, ma_ret_Vogle__Rect, um_ret_Vogle__Rect, fr_ret_Vogle__Rect},
	{ or__Vogle__SwapBuffers, 0, &td_Vogle__SwapBuffers, 17, OP_PURE_WRITE, "Vogle.SwapBuffers",
	  sz_call_Vogle__SwapBuffers, ma_call_Vogle__SwapBuffers, um_call_Vogle__SwapBuffers, sz_ret_Vogle__SwapBuffers, ma_ret_Vogle__SwapBuffers, um_ret_Vogle__SwapBuffers, fr_ret_Vogle__SwapBuffers},
	{ or__Vogle__VsetFlush, 0, &td_Vogle__VsetFlush, 18, OP_PURE_WRITE, "Vogle.VsetFlush",
	  sz_call_Vogle__VsetFlush, ma_call_Vogle__VsetFlush, um_call_Vogle__VsetFlush, sz_ret_Vogle__VsetFlush, ma_ret_Vogle__VsetFlush, um_ret_Vogle__VsetFlush, fr_ret_Vogle__VsetFlush},
	{ or__Vogle__Vflush, 0, &td_Vogle__Vflush, 19, OP_PURE_WRITE, "Vogle.Vflush",
	  sz_call_Vogle__Vflush, ma_call_Vogle__Vflush, um_call_Vogle__Vflush, sz_ret_Vogle__Vflush, ma_ret_Vogle__Vflush, um_ret_Vogle__Vflush, fr_ret_Vogle__Vflush},
	{ or__Vogle__Draw, 0, &td_Vogle__Draw, 20, OP_PURE_WRITE, "Vogle.Draw",
	  sz_call_Vogle__Draw, ma_call_Vogle__Draw, um_call_Vogle__Draw, sz_ret_Vogle__Draw, ma_ret_Vogle__Draw, um_ret_Vogle__Draw, fr_ret_Vogle__Draw}
};
static int sz_obj_Vogle__Vogle(t_object *op) {
#ifdef PANDA4
    return 1;
#else
    return sizeof(t_Vogle__1);
#endif
}
#ifdef PANDA4
static pan_iovec_p ma_obj_Vogle__Vogle(pan_iovec_p p, t_object *op) {
#else
static char *ma_obj_Vogle__Vogle(char *p, t_object *op) {
#endif
#ifdef PANDA4
    p->data = op->o_fields;
    p->len = sizeof(t_Vogle__1);
    return p+1;
#else
    memcpy(p, op->o_fields, sizeof(t_Vogle__1));
    return p + sizeof(t_Vogle__1);
#endif
}
#ifdef PANDA4
static void um_obj_Vogle__Vogle(void *p, t_object *op) {
#else
static char *um_obj_Vogle__Vogle(char *p, t_object *op) {
#endif
    if (! op->o_fields) op->o_fields = m_malloc(sizeof(t_Vogle__1));
#ifdef PANDA4
    pan_msg_consume(p, op->o_fields, sizeof(t_Vogle__1));
#else
    memcpy(op->o_fields, p, sizeof(t_Vogle__1));
    return p + sizeof(t_Vogle__1);
#endif
}
static obj_info oi_Vogle__Vogle = { sz_obj_Vogle__Vogle, ma_obj_Vogle__Vogle, um_obj_Vogle__Vogle, 0, od_Vogle__Vogle };
tp_dscr td_Vogle__Vogle = { OBJECT, sizeof(t_Vogle__Vogle), 15, &td_Vogle__1, 21, &oi_Vogle__Vogle};
#ifdef PANDA4
int sz_Vogle__Vogle(t_Vogle__Vogle *a) {
    int sz = 0;
    sz = o_rts_nbytes(a, &td_Vogle__Vogle);
    sz ++;
    return sz;
}

pan_iovec_p ma_Vogle__Vogle(pan_iovec_p p, t_Vogle__Vogle *a) {
    p = o_rts_marshall(p, a, &td_Vogle__Vogle);
    p->data = a->o_fields;
    p->len = sizeof(t_Vogle__1);
    p++;
    return p;
}

void um_Vogle__Vogle(void *p, t_Vogle__Vogle *a) {
    o_rts_unmarshall(p, a, &td_Vogle__Vogle);
    a->o_fields = m_malloc(sizeof(t_Vogle__1));
    pan_msg_consume(p, a->o_fields, sizeof(t_Vogle__1));
}

#else
int sz_Vogle__Vogle(t_Vogle__Vogle *a) {
    int sz;
    sz = o_rts_nbytes(a, &td_Vogle__Vogle);
    sz += sizeof(t_Vogle__1);
    return sz;
}

char *ma_Vogle__Vogle(char *p, t_Vogle__Vogle *a) {
    p = o_rts_marshall(p, a, &td_Vogle__Vogle);
    memcpy(p, a->o_fields, sizeof(t_Vogle__1));
    p += sizeof(t_Vogle__1);
    return p;
}

char *um_Vogle__Vogle(char *p, t_Vogle__Vogle *a) {
    p = o_rts_unmarshall(p, a, &td_Vogle__Vogle);
    a->o_fields = m_malloc(sizeof(t_Vogle__1));
    memcpy(a->o_fields, p, sizeof(t_Vogle__1));
    p += sizeof(t_Vogle__1);
    return p;
}

#endif
void free_Vogle__Vogle(void *d) {
    t_Vogle__Vogle *dst = d;
    if (dst->o_fields && o_free(dst)) {
        m_free(dst->o_fields);
    }
}
void ass_Vogle__Vogle(void *dd, void *ss) {
    t_Vogle__Vogle *dst = dd, *src = ss;
    int op_flags = 0;
    t_object tmp;
    void *argv[1];
    int src_local;
    int dst_local;

    if (dst == src) return;
    argv[0] = &tmp;
    if (! dst->o_fields) {
        dst->o_fields = m_malloc(sizeof(t_Vogle__1));
        memset(dst->o_fields, 0, sizeof(t_Vogle__1));
        o_init_rtsdep(dst, &td_Vogle__Vogle, (char *) 0);
    }
    src_local = ! o_isshared(src);
    dst_local = ! o_isshared(dst);
    if (dst_local && (src_local || o_start_read(src))) {
        ass_Vogle__1(dst->o_fields, src->o_fields);
        if (! src_local) o_end_read(src);
        return;
    }
    if (src_local && (dst_local || o_start_write(dst))) {
        ass_Vogle__1(dst->o_fields, src->o_fields);
        if (! dst_local) o_end_write(dst, 1);
        return;
    }
    tmp.o_fields = m_malloc(sizeof(t_Vogle__1));
    memset(tmp.o_fields, 0, sizeof(t_Vogle__1));
    o_init_rtsdep(&tmp, &td_Vogle__Vogle, (char *) 0);
    if (src_local || o_start_read(src)) {
        ass_Vogle__1(tmp.o_fields, src->o_fields);
        if (! src_local) o_end_read(src);
    } else {
        DoOperation(src, &op_flags, &td_Vogle__Vogle, /* READOBJ */ 0, 0, argv);
    }
    if (dst_local || o_start_write(dst)) {
        ass_Vogle__1(dst->o_fields, tmp.o_fields);
        if (! dst_local) o_end_write(dst, 1);
    } else {
        DoOperation(dst, &op_flags, &td_Vogle__Vogle, /* WRITEOBJ */ 1, 0, argv);
    }
    o_free(&tmp);
    m_free(tmp.o_fields);
}
char *fn_Vogle__Vogle = "Vogle.imp";
static void or_Vogle__Draw(t_Vogle__Vogle *v__obj, t_real v_x, t_real v_y);
t_boolean or_Vogle__BackBuffer(t_Vogle__Vogle *v__obj) {
    t_boolean v__result = 0;
    t_Vogle__1 *v__ofldp = v__obj->o_fields;
    if ((f_Xd__BackBuffer()==((t_integer) -1L))) {
        (v__result) = ((t_boolean) 0L);
        goto retlab;
    } else {
        (v__result) = ((t_boolean) 1L);
        goto retlab;
    }
    m_trap(FALL_THROUGH, fn_Vogle__Vogle, 322);
retlab:;
    return v__result;
}
void or_Vogle__Circle(t_Vogle__Vogle *v__obj, t_integer v_col, t_boolean v_polyfill, t_real v_x, t_real v_y, t_real v_radius) {
    t_Vogle__1 *v__ofldp = v__obj->o_fields;
    f_Xd__CirclePrecision(((t_integer) 32L));
    f_Xd__Color(v_col);
    f_Xd__PolyFill(v_polyfill);
    f_Xd__Circle(v_x, v_y, v_radius);
}
void or_Vogle__Circle_Seg(t_Vogle__Vogle *v__obj, t_integer v_col, t_boolean v_polyfill, t_integer v_nsegs, t_real v_x, t_real v_y, t_real v_radius) {
    t_Vogle__1 *v__ofldp = v__obj->o_fields;
    f_Xd__CirclePrecision(v_nsegs);
    f_Xd__Color(v_col);
    f_Xd__PolyFill(v_polyfill);
    f_Xd__Circle(v_x, v_y, v_radius);
    f_Xd__CirclePrecision(((t_integer) 32L));
}
void or_Vogle__Clear(t_Vogle__Vogle *v__obj, t_integer v_col) {
    t_Vogle__1 *v__ofldp = v__obj->o_fields;
    f_Xd__Color(v_col);
    f_Xd__Clear();
}
void or_Vogle__Color(t_Vogle__Vogle *v__obj, t_integer v_col) {
    t_Vogle__1 *v__ofldp = v__obj->o_fields;
    f_Xd__Color(v_col);
}
void or_Vogle__DrawStr(t_Vogle__Vogle *v__obj, t_integer v_col, t_real v_x, t_real v_y, t_string *v_str) {
    t_Vogle__1 *v__ofldp = v__obj->o_fields;
    f_Xd__Color(v_col);
    f_Xd__Move2(v_x, v_y);
    f_Xd__DrawStr(v_str);
}
void or_Vogle__Exit(t_Vogle__Vogle *v__obj) {
    t_Vogle__1 *v__ofldp = v__obj->o_fields;
    f_Xd__X_Exit();
}
void or_Vogle__Init(t_Vogle__Vogle *v__obj) {
    t_Vogle__1 *v__ofldp = v__obj->o_fields;
    f_Xd__X_Init();
}
void or_Vogle__Line(t_Vogle__Vogle *v__obj, t_integer v_col, t_real v_x1, t_real v_y1, t_real v_x2, t_real v_y2) {
    t_Vogle__1 *v__ofldp = v__obj->o_fields;
    f_Xd__Color(v_col);
    f_Xd__Move2(v_x1, v_y1);
    f_Xd__Draw2(v_x2, v_y2);
}
void or_Vogle__MapColor(t_Vogle__Vogle *v__obj, t_integer v_index, t_integer v_red, t_integer v_green, t_integer v_blue) {
    t_Vogle__1 *v__ofldp = v__obj->o_fields;
    f_Xd__MapColor(v_index, v_red, v_green, v_blue);
}
void or_Vogle__Ortho(t_Vogle__Vogle *v__obj, t_real v_left, t_real v_right, t_real v_bottom, t_real v_top) {
    t_Vogle__1 *v__ofldp = v__obj->o_fields;
    f_Xd__Ortho2(v_left, v_right, v_bottom, v_top);
}
void or_Vogle__Point(t_Vogle__Vogle *v__obj, t_integer v_col, t_real v_x, t_real v_y) {
    t_Vogle__1 *v__ofldp = v__obj->o_fields;
    f_Xd__Color(v_col);
    f_Xd__Point2(v_x, v_y);
}
void or_Vogle__PrefPosition(t_Vogle__Vogle *v__obj, t_integer v_x, t_integer v_y) {
    t_Vogle__1 *v__ofldp = v__obj->o_fields;
    f_Xd__PrefPosition(v_x, v_y);
}
void or_Vogle__PrefSize(t_Vogle__Vogle *v__obj, t_integer v_width, t_integer v_height) {
    t_Vogle__1 *v__ofldp = v__obj->o_fields;
    f_Xd__PrefSize(v_width, v_height);
}
void or_Vogle__Rect(t_Vogle__Vogle *v__obj, t_integer v_col, t_boolean v_polyfill, t_real v_x1, t_real v_y1, t_real v_x2, t_real v_y2) {
    t_Vogle__1 *v__ofldp = v__obj->o_fields;
    f_Xd__Color(v_col);
    f_Xd__PolyFill(v_polyfill);
    f_Xd__Rect(v_x1, v_y1, v_x2, v_y2);
}
void or_Vogle__SwapBuffers(t_Vogle__Vogle *v__obj) {
    t_Vogle__1 *v__ofldp = v__obj->o_fields;
    f_Xd__SwapBuffers();
}
void or_Vogle__VsetFlush(t_Vogle__Vogle *v__obj, t_boolean v_yesno) {
    t_Vogle__1 *v__ofldp = v__obj->o_fields;
    f_Xd__VsetFlush(v_yesno);
}
void or_Vogle__Vflush(t_Vogle__Vogle *v__obj) {
    t_Vogle__1 *v__ofldp = v__obj->o_fields;
    f_Xd__Vflush();
}
static void or_Vogle__Draw(t_Vogle__Vogle *v__obj, t_real v_x, t_real v_y) {
    t_Vogle__1 *v__ofldp = v__obj->o_fields;
    f_Xd__Draw2(v_x, v_y);
}
void init_t_Vogle__Vogle(t_Vogle__Vogle *v__obj, char *obj_name) {
    int opflags = 0;
    int *op_flags = &opflags;
    t_Vogle__1 *v__ofldp;
    v__obj->o_fields = m_malloc(sizeof(t_Vogle__1));
    memset(v__obj->o_fields, 0, sizeof(t_Vogle__1));
    o_init_rtsdep(v__obj, &td_Vogle__Vogle, obj_name);
    v__ofldp = v__obj->o_fields;
}
void (ini_Vogle__Vogle)(void) {
	static int done = 0;

	if (done) return;
	done = 1;
	td_registration(&td_Vogle__Vogle) = m_ptrregister((void *)&td_Vogle__Vogle);
	m_objdescr_reg(&td_Vogle__Vogle, 21, "Vogle");
	ini_Xd__Xd();
	ini_VTypes__VTypes();
}
