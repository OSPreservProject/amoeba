/* Produced by the Orca-to-C compiler */

/* Orca-to-C compiler, main branch, date: Tue Jun 30 16:56:47 MET DST 1998. */

#include <interface.h>
#include "barrier.h"
static tp_dscr td_barrier__2;
typedef t_integer t_barrier__2;
static par_dscr fa_barrier__2[] = {
	{ OUT, &td_barrier__barrier, ass_barrier__barrier, free_barrier__barrier}
};
static tp_dscr td_barrier__2 = { FUNCTION, sizeof(t_barrier__2), 0, 0, 1, fa_barrier__2};
static tp_dscr td_barrier__3;
typedef t_integer t_barrier__3;
static par_dscr fa_barrier__3[] = {
	{ IN, &td_barrier__barrier, ass_barrier__barrier, free_barrier__barrier}
};
static tp_dscr td_barrier__3 = { FUNCTION, sizeof(t_barrier__3), 0, 0, 1, fa_barrier__3};
static par_dscr fa_barrier__init[] = {
	{ IN, &td_integer, ass_integer, 0}
};
tp_dscr td_barrier__init = { FUNCTION, sizeof(t_barrier__init), 0, 0, 1, fa_barrier__init};
static tp_dscr td_barrier__ack;
typedef t_integer t_barrier__ack;
static par_dscr fa_barrier__ack[] = {
	{ 0, 0, 0, 0}
};
static tp_dscr td_barrier__ack = { FUNCTION, sizeof(t_barrier__ack), 0, 0, 0, fa_barrier__ack};
static tp_dscr td_barrier__done;
typedef t_integer t_barrier__done;
static par_dscr fa_barrier__done[] = {
	{ 0, 0, 0, 0}
};
static tp_dscr td_barrier__done = { FUNCTION, sizeof(t_barrier__done), 0, 0, 0, fa_barrier__done};
static tp_dscr td_barrier__1;
typedef struct t_barrier__1 {
	t_integer f_hit;
	t_integer f_released;
	t_integer f_N;
} t_barrier__1;
static fld_dscr rf_barrier__1[] = {
	{ offsetof(t_barrier__1, f_hit), &td_integer},
	{ offsetof(t_barrier__1, f_released), &td_integer},
	{ offsetof(t_barrier__1, f_N), &td_integer}
};
static tp_dscr td_barrier__1 = { RECORD, sizeof(t_barrier__1), 4, 0, 3, rf_barrier__1};
#undef init_t_barrier__1
#define init_t_barrier__1(p, s) { \
	}
static int cmp_barrier__1(void *aa, void *bb) {
    t_barrier__1 *a=aa; t_barrier__1 *b=bb;
    if (a->f_hit != b->f_hit) return 0;
    if (a->f_released != b->f_released) return 0;
    if (a->f_N != b->f_N) return 0;
    return 1;
}
static void ass_barrier__1(void *dd, void *ss) {
    t_barrier__1 *dst = dd, *src = ss;
    if (dst == src) return;
    dst->f_hit = src->f_hit;
    dst->f_released = src->f_released;
    dst->f_N = src->f_N;
}
static int or__barrier__READ_(t_object *v_obj, void **v__args) {
    init_t_barrier__barrier((t_object *) (v__args[0]), "result");
    ass_barrier__1(((t_object *) (v__args[0]))->o_fields, v_obj->o_fields);
    return 0;
}
static int ow__barrier__WRITE_(t_object *v_obj, void **v__args) {
    ass_barrier__1(v_obj->o_fields, ((t_object *) (v__args[0]))->o_fields);
    return 0;
}
void ow_barrier__init(t_barrier__barrier *v__obj, t_integer v_n_workers);
static int ow__barrier__init(t_object *v_obj, void **v__args) {
    ow_barrier__init(v_obj,*((t_integer *) v__args[0]));
    return 0;
}
static void ow_barrier__ack(int *op_flags, t_barrier__barrier *v__obj);
static int ow__barrier__ack(t_object *v_obj, void **v__args) {
    int op_flags = NESTED;
    ow_barrier__ack(&op_flags, v_obj);
    return (op_flags & BLOCKING) ? 1 : 0;
}
static void ow_barrier__done(int *op_flags, t_barrier__barrier *v__obj);
static int ow__barrier__done(t_object *v_obj, void **v__args) {
    int op_flags = NESTED;
    ow_barrier__done(&op_flags, v_obj);
    return (op_flags & BLOCKING) ? 1 : 0;
}
#ifdef PANDA4
static int sz_call_barrier__READ_(void **argv) {
	int sz = 0;
	return sz;
}
static pan_iovec_p ma_call_barrier__READ_(pan_iovec_p p, void **argv) {
	return p;
}
static void um_call_barrier__READ_(void *p, void ***ap) {
	struct {
		void *av[1];
		t_barrier__barrier arg1;
	} *argstruct;
	argstruct = m_malloc(sizeof(*argstruct));
	*ap = argstruct->av;
	argstruct->av[0] = &(argstruct->arg1);
	memset(&(argstruct->arg1), 0, sizeof(t_barrier__barrier));
}
static int sz_ret_barrier__READ_(void **argv) {
	int sz = 0;
	sz += sz_barrier__barrier(argv[0]);
	return sz;
}
static pan_iovec_p ma_ret_barrier__READ_(pan_iovec_p p, void **argv) {
	p = ma_barrier__barrier(p, argv[0]);
	return p;
}
static void um_ret_barrier__READ_(void *p, void **argv) {
	free_barrier__barrier(argv[0]);
	um_barrier__barrier(p, argv[0]);
}
#else
static int sz_call_barrier__READ_(void **argv) {
	int sz = 0;
	return sz;
}
static char *ma_call_barrier__READ_(char *p, void **argv) {
	return p;
}
static char *um_call_barrier__READ_(char *p, void ***ap) {
	struct {
		void *av[1];
		t_barrier__barrier arg1;
	} *argstruct;
	argstruct = m_malloc(sizeof(*argstruct));
	*ap = argstruct->av;
	argstruct->av[0] = &(argstruct->arg1);
	memset(&(argstruct->arg1), 0, sizeof(t_barrier__barrier));
	return p;
}
static int sz_ret_barrier__READ_(void **argv) {
	int sz = 0;
	sz += sz_barrier__barrier(argv[0]);
	return sz;
}
static char *ma_ret_barrier__READ_(char *p, void **argv) {
	p = ma_barrier__barrier(p, argv[0]);
	free_barrier__barrier(argv[0]);
	m_free((void *) argv);
	return p;
}
static char *um_ret_barrier__READ_(char *p, void **argv) {
	free_barrier__barrier(argv[0]);
	p = um_barrier__barrier(p, argv[0]);
	return p;
}
#endif
static void fr_ret_barrier__READ_(void **argv) {
	free_barrier__barrier(argv[0]);
	m_free((void *) argv);
}
#ifdef PANDA4
static int sz_call_barrier__WRITE_(void **argv) {
	int sz = 0;
	sz += sz_barrier__barrier(argv[0]);
	return sz;
}
static pan_iovec_p ma_call_barrier__WRITE_(pan_iovec_p p, void **argv) {
	p = ma_barrier__barrier(p, argv[0]);
	return p;
}
static void um_call_barrier__WRITE_(void *p, void ***ap) {
	struct {
		void *av[1];
		t_barrier__barrier arg1;
	} *argstruct;
	argstruct = m_malloc(sizeof(*argstruct));
	*ap = argstruct->av;
	argstruct->av[0] = &(argstruct->arg1);
	um_barrier__barrier(p, &(argstruct->arg1));
}
static int sz_ret_barrier__WRITE_(void **argv) {
	int sz = 0;
	return sz;
}
static pan_iovec_p ma_ret_barrier__WRITE_(pan_iovec_p p, void **argv) {
	return p;
}
static void um_ret_barrier__WRITE_(void *p, void **argv) {
}
#else
static int sz_call_barrier__WRITE_(void **argv) {
	int sz = 0;
	sz += sz_barrier__barrier(argv[0]);
	return sz;
}
static char *ma_call_barrier__WRITE_(char *p, void **argv) {
	p = ma_barrier__barrier(p, argv[0]);
	return p;
}
static char *um_call_barrier__WRITE_(char *p, void ***ap) {
	struct {
		void *av[1];
		t_barrier__barrier arg1;
	} *argstruct;
	argstruct = m_malloc(sizeof(*argstruct));
	*ap = argstruct->av;
	argstruct->av[0] = &(argstruct->arg1);
	p = um_barrier__barrier(p, &(argstruct->arg1));
	return p;
}
static int sz_ret_barrier__WRITE_(void **argv) {
	int sz = 0;
	return sz;
}
static char *ma_ret_barrier__WRITE_(char *p, void **argv) {
	free_barrier__barrier(argv[0]);
	m_free((void *) argv);
	return p;
}
static char *um_ret_barrier__WRITE_(char *p, void **argv) {
	return p;
}
#endif
static void fr_ret_barrier__WRITE_(void **argv) {
	free_barrier__barrier(argv[0]);
	m_free((void *) argv);
}
#ifdef PANDA4
static int sz_call_barrier__init(void **argv) {
	int sz = 0;
	sz++;
	return sz;
}
static pan_iovec_p ma_call_barrier__init(pan_iovec_p p, void **argv) {
	p->data = argv[0];
	p->len = sizeof(t_integer);
	p++;
	return p;
}
static void um_call_barrier__init(void *p, void ***ap) {
	struct {
		void *av[1];
		t_integer arg1;
	} *argstruct;
	argstruct = m_malloc(sizeof(*argstruct));
	*ap = argstruct->av;
	argstruct->av[0] = &(argstruct->arg1);
	pan_msg_consume(p, &(argstruct->arg1), sizeof(t_integer));
}
static int sz_ret_barrier__init(void **argv) {
	int sz = 0;
	return sz;
}
static pan_iovec_p ma_ret_barrier__init(pan_iovec_p p, void **argv) {
	return p;
}
static void um_ret_barrier__init(void *p, void **argv) {
}
#else
static int sz_call_barrier__init(void **argv) {
	int sz = 0;
	sz += sizeof(t_integer);
	return sz;
}
static char *ma_call_barrier__init(char *p, void **argv) {
	memcpy(p, argv[0], sizeof(t_integer));
	p += sizeof(t_integer);
	return p;
}
static char *um_call_barrier__init(char *p, void ***ap) {
	struct {
		void *av[1];
		t_integer arg1;
	} *argstruct;
	argstruct = m_malloc(sizeof(*argstruct));
	*ap = argstruct->av;
	argstruct->av[0] = &(argstruct->arg1);
	memcpy(&(argstruct->arg1), p, sizeof(t_integer));
	p += sizeof(t_integer);
	return p;
}
static int sz_ret_barrier__init(void **argv) {
	int sz = 0;
	return sz;
}
static char *ma_ret_barrier__init(char *p, void **argv) {
	m_free((void *) argv);
	return p;
}
static char *um_ret_barrier__init(char *p, void **argv) {
	return p;
}
#endif
static void fr_ret_barrier__init(void **argv) {
	m_free((void *) argv);
}
#ifdef PANDA4
static int sz_call_barrier__ack(void **argv) {
	int sz = 0;
	return sz;
}
static pan_iovec_p ma_call_barrier__ack(pan_iovec_p p, void **argv) {
	return p;
}
static void um_call_barrier__ack(void *p, void ***ap) {
	*ap = 0;
}
static int sz_ret_barrier__ack(void **argv) {
	int sz = 0;
	return sz;
}
static pan_iovec_p ma_ret_barrier__ack(pan_iovec_p p, void **argv) {
	return p;
}
static void um_ret_barrier__ack(void *p, void **argv) {
}
#else
static int sz_call_barrier__ack(void **argv) {
	int sz = 0;
	return sz;
}
static char *ma_call_barrier__ack(char *p, void **argv) {
	return p;
}
static char *um_call_barrier__ack(char *p, void ***ap) {
	*ap = 0;
	return p;
}
static int sz_ret_barrier__ack(void **argv) {
	int sz = 0;
	return sz;
}
static char *ma_ret_barrier__ack(char *p, void **argv) {
	m_free((void *) argv);
	return p;
}
static char *um_ret_barrier__ack(char *p, void **argv) {
	return p;
}
#endif
static void fr_ret_barrier__ack(void **argv) {
	m_free((void *) argv);
}
#ifdef PANDA4
static int sz_call_barrier__done(void **argv) {
	int sz = 0;
	return sz;
}
static pan_iovec_p ma_call_barrier__done(pan_iovec_p p, void **argv) {
	return p;
}
static void um_call_barrier__done(void *p, void ***ap) {
	*ap = 0;
}
static int sz_ret_barrier__done(void **argv) {
	int sz = 0;
	return sz;
}
static pan_iovec_p ma_ret_barrier__done(pan_iovec_p p, void **argv) {
	return p;
}
static void um_ret_barrier__done(void *p, void **argv) {
}
#else
static int sz_call_barrier__done(void **argv) {
	int sz = 0;
	return sz;
}
static char *ma_call_barrier__done(char *p, void **argv) {
	return p;
}
static char *um_call_barrier__done(char *p, void ***ap) {
	*ap = 0;
	return p;
}
static int sz_ret_barrier__done(void **argv) {
	int sz = 0;
	return sz;
}
static char *ma_ret_barrier__done(char *p, void **argv) {
	m_free((void *) argv);
	return p;
}
static char *um_ret_barrier__done(char *p, void **argv) {
	return p;
}
#endif
static void fr_ret_barrier__done(void **argv) {
	m_free((void *) argv);
}
static op_dscr od_barrier__barrier[] = {
	{ or__barrier__READ_, 0, &td_barrier__2, 0, 0, "barrier.READ_",
	  sz_call_barrier__READ_, ma_call_barrier__READ_, um_call_barrier__READ_, sz_ret_barrier__READ_, ma_ret_barrier__READ_, um_ret_barrier__READ_, fr_ret_barrier__READ_},
	{ 0, ow__barrier__WRITE_, &td_barrier__3, 1, OP_PURE_WRITE, "barrier.WRITE_",
	  sz_call_barrier__WRITE_, ma_call_barrier__WRITE_, um_call_barrier__WRITE_, sz_ret_barrier__WRITE_, ma_ret_barrier__WRITE_, um_ret_barrier__WRITE_, fr_ret_barrier__WRITE_},
	{ 0, ow__barrier__init, &td_barrier__init, 2, OP_PURE_WRITE, "barrier.init",
	  sz_call_barrier__init, ma_call_barrier__init, um_call_barrier__init, sz_ret_barrier__init, ma_ret_barrier__init, um_ret_barrier__init, fr_ret_barrier__init},
	{ 0, ow__barrier__ack, &td_barrier__ack, 3, OP_BLOCKING|OP_PURE_WRITE, "barrier.ack",
	  sz_call_barrier__ack, ma_call_barrier__ack, um_call_barrier__ack, sz_ret_barrier__ack, ma_ret_barrier__ack, um_ret_barrier__ack, fr_ret_barrier__ack},
	{ 0, ow__barrier__done, &td_barrier__done, 4, OP_BLOCKING|OP_PURE_WRITE, "barrier.done",
	  sz_call_barrier__done, ma_call_barrier__done, um_call_barrier__done, sz_ret_barrier__done, ma_ret_barrier__done, um_ret_barrier__done, fr_ret_barrier__done}
};
static int sz_obj_barrier__barrier(t_object *op) {
#ifdef PANDA4
    return 1;
#else
    return sizeof(t_barrier__1);
#endif
}
#ifdef PANDA4
static pan_iovec_p ma_obj_barrier__barrier(pan_iovec_p p, t_object *op) {
#else
static char *ma_obj_barrier__barrier(char *p, t_object *op) {
#endif
#ifdef PANDA4
    p->data = op->o_fields;
    p->len = sizeof(t_barrier__1);
    return p+1;
#else
    memcpy(p, op->o_fields, sizeof(t_barrier__1));
    return p + sizeof(t_barrier__1);
#endif
}
#ifdef PANDA4
static void um_obj_barrier__barrier(void *p, t_object *op) {
#else
static char *um_obj_barrier__barrier(char *p, t_object *op) {
#endif
    if (! op->o_fields) op->o_fields = m_malloc(sizeof(t_barrier__1));
#ifdef PANDA4
    pan_msg_consume(p, op->o_fields, sizeof(t_barrier__1));
#else
    memcpy(op->o_fields, p, sizeof(t_barrier__1));
    return p + sizeof(t_barrier__1);
#endif
}
static obj_info oi_barrier__barrier = { sz_obj_barrier__barrier, ma_obj_barrier__barrier, um_obj_barrier__barrier, 0, od_barrier__barrier };
tp_dscr td_barrier__barrier = { OBJECT, sizeof(t_barrier__barrier), 15, &td_barrier__1, 5, &oi_barrier__barrier};
#ifdef PANDA4
int sz_barrier__barrier(t_barrier__barrier *a) {
    int sz = 0;
    sz = o_rts_nbytes(a, &td_barrier__barrier);
    sz ++;
    return sz;
}

pan_iovec_p ma_barrier__barrier(pan_iovec_p p, t_barrier__barrier *a) {
    p = o_rts_marshall(p, a, &td_barrier__barrier);
    p->data = a->o_fields;
    p->len = sizeof(t_barrier__1);
    p++;
    return p;
}

void um_barrier__barrier(void *p, t_barrier__barrier *a) {
    o_rts_unmarshall(p, a, &td_barrier__barrier);
    a->o_fields = m_malloc(sizeof(t_barrier__1));
    pan_msg_consume(p, a->o_fields, sizeof(t_barrier__1));
}

#else
int sz_barrier__barrier(t_barrier__barrier *a) {
    int sz;
    sz = o_rts_nbytes(a, &td_barrier__barrier);
    sz += sizeof(t_barrier__1);
    return sz;
}

char *ma_barrier__barrier(char *p, t_barrier__barrier *a) {
    p = o_rts_marshall(p, a, &td_barrier__barrier);
    memcpy(p, a->o_fields, sizeof(t_barrier__1));
    p += sizeof(t_barrier__1);
    return p;
}

char *um_barrier__barrier(char *p, t_barrier__barrier *a) {
    p = o_rts_unmarshall(p, a, &td_barrier__barrier);
    a->o_fields = m_malloc(sizeof(t_barrier__1));
    memcpy(a->o_fields, p, sizeof(t_barrier__1));
    p += sizeof(t_barrier__1);
    return p;
}

#endif
void free_barrier__barrier(void *d) {
    t_barrier__barrier *dst = d;
    if (dst->o_fields && o_free(dst)) {
        m_free(dst->o_fields);
    }
}
void ass_barrier__barrier(void *dd, void *ss) {
    t_barrier__barrier *dst = dd, *src = ss;
    int op_flags = 0;
    t_object tmp;
    void *argv[1];
    int src_local;
    int dst_local;

    if (dst == src) return;
    argv[0] = &tmp;
    if (! dst->o_fields) {
        dst->o_fields = m_malloc(sizeof(t_barrier__1));
        memset(dst->o_fields, 0, sizeof(t_barrier__1));
        o_init_rtsdep(dst, &td_barrier__barrier, (char *) 0);
    }
    src_local = ! o_isshared(src);
    dst_local = ! o_isshared(dst);
    if (dst_local && (src_local || o_start_read(src))) {
        ass_barrier__1(dst->o_fields, src->o_fields);
        if (! src_local) o_end_read(src);
        return;
    }
    if (src_local && (dst_local || o_start_write(dst))) {
        ass_barrier__1(dst->o_fields, src->o_fields);
        if (! dst_local) o_end_write(dst, 1);
        return;
    }
    tmp.o_fields = m_malloc(sizeof(t_barrier__1));
    memset(tmp.o_fields, 0, sizeof(t_barrier__1));
    o_init_rtsdep(&tmp, &td_barrier__barrier, (char *) 0);
    if (src_local || o_start_read(src)) {
        ass_barrier__1(tmp.o_fields, src->o_fields);
        if (! src_local) o_end_read(src);
    } else {
        DoOperation(src, &op_flags, &td_barrier__barrier, /* READOBJ */ 0, 0, argv);
    }
    if (dst_local || o_start_write(dst)) {
        ass_barrier__1(dst->o_fields, tmp.o_fields);
        if (! dst_local) o_end_write(dst, 1);
    } else {
        DoOperation(dst, &op_flags, &td_barrier__barrier, /* WRITEOBJ */ 1, 0, argv);
    }
    o_free(&tmp);
    m_free(tmp.o_fields);
}
char *fn_barrier__barrier = "barrier.imp";
static void ow_barrier__ack(int *op_flags, t_barrier__barrier *v__obj);
static void ow_barrier__done(int *op_flags, t_barrier__barrier *v__obj);
void f_barrier__sync(int *op_flags, t_barrier__barrier *v_b) {
    m_rts();
    DoOperation(v_b, op_flags, &td_barrier__barrier, 4, 0, (void **) 0);
    if (*op_flags & BLOCKING) goto retlab;
    DoOperation(v_b, op_flags, &td_barrier__barrier, 3, 0, (void **) 0);
    if (*op_flags & BLOCKING) goto retlab;
retlab:;
}
void ow_barrier__init(t_barrier__barrier *v__obj, t_integer v_n_workers) {
    t_barrier__1 *v__ofldp = v__obj->o_fields;
    (v__ofldp->f_N) = v_n_workers;
    (v__ofldp->f_released) = (v__ofldp->f_N);
    (v__ofldp->f_hit) = ((t_integer) 0L);
}
static void ow_barrier__ack(int *op_flags, t_barrier__barrier *v__obj) {
    t_barrier__1 *v__ofldp = v__obj->o_fields;
    if (((v__ofldp->f_hit)==(v__ofldp->f_N))) {
        (v__ofldp->f_released) += ((t_integer) 1L);
        if (((v__ofldp->f_released)==(v__ofldp->f_N))) {
            (v__ofldp->f_hit) = ((t_integer) 0L);
        }
        goto retlab;
    }
    *op_flags |= BLOCKING;
    goto blocking_oper;
retlab:;
blocking_oper:;
}
static void ow_barrier__done(int *op_flags, t_barrier__barrier *v__obj) {
    t_barrier__1 *v__ofldp = v__obj->o_fields;
    if (((v__ofldp->f_released)==(v__ofldp->f_N))) {
        (v__ofldp->f_hit) += ((t_integer) 1L);
        if (((v__ofldp->f_hit)==(v__ofldp->f_N))) {
            (v__ofldp->f_released) = ((t_integer) 0L);
        }
        goto retlab;
    }
    *op_flags |= BLOCKING;
    goto blocking_oper;
retlab:;
blocking_oper:;
}
void init_t_barrier__barrier(t_barrier__barrier *v__obj, char *obj_name) {
    int opflags = 0;
    int *op_flags = &opflags;
    t_barrier__1 *v__ofldp;
    v__obj->o_fields = m_malloc(sizeof(t_barrier__1));
    memset(v__obj->o_fields, 0, sizeof(t_barrier__1));
    o_init_rtsdep(v__obj, &td_barrier__barrier, obj_name);
    v__ofldp = v__obj->o_fields;
}
void (ini_barrier__barrier)(void) {
	static int done = 0;

	if (done) return;
	done = 1;
	td_registration(&td_barrier__barrier) = m_ptrregister((void *)&td_barrier__barrier);
	m_objdescr_reg(&td_barrier__barrier, 5, "barrier");
}
