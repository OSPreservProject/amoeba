/* Produced by the Orca-to-C compiler */

/* Orca-to-C compiler, main branch, date: Tue Jun 30 16:56:47 MET DST 1998. */

#ifndef IntObject____SEEN
#define IntObject____SEEN
extern tp_dscr td_IntObject__IntObject;
typedef t_object t_IntObject__IntObject;
extern tp_dscr td_IntObject__dummy;
typedef t_integer t_IntObject__dummy;
extern tp_dscr td_IntObject__value;
typedef t_integer t_IntObject__value;
extern tp_dscr td_IntObject__assign;
typedef t_integer t_IntObject__assign;
extern tp_dscr td_IntObject__min;
typedef t_integer t_IntObject__min;
extern tp_dscr td_IntObject__max;
typedef t_integer t_IntObject__max;
extern tp_dscr td_IntObject__inc;
typedef t_integer t_IntObject__inc;
extern tp_dscr td_IntObject__dec;
typedef t_integer t_IntObject__dec;
extern tp_dscr td_IntObject__add;
typedef t_integer t_IntObject__add;
extern tp_dscr td_IntObject__subs;
typedef t_integer t_IntObject__subs;
extern tp_dscr td_IntObject__AwaitValue;
typedef t_integer t_IntObject__AwaitValue;
extern int sz_IntObject__IntObject(t_IntObject__IntObject *);
#ifdef PANDA4
extern pan_iovec_p ma_IntObject__IntObject(pan_iovec_p , t_IntObject__IntObject *);
void um_IntObject__IntObject(void *, t_IntObject__IntObject *);
#else
extern char *ma_IntObject__IntObject(char *, t_IntObject__IntObject *);
extern char *um_IntObject__IntObject(char *, t_IntObject__IntObject *);
#endif
void free_IntObject__IntObject(void *);
void ass_IntObject__IntObject(void *a, void *b);
extern char *fn_IntObject__IntObject;
void or_IntObject__dummy(t_IntObject__IntObject *v__obj);
t_integer or_IntObject__value(t_IntObject__IntObject *v__obj);
void ow_IntObject__assign(t_IntObject__IntObject *v__obj, t_integer v_v);
void or_IntObject__min(int *op_flags, t_IntObject__IntObject *v__obj, t_integer v_v);
void ow_IntObject__min(int *op_flags, t_IntObject__IntObject *v__obj, t_integer v_v);
void or_IntObject__max(int *op_flags, t_IntObject__IntObject *v__obj, t_integer v_v);
void ow_IntObject__max(int *op_flags, t_IntObject__IntObject *v__obj, t_integer v_v);
void ow_IntObject__inc(t_IntObject__IntObject *v__obj);
void ow_IntObject__dec(t_IntObject__IntObject *v__obj);
void ow_IntObject__add(t_IntObject__IntObject *v__obj, t_integer v_v);
void ow_IntObject__subs(t_IntObject__IntObject *v__obj, t_integer v_v);
void or_IntObject__AwaitValue(int *op_flags, t_IntObject__IntObject *v__obj, t_integer v_v);
void init_t_IntObject__IntObject(t_IntObject__IntObject *v__obj, char *obj_name);
void ini_IntObject__IntObject(void);
#endif
