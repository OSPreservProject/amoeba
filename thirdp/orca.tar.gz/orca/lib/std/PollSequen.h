/* Produced by the Orca-to-C compiler */

/* Orca-to-C compiler, main branch, date: Tue Jun 30 16:56:47 MET DST 1998. */

#ifndef PollSequence____SEEN
#define PollSequence____SEEN
extern tp_dscr td_PollSequence__PollSequence;
typedef t_object t_PollSequence__PollSequence;
extern tp_dscr td_PollSequence__init;
typedef t_integer t_PollSequence__init;
extern tp_dscr td_PollSequence__vote;
typedef t_integer t_PollSequence__vote;
extern tp_dscr td_PollSequence__AwaitDecision;
typedef t_integer t_PollSequence__AwaitDecision;
extern int sz_PollSequence__PollSequence(t_PollSequence__PollSequence *);
#ifdef PANDA4
extern pan_iovec_p ma_PollSequence__PollSequence(pan_iovec_p , t_PollSequence__PollSequence *);
void um_PollSequence__PollSequence(void *, t_PollSequence__PollSequence *);
#else
extern char *ma_PollSequence__PollSequence(char *, t_PollSequence__PollSequence *);
extern char *um_PollSequence__PollSequence(char *, t_PollSequence__PollSequence *);
#endif
void free_PollSequence__PollSequence(void *);
void ass_PollSequence__PollSequence(void *a, void *b);
extern char *fn_PollSequence__PollSequence;
void ow_PollSequence__init(t_PollSequence__PollSequence *v__obj, t_integer v_n);
void or_PollSequence__vote(int *op_flags, t_PollSequence__PollSequence *v__obj, t_integer v_iter, t_boolean v_YesOrNo);
void ow_PollSequence__vote(int *op_flags, t_PollSequence__PollSequence *v__obj, t_integer v_iter, t_boolean v_YesOrNo);
t_boolean or_PollSequence__AwaitDecision(int *op_flags, t_PollSequence__PollSequence *v__obj, t_integer v_iter);
void init_t_PollSequence__PollSequence(t_PollSequence__PollSequence *v__obj, char *obj_name);
void ini_PollSequence__PollSequence(void);
#endif
