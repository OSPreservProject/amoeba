/* Produced by the Orca-to-C compiler */

/* Orca-to-C compiler, main branch, date: Tue Jun 30 16:56:47 MET DST 1998. */

#ifndef Time____SEEN
#define Time____SEEN
extern char *fn_Time__Time;
t_integer f_Time__GetTime(void);
t_integer f_Time__SysMilli(void);
t_real f_Time__SysMicro(void);
void f_Time__Sleep(t_integer v_sec, t_integer v_nanosec);
void f_Time__PrintTime(t_string *v_name, t_integer v_delta);
void f_Time__PrintCompilationInfo(void);
void ini_Time__Time(void);
#endif
