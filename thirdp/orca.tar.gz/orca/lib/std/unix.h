/* Produced by the Orca-to-C compiler */

/* Orca-to-C compiler, main branch, date: Tue Jun 30 16:56:47 MET DST 1998. */

#ifndef unix____SEEN
#define unix____SEEN
extern char *fn_unix__unix;
t_integer f_unix__open(t_string *v_name, t_integer v_mode);
t_integer f_unix__creat(t_string *v_name, t_integer v_mode);
t_integer f_unix__read(t_integer v_fildes, t_string *ov_buffer, t_integer v_nbytes);
t_integer f_unix__write(t_integer v_fildes, t_string *v_buffer, t_integer v_nbytes);
t_integer f_unix__close(t_integer v_fildes);
t_integer f_unix__getpid(void);
t_integer f_unix__getuid(void);
t_integer f_unix__geteuid(void);
t_integer f_unix__getgid(void);
t_integer f_unix__getegid(void);
t_integer f_unix__link(t_string *v_name1, t_string *v_name2);
t_integer f_unix__lseek(t_integer v_fildes, t_integer v_offset, t_integer v_whence);
t_integer f_unix__unlink(t_string *v_name);
void f_unix__WriteChar(t_integer v_fildes, t_char v_c);
void f_unix__WriteInt(t_integer v_fildes, t_integer v_i);
void f_unix__WriteReal(t_integer v_fildes, t_real v_r);
void f_unix__WriteLn(t_integer v_fildes);
void f_unix__WriteSpaces(t_integer v_fildes, t_integer v_n);
void f_unix__WriteString(t_integer v_fildes, t_string *v_str);
t_char f_unix__ReadChar(t_integer v_fildes);
t_integer f_unix__ReadInt(t_integer v_fildes);
t_real f_unix__ReadReal(t_integer v_fildes);
void f_unix__ReadString(t_integer v_fildes, t_string *v__result);
#define ini_unix__unix()	/* nothing */
#endif
