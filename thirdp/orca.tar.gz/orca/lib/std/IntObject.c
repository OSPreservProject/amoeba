/* Produced by the Orca-to-C compiler */

/* Orca-to-C compiler, main branch, date: Tue Jun 30 16:56:47 MET DST 1998. */

#include <interface.h>
#include "IntObject.h"
static tp_dscr td_IntObject__2;
typedef t_integer t_IntObject__2;
static par_dscr fa_IntObject__2[] = {
	{ OUT, &td_IntObject__IntObject, ass_IntObject__IntObject, free_IntObject__IntObject}
};
static tp_dscr td_IntObject__2 = { FUNCTION, sizeof(t_IntObject__2), 0, 0, 1, fa_IntObject__2};
static tp_dscr td_IntObject__3;
typedef t_integer t_IntObject__3;
static par_dscr fa_IntObject__3[] = {
	{ IN, &td_IntObject__IntObject, ass_IntObject__IntObject, free_IntObject__IntObject}
};
static tp_dscr td_IntObject__3 = { FUNCTION, sizeof(t_IntObject__3), 0, 0, 1, fa_IntObject__3};
static par_dscr fa_IntObject__dummy[] = {
	{ 0, 0, 0, 0}
};
tp_dscr td_IntObject__dummy = { FUNCTION, sizeof(t_IntObject__dummy), 0, 0, 0, fa_IntObject__dummy};
static par_dscr fa_IntObject__value[] = {
	{ OUT, &td_integer, ass_integer, 0}
};
tp_dscr td_IntObject__value = { FUNCTION, sizeof(t_IntObject__value), 0, 0, 1, fa_IntObject__value};
static par_dscr fa_IntObject__assign[] = {
	{ IN, &td_integer, ass_integer, 0}
};
tp_dscr td_IntObject__assign = { FUNCTION, sizeof(t_IntObject__assign), 0, 0, 1, fa_IntObject__assign};
static par_dscr fa_IntObject__min[] = {
	{ IN, &td_integer, ass_integer, 0}
};
tp_dscr td_IntObject__min = { FUNCTION, sizeof(t_IntObject__min), 0, 0, 1, fa_IntObject__min};
static par_dscr fa_IntObject__max[] = {
	{ IN, &td_integer, ass_integer, 0}
};
tp_dscr td_IntObject__max = { FUNCTION, sizeof(t_IntObject__max), 0, 0, 1, fa_IntObject__max};
static par_dscr fa_IntObject__inc[] = {
	{ 0, 0, 0, 0}
};
tp_dscr td_IntObject__inc = { FUNCTION, sizeof(t_IntObject__inc), 0, 0, 0, fa_IntObject__inc};
static par_dscr fa_IntObject__dec[] = {
	{ 0, 0, 0, 0}
};
tp_dscr td_IntObject__dec = { FUNCTION, sizeof(t_IntObject__dec), 0, 0, 0, fa_IntObject__dec};
static par_dscr fa_IntObject__add[] = {
	{ IN, &td_integer, ass_integer, 0}
};
tp_dscr td_IntObject__add = { FUNCTION, sizeof(t_IntObject__add), 0, 0, 1, fa_IntObject__add};
static par_dscr fa_IntObject__subs[] = {
	{ IN, &td_integer, ass_integer, 0}
};
tp_dscr td_IntObject__subs = { FUNCTION, sizeof(t_IntObject__subs), 0, 0, 1, fa_IntObject__subs};
static par_dscr fa_IntObject__AwaitValue[] = {
	{ IN, &td_integer, ass_integer, 0}
};
tp_dscr td_IntObject__AwaitValue = { FUNCTION, sizeof(t_IntObject__AwaitValue), 0, 0, 1, fa_IntObject__AwaitValue};
static tp_dscr td_IntObject__1;
typedef struct t_IntObject__1 {
	t_integer f_x;
} t_IntObject__1;
static fld_dscr rf_IntObject__1[] = {
	{ offsetof(t_IntObject__1, f_x), &td_integer}
};
static tp_dscr td_IntObject__1 = { RECORD, sizeof(t_IntObject__1), 4, 0, 1, rf_IntObject__1};
#undef init_t_IntObject__1
#define init_t_IntObject__1(p, s) { \
	}
static int cmp_IntObject__1(void *aa, void *bb) {
    t_IntObject__1 *a=aa; t_IntObject__1 *b=bb;
    if (a->f_x != b->f_x) return 0;
    return 1;
}
static void ass_IntObject__1(void *dd, void *ss) {
    t_IntObject__1 *dst = dd, *src = ss;
    if (dst == src) return;
    dst->f_x = src->f_x;
}
static int or__IntObject__READ_(t_object *v_obj, void **v__args) {
    init_t_IntObject__IntObject((t_object *) (v__args[0]), "result");
    ass_IntObject__1(((t_object *) (v__args[0]))->o_fields, v_obj->o_fields);
    return 0;
}
static int ow__IntObject__WRITE_(t_object *v_obj, void **v__args) {
    ass_IntObject__1(v_obj->o_fields, ((t_object *) (v__args[0]))->o_fields);
    return 0;
}
void or_IntObject__dummy(t_IntObject__IntObject *v__obj);
static int or__IntObject__dummy(t_object *v_obj, void **v__args) {
    or_IntObject__dummy(v_obj);
    return 0;
}
t_integer or_IntObject__value(t_IntObject__IntObject *v__obj);
static int or__IntObject__value(t_object *v_obj, void **v__args) {
    *((t_integer *) v__args[0]) = or_IntObject__value(v_obj);
    return 0;
}
void ow_IntObject__assign(t_IntObject__IntObject *v__obj, t_integer v_v);
static int ow__IntObject__assign(t_object *v_obj, void **v__args) {
    ow_IntObject__assign(v_obj,*((t_integer *) v__args[0]));
    return 0;
}
void or_IntObject__min(int *op_flags, t_IntObject__IntObject *v__obj, t_integer v_v);
static int or__IntObject__min(t_object *v_obj, void **v__args) {
    int op_flags = NESTED;
    or_IntObject__min(&op_flags, v_obj,*((t_integer *) v__args[0]));
    return (op_flags & BLOCKING) ? 1 : 0;
}
void ow_IntObject__min(int *op_flags, t_IntObject__IntObject *v__obj, t_integer v_v);
static int ow__IntObject__min(t_object *v_obj, void **v__args) {
    int op_flags = NESTED;
    ow_IntObject__min(&op_flags, v_obj,*((t_integer *) v__args[0]));
    return (op_flags & BLOCKING) ? 1 : 0;
}
void or_IntObject__max(int *op_flags, t_IntObject__IntObject *v__obj, t_integer v_v);
static int or__IntObject__max(t_object *v_obj, void **v__args) {
    int op_flags = NESTED;
    or_IntObject__max(&op_flags, v_obj,*((t_integer *) v__args[0]));
    return (op_flags & BLOCKING) ? 1 : 0;
}
void ow_IntObject__max(int *op_flags, t_IntObject__IntObject *v__obj, t_integer v_v);
static int ow__IntObject__max(t_object *v_obj, void **v__args) {
    int op_flags = NESTED;
    ow_IntObject__max(&op_flags, v_obj,*((t_integer *) v__args[0]));
    return (op_flags & BLOCKING) ? 1 : 0;
}
void ow_IntObject__inc(t_IntObject__IntObject *v__obj);
static int ow__IntObject__inc(t_object *v_obj, void **v__args) {
    ow_IntObject__inc(v_obj);
    return 0;
}
void ow_IntObject__dec(t_IntObject__IntObject *v__obj);
static int ow__IntObject__dec(t_object *v_obj, void **v__args) {
    ow_IntObject__dec(v_obj);
    return 0;
}
void ow_IntObject__add(t_IntObject__IntObject *v__obj, t_integer v_v);
static int ow__IntObject__add(t_object *v_obj, void **v__args) {
    ow_IntObject__add(v_obj,*((t_integer *) v__args[0]));
    return 0;
}
void ow_IntObject__subs(t_IntObject__IntObject *v__obj, t_integer v_v);
static int ow__IntObject__subs(t_object *v_obj, void **v__args) {
    ow_IntObject__subs(v_obj,*((t_integer *) v__args[0]));
    return 0;
}
void or_IntObject__AwaitValue(int *op_flags, t_IntObject__IntObject *v__obj, t_integer v_v);
static int or__IntObject__AwaitValue(t_object *v_obj, void **v__args) {
    int op_flags = NESTED;
    or_IntObject__AwaitValue(&op_flags, v_obj,*((t_integer *) v__args[0]));
    return (op_flags & BLOCKING) ? 1 : 0;
}
#ifdef PANDA4
static int sz_call_IntObject__READ_(void **argv) {
	int sz = 0;
	return sz;
}
static pan_iovec_p ma_call_IntObject__READ_(pan_iovec_p p, void **argv) {
	return p;
}
static void um_call_IntObject__READ_(void *p, void ***ap) {
	struct {
		void *av[1];
		t_IntObject__IntObject arg1;
	} *argstruct;
	argstruct = m_malloc(sizeof(*argstruct));
	*ap = argstruct->av;
	argstruct->av[0] = &(argstruct->arg1);
	memset(&(argstruct->arg1), 0, sizeof(t_IntObject__IntObject));
}
static int sz_ret_IntObject__READ_(void **argv) {
	int sz = 0;
	sz += sz_IntObject__IntObject(argv[0]);
	return sz;
}
static pan_iovec_p ma_ret_IntObject__READ_(pan_iovec_p p, void **argv) {
	p = ma_IntObject__IntObject(p, argv[0]);
	return p;
}
static void um_ret_IntObject__READ_(void *p, void **argv) {
	free_IntObject__IntObject(argv[0]);
	um_IntObject__IntObject(p, argv[0]);
}
#else
static int sz_call_IntObject__READ_(void **argv) {
	int sz = 0;
	return sz;
}
static char *ma_call_IntObject__READ_(char *p, void **argv) {
	return p;
}
static char *um_call_IntObject__READ_(char *p, void ***ap) {
	struct {
		void *av[1];
		t_IntObject__IntObject arg1;
	} *argstruct;
	argstruct = m_malloc(sizeof(*argstruct));
	*ap = argstruct->av;
	argstruct->av[0] = &(argstruct->arg1);
	memset(&(argstruct->arg1), 0, sizeof(t_IntObject__IntObject));
	return p;
}
static int sz_ret_IntObject__READ_(void **argv) {
	int sz = 0;
	sz += sz_IntObject__IntObject(argv[0]);
	return sz;
}
static char *ma_ret_IntObject__READ_(char *p, void **argv) {
	p = ma_IntObject__IntObject(p, argv[0]);
	free_IntObject__IntObject(argv[0]);
	m_free((void *) argv);
	return p;
}
static char *um_ret_IntObject__READ_(char *p, void **argv) {
	free_IntObject__IntObject(argv[0]);
	p = um_IntObject__IntObject(p, argv[0]);
	return p;
}
#endif
static void fr_ret_IntObject__READ_(void **argv) {
	free_IntObject__IntObject(argv[0]);
	m_free((void *) argv);
}
#ifdef PANDA4
static int sz_call_IntObject__WRITE_(void **argv) {
	int sz = 0;
	sz += sz_IntObject__IntObject(argv[0]);
	return sz;
}
static pan_iovec_p ma_call_IntObject__WRITE_(pan_iovec_p p, void **argv) {
	p = ma_IntObject__IntObject(p, argv[0]);
	return p;
}
static void um_call_IntObject__WRITE_(void *p, void ***ap) {
	struct {
		void *av[1];
		t_IntObject__IntObject arg1;
	} *argstruct;
	argstruct = m_malloc(sizeof(*argstruct));
	*ap = argstruct->av;
	argstruct->av[0] = &(argstruct->arg1);
	um_IntObject__IntObject(p, &(argstruct->arg1));
}
static int sz_ret_IntObject__WRITE_(void **argv) {
	int sz = 0;
	return sz;
}
static pan_iovec_p ma_ret_IntObject__WRITE_(pan_iovec_p p, void **argv) {
	return p;
}
static void um_ret_IntObject__WRITE_(void *p, void **argv) {
}
#else
static int sz_call_IntObject__WRITE_(void **argv) {
	int sz = 0;
	sz += sz_IntObject__IntObject(argv[0]);
	return sz;
}
static char *ma_call_IntObject__WRITE_(char *p, void **argv) {
	p = ma_IntObject__IntObject(p, argv[0]);
	return p;
}
static char *um_call_IntObject__WRITE_(char *p, void ***ap) {
	struct {
		void *av[1];
		t_IntObject__IntObject arg1;
	} *argstruct;
	argstruct = m_malloc(sizeof(*argstruct));
	*ap = argstruct->av;
	argstruct->av[0] = &(argstruct->arg1);
	p = um_IntObject__IntObject(p, &(argstruct->arg1));
	return p;
}
static int sz_ret_IntObject__WRITE_(void **argv) {
	int sz = 0;
	return sz;
}
static char *ma_ret_IntObject__WRITE_(char *p, void **argv) {
	free_IntObject__IntObject(argv[0]);
	m_free((void *) argv);
	return p;
}
static char *um_ret_IntObject__WRITE_(char *p, void **argv) {
	return p;
}
#endif
static void fr_ret_IntObject__WRITE_(void **argv) {
	free_IntObject__IntObject(argv[0]);
	m_free((void *) argv);
}
#ifdef PANDA4
static int sz_call_IntObject__dummy(void **argv) {
	int sz = 0;
	return sz;
}
static pan_iovec_p ma_call_IntObject__dummy(pan_iovec_p p, void **argv) {
	return p;
}
static void um_call_IntObject__dummy(void *p, void ***ap) {
	*ap = 0;
}
static int sz_ret_IntObject__dummy(void **argv) {
	int sz = 0;
	return sz;
}
static pan_iovec_p ma_ret_IntObject__dummy(pan_iovec_p p, void **argv) {
	return p;
}
static void um_ret_IntObject__dummy(void *p, void **argv) {
}
#else
static int sz_call_IntObject__dummy(void **argv) {
	int sz = 0;
	return sz;
}
static char *ma_call_IntObject__dummy(char *p, void **argv) {
	return p;
}
static char *um_call_IntObject__dummy(char *p, void ***ap) {
	*ap = 0;
	return p;
}
static int sz_ret_IntObject__dummy(void **argv) {
	int sz = 0;
	return sz;
}
static char *ma_ret_IntObject__dummy(char *p, void **argv) {
	m_free((void *) argv);
	return p;
}
static char *um_ret_IntObject__dummy(char *p, void **argv) {
	return p;
}
#endif
static void fr_ret_IntObject__dummy(void **argv) {
	m_free((void *) argv);
}
#ifdef PANDA4
static int sz_call_IntObject__value(void **argv) {
	int sz = 0;
	return sz;
}
static pan_iovec_p ma_call_IntObject__value(pan_iovec_p p, void **argv) {
	return p;
}
static void um_call_IntObject__value(void *p, void ***ap) {
	struct {
		void *av[1];
		t_integer result;
	} *argstruct;
	argstruct = m_malloc(sizeof(*argstruct));
	*ap = argstruct->av;
	argstruct->av[0] = &(argstruct->result);
}
static int sz_ret_IntObject__value(void **argv) {
	int sz = 0;
	sz++;
	return sz;
}
static pan_iovec_p ma_ret_IntObject__value(pan_iovec_p p, void **argv) {
	p->data = argv[0];
	p->len = sizeof(t_integer);
	p++;
	return p;
}
static void um_ret_IntObject__value(void *p, void **argv) {
	pan_msg_consume(p, argv[0], sizeof(t_integer));
}
#else
static int sz_call_IntObject__value(void **argv) {
	int sz = 0;
	return sz;
}
static char *ma_call_IntObject__value(char *p, void **argv) {
	return p;
}
static char *um_call_IntObject__value(char *p, void ***ap) {
	struct {
		void *av[1];
		t_integer result;
	} *argstruct;
	argstruct = m_malloc(sizeof(*argstruct));
	*ap = argstruct->av;
	argstruct->av[0] = &(argstruct->result);
	return p;
}
static int sz_ret_IntObject__value(void **argv) {
	int sz = 0;
	sz += sizeof(t_integer);
	return sz;
}
static char *ma_ret_IntObject__value(char *p, void **argv) {
	memcpy(p, argv[0], sizeof(t_integer));
	p += sizeof(t_integer);
	m_free((void *) argv);
	return p;
}
static char *um_ret_IntObject__value(char *p, void **argv) {
	memcpy(argv[0], p, sizeof(t_integer));
	p += sizeof(t_integer);
	return p;
}
#endif
static void fr_ret_IntObject__value(void **argv) {
	m_free((void *) argv);
}
#ifdef PANDA4
static int sz_call_IntObject__assign(void **argv) {
	int sz = 0;
	sz++;
	return sz;
}
static pan_iovec_p ma_call_IntObject__assign(pan_iovec_p p, void **argv) {
	p->data = argv[0];
	p->len = sizeof(t_integer);
	p++;
	return p;
}
static void um_call_IntObject__assign(void *p, void ***ap) {
	struct {
		void *av[1];
		t_integer arg1;
	} *argstruct;
	argstruct = m_malloc(sizeof(*argstruct));
	*ap = argstruct->av;
	argstruct->av[0] = &(argstruct->arg1);
	pan_msg_consume(p, &(argstruct->arg1), sizeof(t_integer));
}
static int sz_ret_IntObject__assign(void **argv) {
	int sz = 0;
	return sz;
}
static pan_iovec_p ma_ret_IntObject__assign(pan_iovec_p p, void **argv) {
	return p;
}
static void um_ret_IntObject__assign(void *p, void **argv) {
}
#else
static int sz_call_IntObject__assign(void **argv) {
	int sz = 0;
	sz += sizeof(t_integer);
	return sz;
}
static char *ma_call_IntObject__assign(char *p, void **argv) {
	memcpy(p, argv[0], sizeof(t_integer));
	p += sizeof(t_integer);
	return p;
}
static char *um_call_IntObject__assign(char *p, void ***ap) {
	struct {
		void *av[1];
		t_integer arg1;
	} *argstruct;
	argstruct = m_malloc(sizeof(*argstruct));
	*ap = argstruct->av;
	argstruct->av[0] = &(argstruct->arg1);
	memcpy(&(argstruct->arg1), p, sizeof(t_integer));
	p += sizeof(t_integer);
	return p;
}
static int sz_ret_IntObject__assign(void **argv) {
	int sz = 0;
	return sz;
}
static char *ma_ret_IntObject__assign(char *p, void **argv) {
	m_free((void *) argv);
	return p;
}
static char *um_ret_IntObject__assign(char *p, void **argv) {
	return p;
}
#endif
static void fr_ret_IntObject__assign(void **argv) {
	m_free((void *) argv);
}
#ifdef PANDA4
static int sz_call_IntObject__min(void **argv) {
	int sz = 0;
	sz++;
	return sz;
}
static pan_iovec_p ma_call_IntObject__min(pan_iovec_p p, void **argv) {
	p->data = argv[0];
	p->len = sizeof(t_integer);
	p++;
	return p;
}
static void um_call_IntObject__min(void *p, void ***ap) {
	struct {
		void *av[1];
		t_integer arg1;
	} *argstruct;
	argstruct = m_malloc(sizeof(*argstruct));
	*ap = argstruct->av;
	argstruct->av[0] = &(argstruct->arg1);
	pan_msg_consume(p, &(argstruct->arg1), sizeof(t_integer));
}
static int sz_ret_IntObject__min(void **argv) {
	int sz = 0;
	return sz;
}
static pan_iovec_p ma_ret_IntObject__min(pan_iovec_p p, void **argv) {
	return p;
}
static void um_ret_IntObject__min(void *p, void **argv) {
}
#else
static int sz_call_IntObject__min(void **argv) {
	int sz = 0;
	sz += sizeof(t_integer);
	return sz;
}
static char *ma_call_IntObject__min(char *p, void **argv) {
	memcpy(p, argv[0], sizeof(t_integer));
	p += sizeof(t_integer);
	return p;
}
static char *um_call_IntObject__min(char *p, void ***ap) {
	struct {
		void *av[1];
		t_integer arg1;
	} *argstruct;
	argstruct = m_malloc(sizeof(*argstruct));
	*ap = argstruct->av;
	argstruct->av[0] = &(argstruct->arg1);
	memcpy(&(argstruct->arg1), p, sizeof(t_integer));
	p += sizeof(t_integer);
	return p;
}
static int sz_ret_IntObject__min(void **argv) {
	int sz = 0;
	return sz;
}
static char *ma_ret_IntObject__min(char *p, void **argv) {
	m_free((void *) argv);
	return p;
}
static char *um_ret_IntObject__min(char *p, void **argv) {
	return p;
}
#endif
static void fr_ret_IntObject__min(void **argv) {
	m_free((void *) argv);
}
#ifdef PANDA4
static int sz_call_IntObject__max(void **argv) {
	int sz = 0;
	sz++;
	return sz;
}
static pan_iovec_p ma_call_IntObject__max(pan_iovec_p p, void **argv) {
	p->data = argv[0];
	p->len = sizeof(t_integer);
	p++;
	return p;
}
static void um_call_IntObject__max(void *p, void ***ap) {
	struct {
		void *av[1];
		t_integer arg1;
	} *argstruct;
	argstruct = m_malloc(sizeof(*argstruct));
	*ap = argstruct->av;
	argstruct->av[0] = &(argstruct->arg1);
	pan_msg_consume(p, &(argstruct->arg1), sizeof(t_integer));
}
static int sz_ret_IntObject__max(void **argv) {
	int sz = 0;
	return sz;
}
static pan_iovec_p ma_ret_IntObject__max(pan_iovec_p p, void **argv) {
	return p;
}
static void um_ret_IntObject__max(void *p, void **argv) {
}
#else
static int sz_call_IntObject__max(void **argv) {
	int sz = 0;
	sz += sizeof(t_integer);
	return sz;
}
static char *ma_call_IntObject__max(char *p, void **argv) {
	memcpy(p, argv[0], sizeof(t_integer));
	p += sizeof(t_integer);
	return p;
}
static char *um_call_IntObject__max(char *p, void ***ap) {
	struct {
		void *av[1];
		t_integer arg1;
	} *argstruct;
	argstruct = m_malloc(sizeof(*argstruct));
	*ap = argstruct->av;
	argstruct->av[0] = &(argstruct->arg1);
	memcpy(&(argstruct->arg1), p, sizeof(t_integer));
	p += sizeof(t_integer);
	return p;
}
static int sz_ret_IntObject__max(void **argv) {
	int sz = 0;
	return sz;
}
static char *ma_ret_IntObject__max(char *p, void **argv) {
	m_free((void *) argv);
	return p;
}
static char *um_ret_IntObject__max(char *p, void **argv) {
	return p;
}
#endif
static void fr_ret_IntObject__max(void **argv) {
	m_free((void *) argv);
}
#ifdef PANDA4
static int sz_call_IntObject__inc(void **argv) {
	int sz = 0;
	return sz;
}
static pan_iovec_p ma_call_IntObject__inc(pan_iovec_p p, void **argv) {
	return p;
}
static void um_call_IntObject__inc(void *p, void ***ap) {
	*ap = 0;
}
static int sz_ret_IntObject__inc(void **argv) {
	int sz = 0;
	return sz;
}
static pan_iovec_p ma_ret_IntObject__inc(pan_iovec_p p, void **argv) {
	return p;
}
static void um_ret_IntObject__inc(void *p, void **argv) {
}
#else
static int sz_call_IntObject__inc(void **argv) {
	int sz = 0;
	return sz;
}
static char *ma_call_IntObject__inc(char *p, void **argv) {
	return p;
}
static char *um_call_IntObject__inc(char *p, void ***ap) {
	*ap = 0;
	return p;
}
static int sz_ret_IntObject__inc(void **argv) {
	int sz = 0;
	return sz;
}
static char *ma_ret_IntObject__inc(char *p, void **argv) {
	m_free((void *) argv);
	return p;
}
static char *um_ret_IntObject__inc(char *p, void **argv) {
	return p;
}
#endif
static void fr_ret_IntObject__inc(void **argv) {
	m_free((void *) argv);
}
#ifdef PANDA4
static int sz_call_IntObject__dec(void **argv) {
	int sz = 0;
	return sz;
}
static pan_iovec_p ma_call_IntObject__dec(pan_iovec_p p, void **argv) {
	return p;
}
static void um_call_IntObject__dec(void *p, void ***ap) {
	*ap = 0;
}
static int sz_ret_IntObject__dec(void **argv) {
	int sz = 0;
	return sz;
}
static pan_iovec_p ma_ret_IntObject__dec(pan_iovec_p p, void **argv) {
	return p;
}
static void um_ret_IntObject__dec(void *p, void **argv) {
}
#else
static int sz_call_IntObject__dec(void **argv) {
	int sz = 0;
	return sz;
}
static char *ma_call_IntObject__dec(char *p, void **argv) {
	return p;
}
static char *um_call_IntObject__dec(char *p, void ***ap) {
	*ap = 0;
	return p;
}
static int sz_ret_IntObject__dec(void **argv) {
	int sz = 0;
	return sz;
}
static char *ma_ret_IntObject__dec(char *p, void **argv) {
	m_free((void *) argv);
	return p;
}
static char *um_ret_IntObject__dec(char *p, void **argv) {
	return p;
}
#endif
static void fr_ret_IntObject__dec(void **argv) {
	m_free((void *) argv);
}
#ifdef PANDA4
static int sz_call_IntObject__add(void **argv) {
	int sz = 0;
	sz++;
	return sz;
}
static pan_iovec_p ma_call_IntObject__add(pan_iovec_p p, void **argv) {
	p->data = argv[0];
	p->len = sizeof(t_integer);
	p++;
	return p;
}
static void um_call_IntObject__add(void *p, void ***ap) {
	struct {
		void *av[1];
		t_integer arg1;
	} *argstruct;
	argstruct = m_malloc(sizeof(*argstruct));
	*ap = argstruct->av;
	argstruct->av[0] = &(argstruct->arg1);
	pan_msg_consume(p, &(argstruct->arg1), sizeof(t_integer));
}
static int sz_ret_IntObject__add(void **argv) {
	int sz = 0;
	return sz;
}
static pan_iovec_p ma_ret_IntObject__add(pan_iovec_p p, void **argv) {
	return p;
}
static void um_ret_IntObject__add(void *p, void **argv) {
}
#else
static int sz_call_IntObject__add(void **argv) {
	int sz = 0;
	sz += sizeof(t_integer);
	return sz;
}
static char *ma_call_IntObject__add(char *p, void **argv) {
	memcpy(p, argv[0], sizeof(t_integer));
	p += sizeof(t_integer);
	return p;
}
static char *um_call_IntObject__add(char *p, void ***ap) {
	struct {
		void *av[1];
		t_integer arg1;
	} *argstruct;
	argstruct = m_malloc(sizeof(*argstruct));
	*ap = argstruct->av;
	argstruct->av[0] = &(argstruct->arg1);
	memcpy(&(argstruct->arg1), p, sizeof(t_integer));
	p += sizeof(t_integer);
	return p;
}
static int sz_ret_IntObject__add(void **argv) {
	int sz = 0;
	return sz;
}
static char *ma_ret_IntObject__add(char *p, void **argv) {
	m_free((void *) argv);
	return p;
}
static char *um_ret_IntObject__add(char *p, void **argv) {
	return p;
}
#endif
static void fr_ret_IntObject__add(void **argv) {
	m_free((void *) argv);
}
#ifdef PANDA4
static int sz_call_IntObject__subs(void **argv) {
	int sz = 0;
	sz++;
	return sz;
}
static pan_iovec_p ma_call_IntObject__subs(pan_iovec_p p, void **argv) {
	p->data = argv[0];
	p->len = sizeof(t_integer);
	p++;
	return p;
}
static void um_call_IntObject__subs(void *p, void ***ap) {
	struct {
		void *av[1];
		t_integer arg1;
	} *argstruct;
	argstruct = m_malloc(sizeof(*argstruct));
	*ap = argstruct->av;
	argstruct->av[0] = &(argstruct->arg1);
	pan_msg_consume(p, &(argstruct->arg1), sizeof(t_integer));
}
static int sz_ret_IntObject__subs(void **argv) {
	int sz = 0;
	return sz;
}
static pan_iovec_p ma_ret_IntObject__subs(pan_iovec_p p, void **argv) {
	return p;
}
static void um_ret_IntObject__subs(void *p, void **argv) {
}
#else
static int sz_call_IntObject__subs(void **argv) {
	int sz = 0;
	sz += sizeof(t_integer);
	return sz;
}
static char *ma_call_IntObject__subs(char *p, void **argv) {
	memcpy(p, argv[0], sizeof(t_integer));
	p += sizeof(t_integer);
	return p;
}
static char *um_call_IntObject__subs(char *p, void ***ap) {
	struct {
		void *av[1];
		t_integer arg1;
	} *argstruct;
	argstruct = m_malloc(sizeof(*argstruct));
	*ap = argstruct->av;
	argstruct->av[0] = &(argstruct->arg1);
	memcpy(&(argstruct->arg1), p, sizeof(t_integer));
	p += sizeof(t_integer);
	return p;
}
static int sz_ret_IntObject__subs(void **argv) {
	int sz = 0;
	return sz;
}
static char *ma_ret_IntObject__subs(char *p, void **argv) {
	m_free((void *) argv);
	return p;
}
static char *um_ret_IntObject__subs(char *p, void **argv) {
	return p;
}
#endif
static void fr_ret_IntObject__subs(void **argv) {
	m_free((void *) argv);
}
#ifdef PANDA4
static int sz_call_IntObject__AwaitValue(void **argv) {
	int sz = 0;
	sz++;
	return sz;
}
static pan_iovec_p ma_call_IntObject__AwaitValue(pan_iovec_p p, void **argv) {
	p->data = argv[0];
	p->len = sizeof(t_integer);
	p++;
	return p;
}
static void um_call_IntObject__AwaitValue(void *p, void ***ap) {
	struct {
		void *av[1];
		t_integer arg1;
	} *argstruct;
	argstruct = m_malloc(sizeof(*argstruct));
	*ap = argstruct->av;
	argstruct->av[0] = &(argstruct->arg1);
	pan_msg_consume(p, &(argstruct->arg1), sizeof(t_integer));
}
static int sz_ret_IntObject__AwaitValue(void **argv) {
	int sz = 0;
	return sz;
}
static pan_iovec_p ma_ret_IntObject__AwaitValue(pan_iovec_p p, void **argv) {
	return p;
}
static void um_ret_IntObject__AwaitValue(void *p, void **argv) {
}
#else
static int sz_call_IntObject__AwaitValue(void **argv) {
	int sz = 0;
	sz += sizeof(t_integer);
	return sz;
}
static char *ma_call_IntObject__AwaitValue(char *p, void **argv) {
	memcpy(p, argv[0], sizeof(t_integer));
	p += sizeof(t_integer);
	return p;
}
static char *um_call_IntObject__AwaitValue(char *p, void ***ap) {
	struct {
		void *av[1];
		t_integer arg1;
	} *argstruct;
	argstruct = m_malloc(sizeof(*argstruct));
	*ap = argstruct->av;
	argstruct->av[0] = &(argstruct->arg1);
	memcpy(&(argstruct->arg1), p, sizeof(t_integer));
	p += sizeof(t_integer);
	return p;
}
static int sz_ret_IntObject__AwaitValue(void **argv) {
	int sz = 0;
	return sz;
}
static char *ma_ret_IntObject__AwaitValue(char *p, void **argv) {
	m_free((void *) argv);
	return p;
}
static char *um_ret_IntObject__AwaitValue(char *p, void **argv) {
	return p;
}
#endif
static void fr_ret_IntObject__AwaitValue(void **argv) {
	m_free((void *) argv);
}
static op_dscr od_IntObject__IntObject[] = {
	{ or__IntObject__READ_, 0, &td_IntObject__2, 0, 0, "IntObject.READ_",
	  sz_call_IntObject__READ_, ma_call_IntObject__READ_, um_call_IntObject__READ_, sz_ret_IntObject__READ_, ma_ret_IntObject__READ_, um_ret_IntObject__READ_, fr_ret_IntObject__READ_},
	{ 0, ow__IntObject__WRITE_, &td_IntObject__3, 1, OP_PURE_WRITE, "IntObject.WRITE_",
	  sz_call_IntObject__WRITE_, ma_call_IntObject__WRITE_, um_call_IntObject__WRITE_, sz_ret_IntObject__WRITE_, ma_ret_IntObject__WRITE_, um_ret_IntObject__WRITE_, fr_ret_IntObject__WRITE_},
	{ or__IntObject__dummy, 0, &td_IntObject__dummy, 2, OP_PURE_WRITE, "IntObject.dummy",
	  sz_call_IntObject__dummy, ma_call_IntObject__dummy, um_call_IntObject__dummy, sz_ret_IntObject__dummy, ma_ret_IntObject__dummy, um_ret_IntObject__dummy, fr_ret_IntObject__dummy},
	{ or__IntObject__value, 0, &td_IntObject__value, 3, 0, "IntObject.value",
	  sz_call_IntObject__value, ma_call_IntObject__value, um_call_IntObject__value, sz_ret_IntObject__value, ma_ret_IntObject__value, um_ret_IntObject__value, fr_ret_IntObject__value},
	{ 0, ow__IntObject__assign, &td_IntObject__assign, 4, OP_PURE_WRITE, "IntObject.assign",
	  sz_call_IntObject__assign, ma_call_IntObject__assign, um_call_IntObject__assign, sz_ret_IntObject__assign, ma_ret_IntObject__assign, um_ret_IntObject__assign, fr_ret_IntObject__assign},
	{ or__IntObject__min, ow__IntObject__min, &td_IntObject__min, 5, OP_BLOCKING|OP_PURE_WRITE, "IntObject.min",
	  sz_call_IntObject__min, ma_call_IntObject__min, um_call_IntObject__min, sz_ret_IntObject__min, ma_ret_IntObject__min, um_ret_IntObject__min, fr_ret_IntObject__min},
	{ or__IntObject__max, ow__IntObject__max, &td_IntObject__max, 6, OP_BLOCKING|OP_PURE_WRITE, "IntObject.max",
	  sz_call_IntObject__max, ma_call_IntObject__max, um_call_IntObject__max, sz_ret_IntObject__max, ma_ret_IntObject__max, um_ret_IntObject__max, fr_ret_IntObject__max},
	{ 0, ow__IntObject__inc, &td_IntObject__inc, 7, OP_PURE_WRITE, "IntObject.inc",
	  sz_call_IntObject__inc, ma_call_IntObject__inc, um_call_IntObject__inc, sz_ret_IntObject__inc, ma_ret_IntObject__inc, um_ret_IntObject__inc, fr_ret_IntObject__inc},
	{ 0, ow__IntObject__dec, &td_IntObject__dec, 8, OP_PURE_WRITE, "IntObject.dec",
	  sz_call_IntObject__dec, ma_call_IntObject__dec, um_call_IntObject__dec, sz_ret_IntObject__dec, ma_ret_IntObject__dec, um_ret_IntObject__dec, fr_ret_IntObject__dec},
	{ 0, ow__IntObject__add, &td_IntObject__add, 9, OP_PURE_WRITE, "IntObject.add",
	  sz_call_IntObject__add, ma_call_IntObject__add, um_call_IntObject__add, sz_ret_IntObject__add, ma_ret_IntObject__add, um_ret_IntObject__add, fr_ret_IntObject__add},
	{ 0, ow__IntObject__subs, &td_IntObject__subs, 10, OP_PURE_WRITE, "IntObject.subs",
	  sz_call_IntObject__subs, ma_call_IntObject__subs, um_call_IntObject__subs, sz_ret_IntObject__subs, ma_ret_IntObject__subs, um_ret_IntObject__subs, fr_ret_IntObject__subs},
	{ or__IntObject__AwaitValue, 0, &td_IntObject__AwaitValue, 11, OP_BLOCKING|OP_PURE_WRITE, "IntObject.AwaitValue",
	  sz_call_IntObject__AwaitValue, ma_call_IntObject__AwaitValue, um_call_IntObject__AwaitValue, sz_ret_IntObject__AwaitValue, ma_ret_IntObject__AwaitValue, um_ret_IntObject__AwaitValue, fr_ret_IntObject__AwaitValue}
};
static int sz_obj_IntObject__IntObject(t_object *op) {
#ifdef PANDA4
    return 1;
#else
    return sizeof(t_IntObject__1);
#endif
}
#ifdef PANDA4
static pan_iovec_p ma_obj_IntObject__IntObject(pan_iovec_p p, t_object *op) {
#else
static char *ma_obj_IntObject__IntObject(char *p, t_object *op) {
#endif
#ifdef PANDA4
    p->data = op->o_fields;
    p->len = sizeof(t_IntObject__1);
    return p+1;
#else
    memcpy(p, op->o_fields, sizeof(t_IntObject__1));
    return p + sizeof(t_IntObject__1);
#endif
}
#ifdef PANDA4
static void um_obj_IntObject__IntObject(void *p, t_object *op) {
#else
static char *um_obj_IntObject__IntObject(char *p, t_object *op) {
#endif
    if (! op->o_fields) op->o_fields = m_malloc(sizeof(t_IntObject__1));
#ifdef PANDA4
    pan_msg_consume(p, op->o_fields, sizeof(t_IntObject__1));
#else
    memcpy(op->o_fields, p, sizeof(t_IntObject__1));
    return p + sizeof(t_IntObject__1);
#endif
}
static obj_info oi_IntObject__IntObject = { sz_obj_IntObject__IntObject, ma_obj_IntObject__IntObject, um_obj_IntObject__IntObject, 0, od_IntObject__IntObject };
tp_dscr td_IntObject__IntObject = { OBJECT, sizeof(t_IntObject__IntObject), 15, &td_IntObject__1, 12, &oi_IntObject__IntObject};
#ifdef PANDA4
int sz_IntObject__IntObject(t_IntObject__IntObject *a) {
    int sz = 0;
    sz = o_rts_nbytes(a, &td_IntObject__IntObject);
    sz ++;
    return sz;
}

pan_iovec_p ma_IntObject__IntObject(pan_iovec_p p, t_IntObject__IntObject *a) {
    p = o_rts_marshall(p, a, &td_IntObject__IntObject);
    p->data = a->o_fields;
    p->len = sizeof(t_IntObject__1);
    p++;
    return p;
}

void um_IntObject__IntObject(void *p, t_IntObject__IntObject *a) {
    o_rts_unmarshall(p, a, &td_IntObject__IntObject);
    a->o_fields = m_malloc(sizeof(t_IntObject__1));
    pan_msg_consume(p, a->o_fields, sizeof(t_IntObject__1));
}

#else
int sz_IntObject__IntObject(t_IntObject__IntObject *a) {
    int sz;
    sz = o_rts_nbytes(a, &td_IntObject__IntObject);
    sz += sizeof(t_IntObject__1);
    return sz;
}

char *ma_IntObject__IntObject(char *p, t_IntObject__IntObject *a) {
    p = o_rts_marshall(p, a, &td_IntObject__IntObject);
    memcpy(p, a->o_fields, sizeof(t_IntObject__1));
    p += sizeof(t_IntObject__1);
    return p;
}

char *um_IntObject__IntObject(char *p, t_IntObject__IntObject *a) {
    p = o_rts_unmarshall(p, a, &td_IntObject__IntObject);
    a->o_fields = m_malloc(sizeof(t_IntObject__1));
    memcpy(a->o_fields, p, sizeof(t_IntObject__1));
    p += sizeof(t_IntObject__1);
    return p;
}

#endif
void free_IntObject__IntObject(void *d) {
    t_IntObject__IntObject *dst = d;
    if (dst->o_fields && o_free(dst)) {
        m_free(dst->o_fields);
    }
}
void ass_IntObject__IntObject(void *dd, void *ss) {
    t_IntObject__IntObject *dst = dd, *src = ss;
    int op_flags = 0;
    t_object tmp;
    void *argv[1];
    int src_local;
    int dst_local;

    if (dst == src) return;
    argv[0] = &tmp;
    if (! dst->o_fields) {
        dst->o_fields = m_malloc(sizeof(t_IntObject__1));
        memset(dst->o_fields, 0, sizeof(t_IntObject__1));
        o_init_rtsdep(dst, &td_IntObject__IntObject, (char *) 0);
    }
    src_local = ! o_isshared(src);
    dst_local = ! o_isshared(dst);
    if (dst_local && (src_local || o_start_read(src))) {
        ass_IntObject__1(dst->o_fields, src->o_fields);
        if (! src_local) o_end_read(src);
        return;
    }
    if (src_local && (dst_local || o_start_write(dst))) {
        ass_IntObject__1(dst->o_fields, src->o_fields);
        if (! dst_local) o_end_write(dst, 1);
        return;
    }
    tmp.o_fields = m_malloc(sizeof(t_IntObject__1));
    memset(tmp.o_fields, 0, sizeof(t_IntObject__1));
    o_init_rtsdep(&tmp, &td_IntObject__IntObject, (char *) 0);
    if (src_local || o_start_read(src)) {
        ass_IntObject__1(tmp.o_fields, src->o_fields);
        if (! src_local) o_end_read(src);
    } else {
        DoOperation(src, &op_flags, &td_IntObject__IntObject, /* READOBJ */ 0, 0, argv);
    }
    if (dst_local || o_start_write(dst)) {
        ass_IntObject__1(dst->o_fields, tmp.o_fields);
        if (! dst_local) o_end_write(dst, 1);
    } else {
        DoOperation(dst, &op_flags, &td_IntObject__IntObject, /* WRITEOBJ */ 1, 0, argv);
    }
    o_free(&tmp);
    m_free(tmp.o_fields);
}
char *fn_IntObject__IntObject = "IntObject.imp";
void or_IntObject__dummy(t_IntObject__IntObject *v__obj) {
    t_IntObject__1 *v__ofldp = v__obj->o_fields;
}
t_integer or_IntObject__value(t_IntObject__IntObject *v__obj) {
    t_integer v__result = 0;
    t_IntObject__1 *v__ofldp = v__obj->o_fields;
    (v__result) = (v__ofldp->f_x);
    goto retlab;
    m_trap(FALL_THROUGH, fn_IntObject__IntObject, 71);
retlab:;
    return v__result;
}
void ow_IntObject__assign(t_IntObject__IntObject *v__obj, t_integer v_v) {
    t_IntObject__1 *v__ofldp = v__obj->o_fields;
    (v__ofldp->f_x) = v_v;
}
void or_IntObject__min(int *op_flags, t_IntObject__IntObject *v__obj, t_integer v_v) {
    t_IntObject__1 *v__ofldp = v__obj->o_fields;
    if ((v_v>=(v__ofldp->f_x))) {
        goto retlab;
    }
    *op_flags |= BLOCKING;
    goto blocking_oper;
retlab:;
blocking_oper:;
}
void ow_IntObject__min(int *op_flags, t_IntObject__IntObject *v__obj, t_integer v_v) {
    t_IntObject__1 *v__ofldp = v__obj->o_fields;
    if ((v_v<(v__ofldp->f_x))) {
        (v__ofldp->f_x) = v_v;
        goto retlab;
    }
    *op_flags |= BLOCKING;
    goto blocking_oper;
retlab:;
blocking_oper:;
}
void or_IntObject__max(int *op_flags, t_IntObject__IntObject *v__obj, t_integer v_v) {
    t_IntObject__1 *v__ofldp = v__obj->o_fields;
    if ((v_v<=(v__ofldp->f_x))) {
        goto retlab;
    }
    *op_flags |= BLOCKING;
    goto blocking_oper;
retlab:;
blocking_oper:;
}
void ow_IntObject__max(int *op_flags, t_IntObject__IntObject *v__obj, t_integer v_v) {
    t_IntObject__1 *v__ofldp = v__obj->o_fields;
    if ((v_v>(v__ofldp->f_x))) {
        (v__ofldp->f_x) = v_v;
        goto retlab;
    }
    *op_flags |= BLOCKING;
    goto blocking_oper;
retlab:;
blocking_oper:;
}
void ow_IntObject__inc(t_IntObject__IntObject *v__obj) {
    t_IntObject__1 *v__ofldp = v__obj->o_fields;
    (v__ofldp->f_x) += ((t_integer) 1L);
}
void ow_IntObject__dec(t_IntObject__IntObject *v__obj) {
    t_IntObject__1 *v__ofldp = v__obj->o_fields;
    (v__ofldp->f_x) -= ((t_integer) 1L);
}
void ow_IntObject__add(t_IntObject__IntObject *v__obj, t_integer v_v) {
    t_IntObject__1 *v__ofldp = v__obj->o_fields;
    (v__ofldp->f_x) += v_v;
}
void ow_IntObject__subs(t_IntObject__IntObject *v__obj, t_integer v_v) {
    t_IntObject__1 *v__ofldp = v__obj->o_fields;
    (v__ofldp->f_x) -= v_v;
}
void or_IntObject__AwaitValue(int *op_flags, t_IntObject__IntObject *v__obj, t_integer v_v) {
    t_IntObject__1 *v__ofldp = v__obj->o_fields;
    if (((v__ofldp->f_x)==v_v)) {
        goto retlab;
    }
    *op_flags |= BLOCKING;
    goto blocking_oper;
retlab:;
blocking_oper:;
}
void init_t_IntObject__IntObject(t_IntObject__IntObject *v__obj, char *obj_name) {
    int opflags = 0;
    int *op_flags = &opflags;
    t_IntObject__1 *v__ofldp;
    v__obj->o_fields = m_malloc(sizeof(t_IntObject__1));
    memset(v__obj->o_fields, 0, sizeof(t_IntObject__1));
    o_init_rtsdep(v__obj, &td_IntObject__IntObject, obj_name);
    v__ofldp = v__obj->o_fields;
    (v__ofldp->f_x) = ((t_integer) 0L);
}
void (ini_IntObject__IntObject)(void) {
	static int done = 0;

	if (done) return;
	done = 1;
	td_registration(&td_IntObject__IntObject) = m_ptrregister((void *)&td_IntObject__IntObject);
	m_objdescr_reg(&td_IntObject__IntObject, 12, "IntObject");
}
