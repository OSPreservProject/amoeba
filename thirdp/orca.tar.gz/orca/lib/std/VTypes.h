/* Produced by the Orca-to-C compiler */

/* Orca-to-C compiler, main branch, date: Tue Jun 30 16:56:47 MET DST 1998. */

#ifndef VTypes____SEEN
#define VTypes____SEEN
extern char *fn_VTypes__VTypes;
#define ini_VTypes__VTypes()	/* nothing */
#endif
