/* Produced by the Orca-to-C compiler */

/* Orca-to-C compiler, main branch, date: Tue Jun 30 16:56:47 MET DST 1998. */

#ifndef args____SEEN
#define args____SEEN
extern char *fn_args__args;
t_integer f_args__Argc(void);
void f_args__Argv(t_integer v_n, t_string *v__result);
void f_args__Getenv(t_string *v_s, t_string *v__result);
#define ini_args__args()	/* nothing */
#endif
