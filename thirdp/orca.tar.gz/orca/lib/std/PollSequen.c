/* Produced by the Orca-to-C compiler */

/* Orca-to-C compiler, main branch, date: Tue Jun 30 16:56:47 MET DST 1998. */

#include <interface.h>
#include "PollSequen.h"
static tp_dscr td_PollSequence__2;
typedef t_integer t_PollSequence__2;
static par_dscr fa_PollSequence__2[] = {
	{ OUT, &td_PollSequence__PollSequence, ass_PollSequence__PollSequence, free_PollSequence__PollSequence}
};
static tp_dscr td_PollSequence__2 = { FUNCTION, sizeof(t_PollSequence__2), 0, 0, 1, fa_PollSequence__2};
static tp_dscr td_PollSequence__3;
typedef t_integer t_PollSequence__3;
static par_dscr fa_PollSequence__3[] = {
	{ IN, &td_PollSequence__PollSequence, ass_PollSequence__PollSequence, free_PollSequence__PollSequence}
};
static tp_dscr td_PollSequence__3 = { FUNCTION, sizeof(t_PollSequence__3), 0, 0, 1, fa_PollSequence__3};
static par_dscr fa_PollSequence__init[] = {
	{ IN, &td_integer, ass_integer, 0}
};
tp_dscr td_PollSequence__init = { FUNCTION, sizeof(t_PollSequence__init), 0, 0, 1, fa_PollSequence__init};
static par_dscr fa_PollSequence__vote[] = {
	{ IN, &td_integer, ass_integer, 0},
	{ IN, &td_boolean, ass_enum, 0}
};
tp_dscr td_PollSequence__vote = { FUNCTION, sizeof(t_PollSequence__vote), 0, 0, 2, fa_PollSequence__vote};
static par_dscr fa_PollSequence__AwaitDecision[] = {
	{ IN, &td_integer, ass_integer, 0},
	{ OUT, &td_boolean, ass_enum, 0}
};
tp_dscr td_PollSequence__AwaitDecision = { FUNCTION, sizeof(t_PollSequence__AwaitDecision), 0, 0, 2, fa_PollSequence__AwaitDecision};
static tp_dscr td_PollSequence__1;
typedef struct t_PollSequence__1 {
	t_integer f_cleared;
	t_integer f_FinalIter;
	t_integer f_votes;
	t_integer f_nvoters;
} t_PollSequence__1;
static fld_dscr rf_PollSequence__1[] = {
	{ offsetof(t_PollSequence__1, f_cleared), &td_integer},
	{ offsetof(t_PollSequence__1, f_FinalIter), &td_integer},
	{ offsetof(t_PollSequence__1, f_votes), &td_integer},
	{ offsetof(t_PollSequence__1, f_nvoters), &td_integer}
};
static tp_dscr td_PollSequence__1 = { RECORD, sizeof(t_PollSequence__1), 4, 0, 4, rf_PollSequence__1};
#undef init_t_PollSequence__1
#define init_t_PollSequence__1(p, s) { \
	}
static int cmp_PollSequence__1(void *aa, void *bb) {
    t_PollSequence__1 *a=aa; t_PollSequence__1 *b=bb;
    if (a->f_cleared != b->f_cleared) return 0;
    if (a->f_FinalIter != b->f_FinalIter) return 0;
    if (a->f_votes != b->f_votes) return 0;
    if (a->f_nvoters != b->f_nvoters) return 0;
    return 1;
}
static void ass_PollSequence__1(void *dd, void *ss) {
    t_PollSequence__1 *dst = dd, *src = ss;
    if (dst == src) return;
    dst->f_cleared = src->f_cleared;
    dst->f_FinalIter = src->f_FinalIter;
    dst->f_votes = src->f_votes;
    dst->f_nvoters = src->f_nvoters;
}
static int or__PollSequence__READ_(t_object *v_obj, void **v__args) {
    init_t_PollSequence__PollSequence((t_object *) (v__args[0]), "result");
    ass_PollSequence__1(((t_object *) (v__args[0]))->o_fields, v_obj->o_fields);
    return 0;
}
static int ow__PollSequence__WRITE_(t_object *v_obj, void **v__args) {
    ass_PollSequence__1(v_obj->o_fields, ((t_object *) (v__args[0]))->o_fields);
    return 0;
}
void ow_PollSequence__init(t_PollSequence__PollSequence *v__obj, t_integer v_n);
static int ow__PollSequence__init(t_object *v_obj, void **v__args) {
    ow_PollSequence__init(v_obj,*((t_integer *) v__args[0]));
    return 0;
}
void or_PollSequence__vote(int *op_flags, t_PollSequence__PollSequence *v__obj, t_integer v_iter, t_boolean v_YesOrNo);
static int or__PollSequence__vote(t_object *v_obj, void **v__args) {
    int op_flags = NESTED;
    or_PollSequence__vote(&op_flags, v_obj,*((t_integer *) v__args[0]), *((t_boolean *) v__args[1]));
    return (op_flags & BLOCKING) ? 1 : 0;
}
void ow_PollSequence__vote(int *op_flags, t_PollSequence__PollSequence *v__obj, t_integer v_iter, t_boolean v_YesOrNo);
static int ow__PollSequence__vote(t_object *v_obj, void **v__args) {
    int op_flags = NESTED;
    ow_PollSequence__vote(&op_flags, v_obj,*((t_integer *) v__args[0]), *((t_boolean *) v__args[1]));
    return (op_flags & BLOCKING) ? 1 : 0;
}
t_boolean or_PollSequence__AwaitDecision(int *op_flags, t_PollSequence__PollSequence *v__obj, t_integer v_iter);
static int or__PollSequence__AwaitDecision(t_object *v_obj, void **v__args) {
    int op_flags = NESTED;
    *((t_boolean *) v__args[1]) = or_PollSequence__AwaitDecision(&op_flags, v_obj,*((t_integer *) v__args[0]));
    return (op_flags & BLOCKING) ? 1 : 0;
}
#ifdef PANDA4
static int sz_call_PollSequence__READ_(void **argv) {
	int sz = 0;
	return sz;
}
static pan_iovec_p ma_call_PollSequence__READ_(pan_iovec_p p, void **argv) {
	return p;
}
static void um_call_PollSequence__READ_(void *p, void ***ap) {
	struct {
		void *av[1];
		t_PollSequence__PollSequence arg1;
	} *argstruct;
	argstruct = m_malloc(sizeof(*argstruct));
	*ap = argstruct->av;
	argstruct->av[0] = &(argstruct->arg1);
	memset(&(argstruct->arg1), 0, sizeof(t_PollSequence__PollSequence));
}
static int sz_ret_PollSequence__READ_(void **argv) {
	int sz = 0;
	sz += sz_PollSequence__PollSequence(argv[0]);
	return sz;
}
static pan_iovec_p ma_ret_PollSequence__READ_(pan_iovec_p p, void **argv) {
	p = ma_PollSequence__PollSequence(p, argv[0]);
	return p;
}
static void um_ret_PollSequence__READ_(void *p, void **argv) {
	free_PollSequence__PollSequence(argv[0]);
	um_PollSequence__PollSequence(p, argv[0]);
}
#else
static int sz_call_PollSequence__READ_(void **argv) {
	int sz = 0;
	return sz;
}
static char *ma_call_PollSequence__READ_(char *p, void **argv) {
	return p;
}
static char *um_call_PollSequence__READ_(char *p, void ***ap) {
	struct {
		void *av[1];
		t_PollSequence__PollSequence arg1;
	} *argstruct;
	argstruct = m_malloc(sizeof(*argstruct));
	*ap = argstruct->av;
	argstruct->av[0] = &(argstruct->arg1);
	memset(&(argstruct->arg1), 0, sizeof(t_PollSequence__PollSequence));
	return p;
}
static int sz_ret_PollSequence__READ_(void **argv) {
	int sz = 0;
	sz += sz_PollSequence__PollSequence(argv[0]);
	return sz;
}
static char *ma_ret_PollSequence__READ_(char *p, void **argv) {
	p = ma_PollSequence__PollSequence(p, argv[0]);
	free_PollSequence__PollSequence(argv[0]);
	m_free((void *) argv);
	return p;
}
static char *um_ret_PollSequence__READ_(char *p, void **argv) {
	free_PollSequence__PollSequence(argv[0]);
	p = um_PollSequence__PollSequence(p, argv[0]);
	return p;
}
#endif
static void fr_ret_PollSequence__READ_(void **argv) {
	free_PollSequence__PollSequence(argv[0]);
	m_free((void *) argv);
}
#ifdef PANDA4
static int sz_call_PollSequence__WRITE_(void **argv) {
	int sz = 0;
	sz += sz_PollSequence__PollSequence(argv[0]);
	return sz;
}
static pan_iovec_p ma_call_PollSequence__WRITE_(pan_iovec_p p, void **argv) {
	p = ma_PollSequence__PollSequence(p, argv[0]);
	return p;
}
static void um_call_PollSequence__WRITE_(void *p, void ***ap) {
	struct {
		void *av[1];
		t_PollSequence__PollSequence arg1;
	} *argstruct;
	argstruct = m_malloc(sizeof(*argstruct));
	*ap = argstruct->av;
	argstruct->av[0] = &(argstruct->arg1);
	um_PollSequence__PollSequence(p, &(argstruct->arg1));
}
static int sz_ret_PollSequence__WRITE_(void **argv) {
	int sz = 0;
	return sz;
}
static pan_iovec_p ma_ret_PollSequence__WRITE_(pan_iovec_p p, void **argv) {
	return p;
}
static void um_ret_PollSequence__WRITE_(void *p, void **argv) {
}
#else
static int sz_call_PollSequence__WRITE_(void **argv) {
	int sz = 0;
	sz += sz_PollSequence__PollSequence(argv[0]);
	return sz;
}
static char *ma_call_PollSequence__WRITE_(char *p, void **argv) {
	p = ma_PollSequence__PollSequence(p, argv[0]);
	return p;
}
static char *um_call_PollSequence__WRITE_(char *p, void ***ap) {
	struct {
		void *av[1];
		t_PollSequence__PollSequence arg1;
	} *argstruct;
	argstruct = m_malloc(sizeof(*argstruct));
	*ap = argstruct->av;
	argstruct->av[0] = &(argstruct->arg1);
	p = um_PollSequence__PollSequence(p, &(argstruct->arg1));
	return p;
}
static int sz_ret_PollSequence__WRITE_(void **argv) {
	int sz = 0;
	return sz;
}
static char *ma_ret_PollSequence__WRITE_(char *p, void **argv) {
	free_PollSequence__PollSequence(argv[0]);
	m_free((void *) argv);
	return p;
}
static char *um_ret_PollSequence__WRITE_(char *p, void **argv) {
	return p;
}
#endif
static void fr_ret_PollSequence__WRITE_(void **argv) {
	free_PollSequence__PollSequence(argv[0]);
	m_free((void *) argv);
}
#ifdef PANDA4
static int sz_call_PollSequence__init(void **argv) {
	int sz = 0;
	sz++;
	return sz;
}
static pan_iovec_p ma_call_PollSequence__init(pan_iovec_p p, void **argv) {
	p->data = argv[0];
	p->len = sizeof(t_integer);
	p++;
	return p;
}
static void um_call_PollSequence__init(void *p, void ***ap) {
	struct {
		void *av[1];
		t_integer arg1;
	} *argstruct;
	argstruct = m_malloc(sizeof(*argstruct));
	*ap = argstruct->av;
	argstruct->av[0] = &(argstruct->arg1);
	pan_msg_consume(p, &(argstruct->arg1), sizeof(t_integer));
}
static int sz_ret_PollSequence__init(void **argv) {
	int sz = 0;
	return sz;
}
static pan_iovec_p ma_ret_PollSequence__init(pan_iovec_p p, void **argv) {
	return p;
}
static void um_ret_PollSequence__init(void *p, void **argv) {
}
#else
static int sz_call_PollSequence__init(void **argv) {
	int sz = 0;
	sz += sizeof(t_integer);
	return sz;
}
static char *ma_call_PollSequence__init(char *p, void **argv) {
	memcpy(p, argv[0], sizeof(t_integer));
	p += sizeof(t_integer);
	return p;
}
static char *um_call_PollSequence__init(char *p, void ***ap) {
	struct {
		void *av[1];
		t_integer arg1;
	} *argstruct;
	argstruct = m_malloc(sizeof(*argstruct));
	*ap = argstruct->av;
	argstruct->av[0] = &(argstruct->arg1);
	memcpy(&(argstruct->arg1), p, sizeof(t_integer));
	p += sizeof(t_integer);
	return p;
}
static int sz_ret_PollSequence__init(void **argv) {
	int sz = 0;
	return sz;
}
static char *ma_ret_PollSequence__init(char *p, void **argv) {
	m_free((void *) argv);
	return p;
}
static char *um_ret_PollSequence__init(char *p, void **argv) {
	return p;
}
#endif
static void fr_ret_PollSequence__init(void **argv) {
	m_free((void *) argv);
}
#ifdef PANDA4
static int sz_call_PollSequence__vote(void **argv) {
	int sz = 0;
	sz++;
	sz++;
	return sz;
}
static pan_iovec_p ma_call_PollSequence__vote(pan_iovec_p p, void **argv) {
	p->data = argv[0];
	p->len = sizeof(t_integer);
	p++;
	p->data = argv[1];
	p->len = sizeof(t_boolean);
	p++;
	return p;
}
static void um_call_PollSequence__vote(void *p, void ***ap) {
	struct {
		void *av[2];
		t_integer arg1;
		t_boolean arg2;
	} *argstruct;
	argstruct = m_malloc(sizeof(*argstruct));
	*ap = argstruct->av;
	argstruct->av[0] = &(argstruct->arg1);
	pan_msg_consume(p, &(argstruct->arg1), sizeof(t_integer));
	argstruct->av[1] = &(argstruct->arg2);
	pan_msg_consume(p, &(argstruct->arg2), sizeof(t_boolean));
}
static int sz_ret_PollSequence__vote(void **argv) {
	int sz = 0;
	return sz;
}
static pan_iovec_p ma_ret_PollSequence__vote(pan_iovec_p p, void **argv) {
	return p;
}
static void um_ret_PollSequence__vote(void *p, void **argv) {
}
#else
static int sz_call_PollSequence__vote(void **argv) {
	int sz = 0;
	sz += sizeof(t_integer);
	sz += sizeof(t_boolean);
	return sz;
}
static char *ma_call_PollSequence__vote(char *p, void **argv) {
	memcpy(p, argv[0], sizeof(t_integer));
	p += sizeof(t_integer);
	memcpy(p, argv[1], sizeof(t_boolean));
	p += sizeof(t_boolean);
	return p;
}
static char *um_call_PollSequence__vote(char *p, void ***ap) {
	struct {
		void *av[2];
		t_integer arg1;
		t_boolean arg2;
	} *argstruct;
	argstruct = m_malloc(sizeof(*argstruct));
	*ap = argstruct->av;
	argstruct->av[0] = &(argstruct->arg1);
	memcpy(&(argstruct->arg1), p, sizeof(t_integer));
	p += sizeof(t_integer);
	argstruct->av[1] = &(argstruct->arg2);
	memcpy(&(argstruct->arg2), p, sizeof(t_boolean));
	p += sizeof(t_boolean);
	return p;
}
static int sz_ret_PollSequence__vote(void **argv) {
	int sz = 0;
	return sz;
}
static char *ma_ret_PollSequence__vote(char *p, void **argv) {
	m_free((void *) argv);
	return p;
}
static char *um_ret_PollSequence__vote(char *p, void **argv) {
	return p;
}
#endif
static void fr_ret_PollSequence__vote(void **argv) {
	m_free((void *) argv);
}
#ifdef PANDA4
static int sz_call_PollSequence__AwaitDecision(void **argv) {
	int sz = 0;
	sz++;
	return sz;
}
static pan_iovec_p ma_call_PollSequence__AwaitDecision(pan_iovec_p p, void **argv) {
	p->data = argv[0];
	p->len = sizeof(t_integer);
	p++;
	return p;
}
static void um_call_PollSequence__AwaitDecision(void *p, void ***ap) {
	struct {
		void *av[2];
		t_integer arg1;
		t_boolean result;
	} *argstruct;
	argstruct = m_malloc(sizeof(*argstruct));
	*ap = argstruct->av;
	argstruct->av[0] = &(argstruct->arg1);
	pan_msg_consume(p, &(argstruct->arg1), sizeof(t_integer));
	argstruct->av[1] = &(argstruct->result);
}
static int sz_ret_PollSequence__AwaitDecision(void **argv) {
	int sz = 0;
	sz++;
	return sz;
}
static pan_iovec_p ma_ret_PollSequence__AwaitDecision(pan_iovec_p p, void **argv) {
	p->data = argv[1];
	p->len = sizeof(t_boolean);
	p++;
	return p;
}
static void um_ret_PollSequence__AwaitDecision(void *p, void **argv) {
	pan_msg_consume(p, argv[1], sizeof(t_boolean));
}
#else
static int sz_call_PollSequence__AwaitDecision(void **argv) {
	int sz = 0;
	sz += sizeof(t_integer);
	return sz;
}
static char *ma_call_PollSequence__AwaitDecision(char *p, void **argv) {
	memcpy(p, argv[0], sizeof(t_integer));
	p += sizeof(t_integer);
	return p;
}
static char *um_call_PollSequence__AwaitDecision(char *p, void ***ap) {
	struct {
		void *av[2];
		t_integer arg1;
		t_boolean result;
	} *argstruct;
	argstruct = m_malloc(sizeof(*argstruct));
	*ap = argstruct->av;
	argstruct->av[0] = &(argstruct->arg1);
	memcpy(&(argstruct->arg1), p, sizeof(t_integer));
	p += sizeof(t_integer);
	argstruct->av[1] = &(argstruct->result);
	return p;
}
static int sz_ret_PollSequence__AwaitDecision(void **argv) {
	int sz = 0;
	sz += sizeof(t_boolean);
	return sz;
}
static char *ma_ret_PollSequence__AwaitDecision(char *p, void **argv) {
	memcpy(p, argv[1], sizeof(t_boolean));
	p += sizeof(t_boolean);
	m_free((void *) argv);
	return p;
}
static char *um_ret_PollSequence__AwaitDecision(char *p, void **argv) {
	memcpy(argv[1], p, sizeof(t_boolean));
	p += sizeof(t_boolean);
	return p;
}
#endif
static void fr_ret_PollSequence__AwaitDecision(void **argv) {
	m_free((void *) argv);
}
static op_dscr od_PollSequence__PollSequence[] = {
	{ or__PollSequence__READ_, 0, &td_PollSequence__2, 0, 0, "PollSequence.READ_",
	  sz_call_PollSequence__READ_, ma_call_PollSequence__READ_, um_call_PollSequence__READ_, sz_ret_PollSequence__READ_, ma_ret_PollSequence__READ_, um_ret_PollSequence__READ_, fr_ret_PollSequence__READ_},
	{ 0, ow__PollSequence__WRITE_, &td_PollSequence__3, 1, OP_PURE_WRITE, "PollSequence.WRITE_",
	  sz_call_PollSequence__WRITE_, ma_call_PollSequence__WRITE_, um_call_PollSequence__WRITE_, sz_ret_PollSequence__WRITE_, ma_ret_PollSequence__WRITE_, um_ret_PollSequence__WRITE_, fr_ret_PollSequence__WRITE_},
	{ 0, ow__PollSequence__init, &td_PollSequence__init, 2, OP_PURE_WRITE, "PollSequence.init",
	  sz_call_PollSequence__init, ma_call_PollSequence__init, um_call_PollSequence__init, sz_ret_PollSequence__init, ma_ret_PollSequence__init, um_ret_PollSequence__init, fr_ret_PollSequence__init},
	{ or__PollSequence__vote, ow__PollSequence__vote, &td_PollSequence__vote, 3, OP_BLOCKING|OP_PURE_WRITE, "PollSequence.vote",
	  sz_call_PollSequence__vote, ma_call_PollSequence__vote, um_call_PollSequence__vote, sz_ret_PollSequence__vote, ma_ret_PollSequence__vote, um_ret_PollSequence__vote, fr_ret_PollSequence__vote},
	{ or__PollSequence__AwaitDecision, 0, &td_PollSequence__AwaitDecision, 4, OP_BLOCKING, "PollSequence.AwaitDecision",
	  sz_call_PollSequence__AwaitDecision, ma_call_PollSequence__AwaitDecision, um_call_PollSequence__AwaitDecision, sz_ret_PollSequence__AwaitDecision, ma_ret_PollSequence__AwaitDecision, um_ret_PollSequence__AwaitDecision, fr_ret_PollSequence__AwaitDecision}
};
static int sz_obj_PollSequence__PollSequence(t_object *op) {
#ifdef PANDA4
    return 1;
#else
    return sizeof(t_PollSequence__1);
#endif
}
#ifdef PANDA4
static pan_iovec_p ma_obj_PollSequence__PollSequence(pan_iovec_p p, t_object *op) {
#else
static char *ma_obj_PollSequence__PollSequence(char *p, t_object *op) {
#endif
#ifdef PANDA4
    p->data = op->o_fields;
    p->len = sizeof(t_PollSequence__1);
    return p+1;
#else
    memcpy(p, op->o_fields, sizeof(t_PollSequence__1));
    return p + sizeof(t_PollSequence__1);
#endif
}
#ifdef PANDA4
static void um_obj_PollSequence__PollSequence(void *p, t_object *op) {
#else
static char *um_obj_PollSequence__PollSequence(char *p, t_object *op) {
#endif
    if (! op->o_fields) op->o_fields = m_malloc(sizeof(t_PollSequence__1));
#ifdef PANDA4
    pan_msg_consume(p, op->o_fields, sizeof(t_PollSequence__1));
#else
    memcpy(op->o_fields, p, sizeof(t_PollSequence__1));
    return p + sizeof(t_PollSequence__1);
#endif
}
static obj_info oi_PollSequence__PollSequence = { sz_obj_PollSequence__PollSequence, ma_obj_PollSequence__PollSequence, um_obj_PollSequence__PollSequence, 0, od_PollSequence__PollSequence };
tp_dscr td_PollSequence__PollSequence = { OBJECT, sizeof(t_PollSequence__PollSequence), 15, &td_PollSequence__1, 5, &oi_PollSequence__PollSequence};
#ifdef PANDA4
int sz_PollSequence__PollSequence(t_PollSequence__PollSequence *a) {
    int sz = 0;
    sz = o_rts_nbytes(a, &td_PollSequence__PollSequence);
    sz ++;
    return sz;
}

pan_iovec_p ma_PollSequence__PollSequence(pan_iovec_p p, t_PollSequence__PollSequence *a) {
    p = o_rts_marshall(p, a, &td_PollSequence__PollSequence);
    p->data = a->o_fields;
    p->len = sizeof(t_PollSequence__1);
    p++;
    return p;
}

void um_PollSequence__PollSequence(void *p, t_PollSequence__PollSequence *a) {
    o_rts_unmarshall(p, a, &td_PollSequence__PollSequence);
    a->o_fields = m_malloc(sizeof(t_PollSequence__1));
    pan_msg_consume(p, a->o_fields, sizeof(t_PollSequence__1));
}

#else
int sz_PollSequence__PollSequence(t_PollSequence__PollSequence *a) {
    int sz;
    sz = o_rts_nbytes(a, &td_PollSequence__PollSequence);
    sz += sizeof(t_PollSequence__1);
    return sz;
}

char *ma_PollSequence__PollSequence(char *p, t_PollSequence__PollSequence *a) {
    p = o_rts_marshall(p, a, &td_PollSequence__PollSequence);
    memcpy(p, a->o_fields, sizeof(t_PollSequence__1));
    p += sizeof(t_PollSequence__1);
    return p;
}

char *um_PollSequence__PollSequence(char *p, t_PollSequence__PollSequence *a) {
    p = o_rts_unmarshall(p, a, &td_PollSequence__PollSequence);
    a->o_fields = m_malloc(sizeof(t_PollSequence__1));
    memcpy(a->o_fields, p, sizeof(t_PollSequence__1));
    p += sizeof(t_PollSequence__1);
    return p;
}

#endif
void free_PollSequence__PollSequence(void *d) {
    t_PollSequence__PollSequence *dst = d;
    if (dst->o_fields && o_free(dst)) {
        m_free(dst->o_fields);
    }
}
void ass_PollSequence__PollSequence(void *dd, void *ss) {
    t_PollSequence__PollSequence *dst = dd, *src = ss;
    int op_flags = 0;
    t_object tmp;
    void *argv[1];
    int src_local;
    int dst_local;

    if (dst == src) return;
    argv[0] = &tmp;
    if (! dst->o_fields) {
        dst->o_fields = m_malloc(sizeof(t_PollSequence__1));
        memset(dst->o_fields, 0, sizeof(t_PollSequence__1));
        o_init_rtsdep(dst, &td_PollSequence__PollSequence, (char *) 0);
    }
    src_local = ! o_isshared(src);
    dst_local = ! o_isshared(dst);
    if (dst_local && (src_local || o_start_read(src))) {
        ass_PollSequence__1(dst->o_fields, src->o_fields);
        if (! src_local) o_end_read(src);
        return;
    }
    if (src_local && (dst_local || o_start_write(dst))) {
        ass_PollSequence__1(dst->o_fields, src->o_fields);
        if (! dst_local) o_end_write(dst, 1);
        return;
    }
    tmp.o_fields = m_malloc(sizeof(t_PollSequence__1));
    memset(tmp.o_fields, 0, sizeof(t_PollSequence__1));
    o_init_rtsdep(&tmp, &td_PollSequence__PollSequence, (char *) 0);
    if (src_local || o_start_read(src)) {
        ass_PollSequence__1(tmp.o_fields, src->o_fields);
        if (! src_local) o_end_read(src);
    } else {
        DoOperation(src, &op_flags, &td_PollSequence__PollSequence, /* READOBJ */ 0, 0, argv);
    }
    if (dst_local || o_start_write(dst)) {
        ass_PollSequence__1(dst->o_fields, tmp.o_fields);
        if (! dst_local) o_end_write(dst, 1);
    } else {
        DoOperation(dst, &op_flags, &td_PollSequence__PollSequence, /* WRITEOBJ */ 1, 0, argv);
    }
    o_free(&tmp);
    m_free(tmp.o_fields);
}
char *fn_PollSequence__PollSequence = "PollSequen.imp";
void ow_PollSequence__init(t_PollSequence__PollSequence *v__obj, t_integer v_n) {
    t_PollSequence__1 *v__ofldp = v__obj->o_fields;
    (v__ofldp->f_nvoters) = v_n;
    (v__ofldp->f_cleared) = ((t_integer) 0L);
    (v__ofldp->f_votes) = ((t_integer) 0L);
    (v__ofldp->f_FinalIter) = ((t_integer) 0L);
}
void or_PollSequence__vote(int *op_flags, t_PollSequence__PollSequence *v__obj, t_integer v_iter, t_boolean v_YesOrNo) {
    t_PollSequence__1 *v__ofldp = v__obj->o_fields;
    if ((v_iter<=(v__ofldp->f_cleared))) {
        goto retlab;
    }
    *op_flags |= BLOCKING;
    goto blocking_oper;
retlab:;
blocking_oper:;
}
void ow_PollSequence__vote(int *op_flags, t_PollSequence__PollSequence *v__obj, t_integer v_iter, t_boolean v_YesOrNo) {
    t_PollSequence__1 *v__ofldp = v__obj->o_fields;
    if ((v_iter==((v__ofldp->f_cleared)+((t_integer) 1L)))) {
        if (v_YesOrNo) {
            (v__ofldp->f_votes) += ((t_integer) 1L);
            if (((v__ofldp->f_votes)==(v__ofldp->f_nvoters))) {
                m_assert(((v__ofldp->f_FinalIter)==((t_integer) 0L)), fn_PollSequence__PollSequence, 28);
                (v__ofldp->f_FinalIter) = v_iter;
            }
        } else {
            (v__ofldp->f_cleared) += ((t_integer) 1L);
            (v__ofldp->f_votes) = ((t_integer) 0L);
        }
        goto retlab;
    }
    *op_flags |= BLOCKING;
    goto blocking_oper;
retlab:;
blocking_oper:;
}
t_boolean or_PollSequence__AwaitDecision(int *op_flags, t_PollSequence__PollSequence *v__obj, t_integer v_iter) {
    t_boolean v__result = 0;
    t_PollSequence__1 *v__ofldp = v__obj->o_fields;
    if (((v__ofldp->f_FinalIter)==v_iter)) {
        (v__result) = ((t_boolean) 1L);
        goto retlab;
        m_trap(FALL_THROUGH, fn_PollSequence__PollSequence, 54);
        goto retlab;
    }
    *op_flags &= ~BLOCKING;
    if (((v__ofldp->f_cleared)>=v_iter)) {
        (v__result) = ((t_boolean) 0L);
        goto retlab;
        m_trap(FALL_THROUGH, fn_PollSequence__PollSequence, 54);
        goto retlab;
    }
    *op_flags |= BLOCKING;
    goto blocking_oper;
    m_trap(FALL_THROUGH, fn_PollSequence__PollSequence, 54);
retlab:;
blocking_oper:;
    return v__result;
}
void init_t_PollSequence__PollSequence(t_PollSequence__PollSequence *v__obj, char *obj_name) {
    int opflags = 0;
    int *op_flags = &opflags;
    t_PollSequence__1 *v__ofldp;
    v__obj->o_fields = m_malloc(sizeof(t_PollSequence__1));
    memset(v__obj->o_fields, 0, sizeof(t_PollSequence__1));
    o_init_rtsdep(v__obj, &td_PollSequence__PollSequence, obj_name);
    v__ofldp = v__obj->o_fields;
}
void (ini_PollSequence__PollSequence)(void) {
	static int done = 0;

	if (done) return;
	done = 1;
	td_registration(&td_PollSequence__PollSequence) = m_ptrregister((void *)&td_PollSequence__PollSequence);
	m_objdescr_reg(&td_PollSequence__PollSequence, 5, "PollSequence");
}
