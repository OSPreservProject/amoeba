/* Produced by the Orca-to-C compiler */

/* Orca-to-C compiler, main branch, date: Tue Jun 30 16:56:47 MET DST 1998. */

#ifndef Xd____SEEN
#define Xd____SEEN
extern char *fn_Xd__Xd;
void f_Xd__X_Init(void);
void f_Xd__X_Exit(void);
t_integer f_Xd__BackBuffer(void);
void f_Xd__Circle(t_real v_x, t_real v_y, t_real v_radius);
void f_Xd__CirclePrecision(t_integer v_nseg);
void f_Xd__Clear(void);
void f_Xd__Color(t_integer v_col);
void f_Xd__Draw2(t_real v_x, t_real v_y);
void f_Xd__DrawStr(t_string *v_str);
void f_Xd__MapColor(t_integer v_index, t_integer v_red, t_integer v_green, t_integer v_blue);
void f_Xd__Move2(t_real v_x, t_real v_y);
void f_Xd__Ortho2(t_real v_left, t_real v_right, t_real v_bottom, t_real v_top);
void f_Xd__Point2(t_real v_x, t_real v_y);
void f_Xd__PolyFill(t_boolean v_onoff);
void f_Xd__PrefPosition(t_integer v_x, t_integer v_y);
void f_Xd__PrefSize(t_integer v_width, t_integer v_height);
void f_Xd__Rect(t_real v_x1, t_real v_y1, t_real v_x2, t_real v_y2);
void f_Xd__SwapBuffers(void);
void f_Xd__VsetFlush(t_boolean v_yesno);
void f_Xd__Vflush(void);
#define ini_Xd__Xd()	/* nothing */
#endif
