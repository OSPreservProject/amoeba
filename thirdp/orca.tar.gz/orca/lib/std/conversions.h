/* Produced by the Orca-to-C compiler */

/* Orca-to-C compiler, main branch, date: Tue Jun 30 16:56:47 MET DST 1998. */

#ifndef conversions____SEEN
#define conversions____SEEN
extern char *fn_conversions__conversions;
t_longreal f_conversions__StringToReal(t_string *v_s, t_integer *ov_eaten);
t_longint f_conversions__StringToInt(t_string *v_s, t_integer *ov_eaten);
void f_conversions__RealToString(t_longreal v_r, t_integer v_p, t_string *v__result);
void f_conversions__IntToString(t_longint v_i, t_string *v__result);
#define ini_conversions__conversions()	/* nothing */
#endif
