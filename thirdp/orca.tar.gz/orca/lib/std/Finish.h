/* Produced by the Orca-to-C compiler */

/* Orca-to-C compiler, main branch, date: Tue Jun 30 16:56:47 MET DST 1998. */

#ifndef Finish____SEEN
#define Finish____SEEN
extern char *fn_Finish__Finish;
void f_Finish__Finish(void);
#define ini_Finish__Finish()	/* nothing */
#endif
