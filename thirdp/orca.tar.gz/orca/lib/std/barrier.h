/* Produced by the Orca-to-C compiler */

/* Orca-to-C compiler, main branch, date: Tue Jun 30 16:56:47 MET DST 1998. */

#ifndef barrier____SEEN
#define barrier____SEEN
extern tp_dscr td_barrier__barrier;
typedef t_object t_barrier__barrier;
extern tp_dscr td_barrier__init;
typedef t_integer t_barrier__init;
extern int sz_barrier__barrier(t_barrier__barrier *);
#ifdef PANDA4
extern pan_iovec_p ma_barrier__barrier(pan_iovec_p , t_barrier__barrier *);
void um_barrier__barrier(void *, t_barrier__barrier *);
#else
extern char *ma_barrier__barrier(char *, t_barrier__barrier *);
extern char *um_barrier__barrier(char *, t_barrier__barrier *);
#endif
void free_barrier__barrier(void *);
void ass_barrier__barrier(void *a, void *b);
extern char *fn_barrier__barrier;
#define onf_barrier__sync f_barrier__sync
void f_barrier__sync(int *op_flags, t_barrier__barrier *v_b);
void ow_barrier__init(t_barrier__barrier *v__obj, t_integer v_n_workers);
void init_t_barrier__barrier(t_barrier__barrier *v__obj, char *obj_name);
void ini_barrier__barrier(void);
#endif
