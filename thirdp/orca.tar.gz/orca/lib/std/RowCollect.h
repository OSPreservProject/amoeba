/* Produced by the Orca-to-C compiler */

/* Orca-to-C compiler, main branch, date: Tue Jun 30 16:56:47 MET DST 1998. */

#ifndef RowCollection____SEEN
#define RowCollection____SEEN
extern tp_dscr td_RowCollection__RowCollection;
typedef t_object t_RowCollection__RowCollection;
extern tp_dscr td_RowCollection__RowType;
typedef ARRAY_TYPE(1) t_RowCollection__RowType;
#undef batinit_RowCollection__RowType
#define batinit_RowCollection__RowType(p, nestinit, lb0, ub0, s) { \
		a_allocate(p, 1, sizeof(t_integer), lb0, ub0); \
	}
extern int sz_RowCollection__RowType(t_RowCollection__RowType *);
#ifdef PANDA4
extern pan_iovec_p ma_RowCollection__RowType(pan_iovec_p , t_RowCollection__RowType *);
void um_RowCollection__RowType(void *, t_RowCollection__RowType *);
#else
extern char *ma_RowCollection__RowType(char *, t_RowCollection__RowType *);
extern char *um_RowCollection__RowType(char *, t_RowCollection__RowType *);
#endif
int cmp_RowCollection__RowType(void *a, void *b);
void free_RowCollection__RowType(void *);
void ass_RowCollection__RowType(void *a, void *b);
extern tp_dscr td_RowCollection__init;
typedef t_integer t_RowCollection__init;
extern tp_dscr td_RowCollection__AddRow;
typedef t_integer t_RowCollection__AddRow;
extern tp_dscr td_RowCollection__AwaitRow;
typedef t_integer t_RowCollection__AwaitRow;
extern int sz_RowCollection__RowCollection(t_RowCollection__RowCollection *);
#ifdef PANDA4
extern pan_iovec_p ma_RowCollection__RowCollection(pan_iovec_p , t_RowCollection__RowCollection *);
void um_RowCollection__RowCollection(void *, t_RowCollection__RowCollection *);
#else
extern char *ma_RowCollection__RowCollection(char *, t_RowCollection__RowCollection *);
extern char *um_RowCollection__RowCollection(char *, t_RowCollection__RowCollection *);
#endif
void free_RowCollection__RowCollection(void *);
void ass_RowCollection__RowCollection(void *a, void *b);
extern char *fn_RowCollection__RowCollection;
void ow_RowCollection__init(t_RowCollection__RowCollection *v__obj, t_integer v_size);
void ow_RowCollection__AddRow(t_RowCollection__RowCollection *v__obj, t_integer v_iter, t_RowCollection__RowType *v_R);
void or_RowCollection__AwaitRow(int *op_flags, t_RowCollection__RowCollection *v__obj, t_integer v_iter, t_RowCollection__RowType *v__result);
void init_t_RowCollection__RowCollection(t_RowCollection__RowCollection *v__obj, char *obj_name);
void ini_RowCollection__RowCollection(void);
#endif
