/* Produced by the Orca-to-C compiler */

/* Orca-to-C compiler, main branch, date: Tue Jun 30 16:56:47 MET DST 1998. */

#ifndef distributions____SEEN
#define distributions____SEEN
extern tp_dscr td_distributions__CPUListType;
typedef ARRAY_TYPE(1) t_distributions__CPUListType;
#undef batinit_distributions__CPUListType
#define batinit_distributions__CPUListType(p, nestinit, lb0, ub0, s) { \
		a_allocate(p, 1, sizeof(t_integer), lb0, ub0); \
	}
extern int sz_distributions__CPUListType(t_distributions__CPUListType *);
#ifdef PANDA4
extern pan_iovec_p ma_distributions__CPUListType(pan_iovec_p , t_distributions__CPUListType *);
void um_distributions__CPUListType(void *, t_distributions__CPUListType *);
#else
extern char *ma_distributions__CPUListType(char *, t_distributions__CPUListType *);
extern char *um_distributions__CPUListType(char *, t_distributions__CPUListType *);
#endif
int cmp_distributions__CPUListType(void *a, void *b);
void free_distributions__CPUListType(void *);
void ass_distributions__CPUListType(void *a, void *b);
extern tp_dscr td_distributions__DistributionType;
typedef ARRAY_TYPE(1) t_distributions__DistributionType;
#undef batinit_distributions__DistributionType
#define batinit_distributions__DistributionType(p, nestinit, lb0, ub0, s) { \
		a_allocate(p, 1, sizeof(t_integer), lb0, ub0); \
	}
extern int sz_distributions__DistributionType(t_distributions__DistributionType *);
#ifdef PANDA4
extern pan_iovec_p ma_distributions__DistributionType(pan_iovec_p , t_distributions__DistributionType *);
void um_distributions__DistributionType(void *, t_distributions__DistributionType *);
#else
extern char *ma_distributions__DistributionType(char *, t_distributions__DistributionType *);
extern char *um_distributions__DistributionType(char *, t_distributions__DistributionType *);
#endif
int cmp_distributions__DistributionType(void *a, void *b);
void free_distributions__DistributionType(void *);
void ass_distributions__DistributionType(void *a, void *b);
extern char *fn_distributions__distributions;
void f_distributions__block(t_integer v_npart, t_integer v_ncpus, t_distributions__DistributionType *v__result);
void f_distributions__cyclic(t_integer v_npart, t_integer v_ncpus, t_distributions__DistributionType *v__result);
#define ini_distributions__distributions()	/* nothing */
#endif
