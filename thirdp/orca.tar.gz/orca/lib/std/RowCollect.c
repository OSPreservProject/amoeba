/* Produced by the Orca-to-C compiler */

/* Orca-to-C compiler, main branch, date: Tue Jun 30 16:56:47 MET DST 1998. */

#include <interface.h>
#include "RowCollect.h"
static tp_dscr td_RowCollection__2;
typedef t_integer t_RowCollection__2;
static par_dscr fa_RowCollection__2[] = {
	{ OUT, &td_RowCollection__RowCollection, ass_RowCollection__RowCollection, free_RowCollection__RowCollection}
};
static tp_dscr td_RowCollection__2 = { FUNCTION, sizeof(t_RowCollection__2), 0, 0, 1, fa_RowCollection__2};
static tp_dscr td_RowCollection__3;
typedef t_integer t_RowCollection__3;
static par_dscr fa_RowCollection__3[] = {
	{ IN, &td_RowCollection__RowCollection, ass_RowCollection__RowCollection, free_RowCollection__RowCollection}
};
static tp_dscr td_RowCollection__3 = { FUNCTION, sizeof(t_RowCollection__3), 0, 0, 1, fa_RowCollection__3};
static tp_dscr *ar_RowCollection__RowType[] = {
	&td_integer
};
tp_dscr td_RowCollection__RowType = { ARRAY, sizeof(t_RowCollection__RowType), 5, &td_integer, 1, ar_RowCollection__RowType};
#ifdef PANDA4
int sz_RowCollection__RowType(t_RowCollection__RowType *a) {
    int sz = 0;
    if (a->a_sz <= 0) return 1;
    sz = 1;
    sz ++;
    return sz;
}

pan_iovec_p ma_RowCollection__RowType(pan_iovec_p p, t_RowCollection__RowType *a) {
    t_integer *s;
    p->data = (void *) a;
    p->len = sizeof(*a);
    p++;
    if (a->a_sz <= 0) return p;
    s = (t_integer *) a->a_data + a->a_offset;
    p->data = (void *)s;
    p->len = a->a_sz * sizeof(t_integer);
    p++;
    return p;
}

void um_RowCollection__RowType(void *p, t_RowCollection__RowType *a) {
    t_integer *s;
    pan_msg_consume(p, a, sizeof(*a));
    if (a->a_sz <= 0) { a->a_sz = 0; a->a_data = 0;  return; }
    s = (t_integer *) m_malloc(a->a_sz * sizeof(t_integer));
    a->a_data = s - a->a_offset;
    pan_msg_consume(p, s, a->a_sz * sizeof(t_integer));
}

#else
int sz_RowCollection__RowType(t_RowCollection__RowType *a) {
    int sz;
    sz = 2 * sizeof(a->a_dims[0].a_lwb);
    if (a->a_sz <= 0) return sz;
    sz += a->a_sz * sizeof(t_integer);
    return sz;
}

char *ma_RowCollection__RowType(char *p, t_RowCollection__RowType *a) {
    t_integer *s;
    put_tp(a->a_dims[0].a_lwb, p);
    put_tp(a->a_dims[0].a_nel, p);
    if (a->a_sz <= 0) return p;
    s = (t_integer *) a->a_data + a->a_offset;
    memcpy(p, s, a->a_sz * sizeof(t_integer));
    p += a->a_sz * sizeof(t_integer);
    return p;
}

char *um_RowCollection__RowType(char *p, t_RowCollection__RowType *a) {
    t_integer *s;
    a->a_offset = 0;
    get_tp(a->a_dims[0].a_lwb, p);
    get_tp(a->a_dims[0].a_nel, p);
    a->a_sz = a->a_dims[0].a_nel;
    a->a_offset = a->a_dims[0].a_lwb;
    if (a->a_sz <= 0) { a->a_sz = 0; a->a_data = 0;  return p; }
    s = (t_integer *) m_malloc(a->a_sz * sizeof(t_integer));
    a->a_data = s - a->a_offset;
    memcpy(s, p, a->a_sz * sizeof(t_integer));
    p += a->a_sz * sizeof(t_integer);
    return p;
}

#endif
int cmp_RowCollection__RowType(void *aa, void *bb) {
    t_RowCollection__RowType *a=aa; t_RowCollection__RowType *b=bb;
    size_t off;
    if (a == b) return 1;
    if (a->a_sz <= 0) return b->a_sz <= 0;
    if (a_lb(a, 0) != a_lb(b, 0)) return 0;
    if (a_ne(a, 0) != a_ne(b, 0)) return 0;
    off = a->a_offset * sizeof(t_integer);
    return memcmp((char *)(a->a_data) + off, (char *) (b->a_data) + off, sizeof(t_integer) * a->a_sz) == 0;
}
void free_RowCollection__RowType(void *d) {
    t_RowCollection__RowType *dst = d;
    if (dst->a_sz <= 0) return;
    m_free(((t_integer *) (dst->a_data)) + dst->a_offset);
    dst->a_sz = 0;
}
void ass_RowCollection__RowType(void *dd, void *ss) {
    t_RowCollection__RowType *dst = dd, *src = ss;
    size_t off = sizeof(t_integer) * src->a_offset;
    t_integer *p,*q = (void *)((char *)(src->a_data)+off);
    size_t sz = src->a_sz * sizeof(t_integer);

    if (dst == src) return;
    if (dst->a_sz != src->a_sz) {
	void *m;
	if (dst->a_sz > 0) free_RowCollection__RowType(dst);
	dst->a_sz = src->a_sz;
	dst->a_offset = src->a_offset;
	dst->a_dims[0] = src->a_dims[0];
	if (src->a_sz <= 0) return;
	m = m_malloc(sz);
	dst->a_data = (char *)m - off;
    } else {
	dst->a_dims[0] = src->a_dims[0];
	dst->a_data = (t_integer *)(dst->a_data) - (src->a_offset - dst->a_offset);
	dst->a_offset = src->a_offset;
    }
    if (src->a_sz <= 0) return;
    p = (void *)((char *)(dst->a_data) + off);
    memcpy(p, q, sz);
}
static par_dscr fa_RowCollection__init[] = {
	{ IN, &td_integer, ass_integer, 0}
};
tp_dscr td_RowCollection__init = { FUNCTION, sizeof(t_RowCollection__init), 0, 0, 1, fa_RowCollection__init};
static par_dscr fa_RowCollection__AddRow[] = {
	{ IN, &td_integer, ass_integer, 0},
	{ IN, &td_RowCollection__RowType, ass_RowCollection__RowType, free_RowCollection__RowType}
};
tp_dscr td_RowCollection__AddRow = { FUNCTION, sizeof(t_RowCollection__AddRow), 0, 0, 2, fa_RowCollection__AddRow};
static par_dscr fa_RowCollection__AwaitRow[] = {
	{ IN, &td_integer, ass_integer, 0},
	{ OUT, &td_RowCollection__RowType, ass_RowCollection__RowType, free_RowCollection__RowType}
};
tp_dscr td_RowCollection__AwaitRow = { FUNCTION, sizeof(t_RowCollection__AwaitRow), 0, 0, 2, fa_RowCollection__AwaitRow};
static tp_dscr td_RowCollection__collection;
typedef ARRAY_TYPE(1) t_RowCollection__collection;
static tp_dscr *ar_RowCollection__collection[] = {
	&td_integer
};
static tp_dscr td_RowCollection__collection = { ARRAY, sizeof(t_RowCollection__collection), 5, &td_RowCollection__RowType, 1, ar_RowCollection__collection};
#undef batinit_RowCollection__collection
#define batinit_RowCollection__collection(p, nestinit, lb0, ub0, s) { \
		a_allocate(p, 1, sizeof(t_RowCollection__RowType), lb0, ub0); \
		if (nestinit) { \
			t_RowCollection__RowType *a_RowCollection__0 = &((t_RowCollection__RowType *)((p)->a_data))[(p)->a_offset]; \
			unsigned i_ = (p)->a_sz; \
			while (i_-- != 0) { \
				a_initialize(a_RowCollection__0, s "[?]"); a_RowCollection__0++; \
			} \
		} \
	}
#ifdef PANDA4
static int sz_RowCollection__collection(t_RowCollection__collection *a) {
    int sz = 0;
    int i;
    t_RowCollection__RowType *s;
    if (a->a_sz <= 0) return 1;
    sz = 1;
    s = (t_RowCollection__RowType *) a->a_data + a->a_offset;
    for (i = a->a_sz; i > 0; i--, s++) {
	sz += sz_RowCollection__RowType(s);
    }
    return sz;
}

static pan_iovec_p ma_RowCollection__collection(pan_iovec_p p, t_RowCollection__collection *a) {
    t_RowCollection__RowType *s;
    int i;
    p->data = (void *) a;
    p->len = sizeof(*a);
    p++;
    if (a->a_sz <= 0) return p;
    s = (t_RowCollection__RowType *) a->a_data + a->a_offset;
    for (i = a->a_sz; i > 0; i--, s++) {
	p = ma_RowCollection__RowType(p, s);
    }
    return p;
}

static void um_RowCollection__collection(void *p, t_RowCollection__collection *a) {
    t_RowCollection__RowType *s;
    int i;
    pan_msg_consume(p, a, sizeof(*a));
    if (a->a_sz <= 0) { a->a_sz = 0; a->a_data = 0;  return; }
    s = (t_RowCollection__RowType *) m_malloc(a->a_sz * sizeof(t_RowCollection__RowType));
    a->a_data = s - a->a_offset;
    for (i = a->a_sz; i > 0; i--, s++) {
	um_RowCollection__RowType(p, s);
    }
}

#else
static int sz_RowCollection__collection(t_RowCollection__collection *a) {
    int sz;
    int i;
    t_RowCollection__RowType *s;
    sz = 2 * sizeof(a->a_dims[0].a_lwb);
    if (a->a_sz <= 0) return sz;
    s = (t_RowCollection__RowType *) a->a_data + a->a_offset;
    for (i = a->a_sz; i > 0; i--, s++) {
	sz += sz_RowCollection__RowType(s);
    }
    return sz;
}

static char *ma_RowCollection__collection(char *p, t_RowCollection__collection *a) {
    t_RowCollection__RowType *s;
    int i;
    put_tp(a->a_dims[0].a_lwb, p);
    put_tp(a->a_dims[0].a_nel, p);
    if (a->a_sz <= 0) return p;
    s = (t_RowCollection__RowType *) a->a_data + a->a_offset;
    for (i = a->a_sz; i > 0; i--, s++) {
	p = ma_RowCollection__RowType(p, s);
    }
    return p;
}

static char *um_RowCollection__collection(char *p, t_RowCollection__collection *a) {
    t_RowCollection__RowType *s;
    int i;
    a->a_offset = 0;
    get_tp(a->a_dims[0].a_lwb, p);
    get_tp(a->a_dims[0].a_nel, p);
    a->a_sz = a->a_dims[0].a_nel;
    a->a_offset = a->a_dims[0].a_lwb;
    if (a->a_sz <= 0) { a->a_sz = 0; a->a_data = 0;  return p; }
    s = (t_RowCollection__RowType *) m_malloc(a->a_sz * sizeof(t_RowCollection__RowType));
    a->a_data = s - a->a_offset;
    for (i = a->a_sz; i > 0; i--, s++) {
	p = um_RowCollection__RowType(p, s);
    }
    return p;
}

#endif
static int cmp_RowCollection__collection(void *aa, void *bb) {
    t_RowCollection__collection *a=aa; t_RowCollection__collection *b=bb;
    size_t off;
    t_RowCollection__RowType *p, *q;
    int i;
    if (a == b) return 1;
    if (a->a_sz <= 0) return b->a_sz <= 0;
    if (a_lb(a, 0) != a_lb(b, 0)) return 0;
    if (a_ne(a, 0) != a_ne(b, 0)) return 0;
    off = a->a_offset * sizeof(t_RowCollection__RowType);
    p = (void *)((char *) (a->a_data) + off);
    q = (void *)((char *) (b->a_data) + off);
    for (i = a->a_sz; i; p++, q++, i--) {
        if (! cmp_RowCollection__RowType(p, q)) return 0;
    }
    return 1;
}
static void free_RowCollection__collection(void *d) {
    t_RowCollection__collection *dst = d;
    if (dst->a_sz <= 0) return;
    {   int i;
        t_RowCollection__RowType *p = ((t_RowCollection__RowType *) (dst->a_data)) + dst->a_offset;
        for (i = dst->a_sz; i > 0; i--, p++) {
            free_RowCollection__RowType(p);
        }
    }
    m_free(((t_RowCollection__RowType *) (dst->a_data)) + dst->a_offset);
    dst->a_sz = 0;
}
static void ass_RowCollection__collection(void *dd, void *ss) {
    t_RowCollection__collection *dst = dd, *src = ss;
    int	i;
    size_t off = sizeof(t_RowCollection__RowType) * src->a_offset;
    t_RowCollection__RowType *p,*q = (void *)((char *)(src->a_data)+off);
    size_t sz = src->a_sz * sizeof(t_RowCollection__RowType);

    if (dst == src) return;
    if (dst->a_sz != src->a_sz) {
	void *m;
	if (dst->a_sz > 0) free_RowCollection__collection(dst);
	dst->a_sz = src->a_sz;
	dst->a_offset = src->a_offset;
	dst->a_dims[0] = src->a_dims[0];
	if (src->a_sz <= 0) return;
	m = m_malloc(sz);
	memset(m, '\0', sz);
	dst->a_data = (char *)m - off;
    } else {
	dst->a_dims[0] = src->a_dims[0];
	dst->a_data = (t_RowCollection__RowType *)(dst->a_data) - (src->a_offset - dst->a_offset);
	dst->a_offset = src->a_offset;
    }
    if (src->a_sz <= 0) return;
    p = (void *)((char *)(dst->a_data) + off);
    for (i = dst->a_sz; i > 0; i--, p++, q++) {
	ass_RowCollection__RowType(p, q);
    }
}
static tp_dscr td_RowCollection__1;
typedef struct t_RowCollection__1 {
	t_RowCollection__collection f_tab;
} t_RowCollection__1;
static fld_dscr rf_RowCollection__1[] = {
	{ offsetof(t_RowCollection__1, f_tab), &td_RowCollection__collection}
};
static tp_dscr td_RowCollection__1 = { RECORD, sizeof(t_RowCollection__1), 5, 0, 1, rf_RowCollection__1};
#undef init_t_RowCollection__1
#define init_t_RowCollection__1(p, s) { \
		a_initialize(&((p)->f_tab), s); \
	}
#ifdef PANDA4
static int sz_RowCollection__1(t_RowCollection__1 *a) {
    int sz = 0;
    sz += sz_RowCollection__collection(&(a->f_tab));
    return sz;
}

static pan_iovec_p ma_RowCollection__1(pan_iovec_p p, t_RowCollection__1 *a) {
    p = ma_RowCollection__collection(p, &(a->f_tab));
    return p;
}

static void um_RowCollection__1(void *p, t_RowCollection__1 *a) {
    um_RowCollection__collection(p, &(a->f_tab));
}

#else
static int sz_RowCollection__1(t_RowCollection__1 *a) {
    int sz;
    sz = 0;
    sz += sz_RowCollection__collection(&(a->f_tab));
    return sz;
}

static char *ma_RowCollection__1(char *p, t_RowCollection__1 *a) {
    p = ma_RowCollection__collection(p, &(a->f_tab));
    return p;
}

static char *um_RowCollection__1(char *p, t_RowCollection__1 *a) {
    p = um_RowCollection__collection(p, &(a->f_tab));
    return p;
}

#endif
static int cmp_RowCollection__1(void *aa, void *bb) {
    t_RowCollection__1 *a=aa; t_RowCollection__1 *b=bb;
    if (! cmp_RowCollection__collection(&(a->f_tab), &(b->f_tab))) return 0;
    return 1;
}
static void free_RowCollection__1(void *d) {
    t_RowCollection__1 *dst = d;
    free_RowCollection__collection(&(dst->f_tab));
}
static void ass_RowCollection__1(void *dd, void *ss) {
    t_RowCollection__1 *dst = dd, *src = ss;
    if (dst == src) return;
    ass_RowCollection__collection(&(dst->f_tab), &(src->f_tab));
}
static int or__RowCollection__READ_(t_object *v_obj, void **v__args) {
    init_t_RowCollection__RowCollection((t_object *) (v__args[0]), "result");
    ass_RowCollection__1(((t_object *) (v__args[0]))->o_fields, v_obj->o_fields);
    return 0;
}
static int ow__RowCollection__WRITE_(t_object *v_obj, void **v__args) {
    ass_RowCollection__1(v_obj->o_fields, ((t_object *) (v__args[0]))->o_fields);
    return 0;
}
void ow_RowCollection__init(t_RowCollection__RowCollection *v__obj, t_integer v_size);
static int ow__RowCollection__init(t_object *v_obj, void **v__args) {
    ow_RowCollection__init(v_obj,*((t_integer *) v__args[0]));
    return 0;
}
void ow_RowCollection__AddRow(t_RowCollection__RowCollection *v__obj, t_integer v_iter, t_RowCollection__RowType *v_R);
static int ow__RowCollection__AddRow(t_object *v_obj, void **v__args) {
    ow_RowCollection__AddRow(v_obj,*((t_integer *) v__args[0]), v__args[1]);
    return 0;
}
void or_RowCollection__AwaitRow(int *op_flags, t_RowCollection__RowCollection *v__obj, t_integer v_iter, t_RowCollection__RowType *v__result);
static int or__RowCollection__AwaitRow(t_object *v_obj, void **v__args) {
    int op_flags = NESTED;
    or_RowCollection__AwaitRow(&op_flags, v_obj,*((t_integer *) v__args[0]),((t_RowCollection__RowType *) v__args[1]));
    return (op_flags & BLOCKING) ? 1 : 0;
}
#ifdef PANDA4
static int sz_call_RowCollection__READ_(void **argv) {
	int sz = 0;
	return sz;
}
static pan_iovec_p ma_call_RowCollection__READ_(pan_iovec_p p, void **argv) {
	return p;
}
static void um_call_RowCollection__READ_(void *p, void ***ap) {
	struct {
		void *av[1];
		t_RowCollection__RowCollection arg1;
	} *argstruct;
	argstruct = m_malloc(sizeof(*argstruct));
	*ap = argstruct->av;
	argstruct->av[0] = &(argstruct->arg1);
	memset(&(argstruct->arg1), 0, sizeof(t_RowCollection__RowCollection));
}
static int sz_ret_RowCollection__READ_(void **argv) {
	int sz = 0;
	sz += sz_RowCollection__RowCollection(argv[0]);
	return sz;
}
static pan_iovec_p ma_ret_RowCollection__READ_(pan_iovec_p p, void **argv) {
	p = ma_RowCollection__RowCollection(p, argv[0]);
	return p;
}
static void um_ret_RowCollection__READ_(void *p, void **argv) {
	free_RowCollection__RowCollection(argv[0]);
	um_RowCollection__RowCollection(p, argv[0]);
}
#else
static int sz_call_RowCollection__READ_(void **argv) {
	int sz = 0;
	return sz;
}
static char *ma_call_RowCollection__READ_(char *p, void **argv) {
	return p;
}
static char *um_call_RowCollection__READ_(char *p, void ***ap) {
	struct {
		void *av[1];
		t_RowCollection__RowCollection arg1;
	} *argstruct;
	argstruct = m_malloc(sizeof(*argstruct));
	*ap = argstruct->av;
	argstruct->av[0] = &(argstruct->arg1);
	memset(&(argstruct->arg1), 0, sizeof(t_RowCollection__RowCollection));
	return p;
}
static int sz_ret_RowCollection__READ_(void **argv) {
	int sz = 0;
	sz += sz_RowCollection__RowCollection(argv[0]);
	return sz;
}
static char *ma_ret_RowCollection__READ_(char *p, void **argv) {
	p = ma_RowCollection__RowCollection(p, argv[0]);
	free_RowCollection__RowCollection(argv[0]);
	m_free((void *) argv);
	return p;
}
static char *um_ret_RowCollection__READ_(char *p, void **argv) {
	free_RowCollection__RowCollection(argv[0]);
	p = um_RowCollection__RowCollection(p, argv[0]);
	return p;
}
#endif
static void fr_ret_RowCollection__READ_(void **argv) {
	free_RowCollection__RowCollection(argv[0]);
	m_free((void *) argv);
}
#ifdef PANDA4
static int sz_call_RowCollection__WRITE_(void **argv) {
	int sz = 0;
	sz += sz_RowCollection__RowCollection(argv[0]);
	return sz;
}
static pan_iovec_p ma_call_RowCollection__WRITE_(pan_iovec_p p, void **argv) {
	p = ma_RowCollection__RowCollection(p, argv[0]);
	return p;
}
static void um_call_RowCollection__WRITE_(void *p, void ***ap) {
	struct {
		void *av[1];
		t_RowCollection__RowCollection arg1;
	} *argstruct;
	argstruct = m_malloc(sizeof(*argstruct));
	*ap = argstruct->av;
	argstruct->av[0] = &(argstruct->arg1);
	um_RowCollection__RowCollection(p, &(argstruct->arg1));
}
static int sz_ret_RowCollection__WRITE_(void **argv) {
	int sz = 0;
	return sz;
}
static pan_iovec_p ma_ret_RowCollection__WRITE_(pan_iovec_p p, void **argv) {
	return p;
}
static void um_ret_RowCollection__WRITE_(void *p, void **argv) {
}
#else
static int sz_call_RowCollection__WRITE_(void **argv) {
	int sz = 0;
	sz += sz_RowCollection__RowCollection(argv[0]);
	return sz;
}
static char *ma_call_RowCollection__WRITE_(char *p, void **argv) {
	p = ma_RowCollection__RowCollection(p, argv[0]);
	return p;
}
static char *um_call_RowCollection__WRITE_(char *p, void ***ap) {
	struct {
		void *av[1];
		t_RowCollection__RowCollection arg1;
	} *argstruct;
	argstruct = m_malloc(sizeof(*argstruct));
	*ap = argstruct->av;
	argstruct->av[0] = &(argstruct->arg1);
	p = um_RowCollection__RowCollection(p, &(argstruct->arg1));
	return p;
}
static int sz_ret_RowCollection__WRITE_(void **argv) {
	int sz = 0;
	return sz;
}
static char *ma_ret_RowCollection__WRITE_(char *p, void **argv) {
	free_RowCollection__RowCollection(argv[0]);
	m_free((void *) argv);
	return p;
}
static char *um_ret_RowCollection__WRITE_(char *p, void **argv) {
	return p;
}
#endif
static void fr_ret_RowCollection__WRITE_(void **argv) {
	free_RowCollection__RowCollection(argv[0]);
	m_free((void *) argv);
}
#ifdef PANDA4
static int sz_call_RowCollection__init(void **argv) {
	int sz = 0;
	sz++;
	return sz;
}
static pan_iovec_p ma_call_RowCollection__init(pan_iovec_p p, void **argv) {
	p->data = argv[0];
	p->len = sizeof(t_integer);
	p++;
	return p;
}
static void um_call_RowCollection__init(void *p, void ***ap) {
	struct {
		void *av[1];
		t_integer arg1;
	} *argstruct;
	argstruct = m_malloc(sizeof(*argstruct));
	*ap = argstruct->av;
	argstruct->av[0] = &(argstruct->arg1);
	pan_msg_consume(p, &(argstruct->arg1), sizeof(t_integer));
}
static int sz_ret_RowCollection__init(void **argv) {
	int sz = 0;
	return sz;
}
static pan_iovec_p ma_ret_RowCollection__init(pan_iovec_p p, void **argv) {
	return p;
}
static void um_ret_RowCollection__init(void *p, void **argv) {
}
#else
static int sz_call_RowCollection__init(void **argv) {
	int sz = 0;
	sz += sizeof(t_integer);
	return sz;
}
static char *ma_call_RowCollection__init(char *p, void **argv) {
	memcpy(p, argv[0], sizeof(t_integer));
	p += sizeof(t_integer);
	return p;
}
static char *um_call_RowCollection__init(char *p, void ***ap) {
	struct {
		void *av[1];
		t_integer arg1;
	} *argstruct;
	argstruct = m_malloc(sizeof(*argstruct));
	*ap = argstruct->av;
	argstruct->av[0] = &(argstruct->arg1);
	memcpy(&(argstruct->arg1), p, sizeof(t_integer));
	p += sizeof(t_integer);
	return p;
}
static int sz_ret_RowCollection__init(void **argv) {
	int sz = 0;
	return sz;
}
static char *ma_ret_RowCollection__init(char *p, void **argv) {
	m_free((void *) argv);
	return p;
}
static char *um_ret_RowCollection__init(char *p, void **argv) {
	return p;
}
#endif
static void fr_ret_RowCollection__init(void **argv) {
	m_free((void *) argv);
}
#ifdef PANDA4
static int sz_call_RowCollection__AddRow(void **argv) {
	int sz = 0;
	sz++;
	sz += sz_RowCollection__RowType(argv[1]);
	return sz;
}
static pan_iovec_p ma_call_RowCollection__AddRow(pan_iovec_p p, void **argv) {
	p->data = argv[0];
	p->len = sizeof(t_integer);
	p++;
	p = ma_RowCollection__RowType(p, argv[1]);
	return p;
}
static void um_call_RowCollection__AddRow(void *p, void ***ap) {
	struct {
		void *av[2];
		t_integer arg1;
		t_RowCollection__RowType arg2;
	} *argstruct;
	argstruct = m_malloc(sizeof(*argstruct));
	*ap = argstruct->av;
	argstruct->av[0] = &(argstruct->arg1);
	pan_msg_consume(p, &(argstruct->arg1), sizeof(t_integer));
	argstruct->av[1] = &(argstruct->arg2);
	um_RowCollection__RowType(p, &(argstruct->arg2));
}
static int sz_ret_RowCollection__AddRow(void **argv) {
	int sz = 0;
	return sz;
}
static pan_iovec_p ma_ret_RowCollection__AddRow(pan_iovec_p p, void **argv) {
	return p;
}
static void um_ret_RowCollection__AddRow(void *p, void **argv) {
}
#else
static int sz_call_RowCollection__AddRow(void **argv) {
	int sz = 0;
	sz += sizeof(t_integer);
	sz += sz_RowCollection__RowType(argv[1]);
	return sz;
}
static char *ma_call_RowCollection__AddRow(char *p, void **argv) {
	memcpy(p, argv[0], sizeof(t_integer));
	p += sizeof(t_integer);
	p = ma_RowCollection__RowType(p, argv[1]);
	return p;
}
static char *um_call_RowCollection__AddRow(char *p, void ***ap) {
	struct {
		void *av[2];
		t_integer arg1;
		t_RowCollection__RowType arg2;
	} *argstruct;
	argstruct = m_malloc(sizeof(*argstruct));
	*ap = argstruct->av;
	argstruct->av[0] = &(argstruct->arg1);
	memcpy(&(argstruct->arg1), p, sizeof(t_integer));
	p += sizeof(t_integer);
	argstruct->av[1] = &(argstruct->arg2);
	p = um_RowCollection__RowType(p, &(argstruct->arg2));
	return p;
}
static int sz_ret_RowCollection__AddRow(void **argv) {
	int sz = 0;
	return sz;
}
static char *ma_ret_RowCollection__AddRow(char *p, void **argv) {
	free_RowCollection__RowType(argv[1]);
	m_free((void *) argv);
	return p;
}
static char *um_ret_RowCollection__AddRow(char *p, void **argv) {
	return p;
}
#endif
static void fr_ret_RowCollection__AddRow(void **argv) {
	free_RowCollection__RowType(argv[1]);
	m_free((void *) argv);
}
#ifdef PANDA4
static int sz_call_RowCollection__AwaitRow(void **argv) {
	int sz = 0;
	sz++;
	return sz;
}
static pan_iovec_p ma_call_RowCollection__AwaitRow(pan_iovec_p p, void **argv) {
	p->data = argv[0];
	p->len = sizeof(t_integer);
	p++;
	return p;
}
static void um_call_RowCollection__AwaitRow(void *p, void ***ap) {
	struct {
		void *av[2];
		t_integer arg1;
		t_RowCollection__RowType result;
	} *argstruct;
	argstruct = m_malloc(sizeof(*argstruct));
	*ap = argstruct->av;
	argstruct->av[0] = &(argstruct->arg1);
	pan_msg_consume(p, &(argstruct->arg1), sizeof(t_integer));
	argstruct->av[1] = &(argstruct->result);
	memset(&(argstruct->result), 0, sizeof(t_RowCollection__RowType));
}
static int sz_ret_RowCollection__AwaitRow(void **argv) {
	int sz = 0;
	sz += sz_RowCollection__RowType(argv[1]);
	return sz;
}
static pan_iovec_p ma_ret_RowCollection__AwaitRow(pan_iovec_p p, void **argv) {
	p = ma_RowCollection__RowType(p, argv[1]);
	return p;
}
static void um_ret_RowCollection__AwaitRow(void *p, void **argv) {
	free_RowCollection__RowType(argv[1]);
	um_RowCollection__RowType(p, argv[1]);
}
#else
static int sz_call_RowCollection__AwaitRow(void **argv) {
	int sz = 0;
	sz += sizeof(t_integer);
	return sz;
}
static char *ma_call_RowCollection__AwaitRow(char *p, void **argv) {
	memcpy(p, argv[0], sizeof(t_integer));
	p += sizeof(t_integer);
	return p;
}
static char *um_call_RowCollection__AwaitRow(char *p, void ***ap) {
	struct {
		void *av[2];
		t_integer arg1;
		t_RowCollection__RowType result;
	} *argstruct;
	argstruct = m_malloc(sizeof(*argstruct));
	*ap = argstruct->av;
	argstruct->av[0] = &(argstruct->arg1);
	memcpy(&(argstruct->arg1), p, sizeof(t_integer));
	p += sizeof(t_integer);
	argstruct->av[1] = &(argstruct->result);
	memset(&(argstruct->result), 0, sizeof(t_RowCollection__RowType));
	return p;
}
static int sz_ret_RowCollection__AwaitRow(void **argv) {
	int sz = 0;
	sz += sz_RowCollection__RowType(argv[1]);
	return sz;
}
static char *ma_ret_RowCollection__AwaitRow(char *p, void **argv) {
	p = ma_RowCollection__RowType(p, argv[1]);
	free_RowCollection__RowType(argv[1]);
	m_free((void *) argv);
	return p;
}
static char *um_ret_RowCollection__AwaitRow(char *p, void **argv) {
	free_RowCollection__RowType(argv[1]);
	p = um_RowCollection__RowType(p, argv[1]);
	return p;
}
#endif
static void fr_ret_RowCollection__AwaitRow(void **argv) {
	free_RowCollection__RowType(argv[1]);
	m_free((void *) argv);
}
static op_dscr od_RowCollection__RowCollection[] = {
	{ or__RowCollection__READ_, 0, &td_RowCollection__2, 0, 0, "RowCollection.READ_",
	  sz_call_RowCollection__READ_, ma_call_RowCollection__READ_, um_call_RowCollection__READ_, sz_ret_RowCollection__READ_, ma_ret_RowCollection__READ_, um_ret_RowCollection__READ_, fr_ret_RowCollection__READ_},
	{ 0, ow__RowCollection__WRITE_, &td_RowCollection__3, 1, OP_PURE_WRITE, "RowCollection.WRITE_",
	  sz_call_RowCollection__WRITE_, ma_call_RowCollection__WRITE_, um_call_RowCollection__WRITE_, sz_ret_RowCollection__WRITE_, ma_ret_RowCollection__WRITE_, um_ret_RowCollection__WRITE_, fr_ret_RowCollection__WRITE_},
	{ 0, ow__RowCollection__init, &td_RowCollection__init, 2, OP_PURE_WRITE, "RowCollection.init",
	  sz_call_RowCollection__init, ma_call_RowCollection__init, um_call_RowCollection__init, sz_ret_RowCollection__init, ma_ret_RowCollection__init, um_ret_RowCollection__init, fr_ret_RowCollection__init},
	{ 0, ow__RowCollection__AddRow, &td_RowCollection__AddRow, 3, OP_PURE_WRITE, "RowCollection.AddRow",
	  sz_call_RowCollection__AddRow, ma_call_RowCollection__AddRow, um_call_RowCollection__AddRow, sz_ret_RowCollection__AddRow, ma_ret_RowCollection__AddRow, um_ret_RowCollection__AddRow, fr_ret_RowCollection__AddRow},
	{ or__RowCollection__AwaitRow, 0, &td_RowCollection__AwaitRow, 4, OP_BLOCKING, "RowCollection.AwaitRow",
	  sz_call_RowCollection__AwaitRow, ma_call_RowCollection__AwaitRow, um_call_RowCollection__AwaitRow, sz_ret_RowCollection__AwaitRow, ma_ret_RowCollection__AwaitRow, um_ret_RowCollection__AwaitRow, fr_ret_RowCollection__AwaitRow}
};
static int sz_obj_RowCollection__RowCollection(t_object *op) {
    return sz_RowCollection__1(op->o_fields);
}
#ifdef PANDA4
static pan_iovec_p ma_obj_RowCollection__RowCollection(pan_iovec_p p, t_object *op) {
#else
static char *ma_obj_RowCollection__RowCollection(char *p, t_object *op) {
#endif
    return ma_RowCollection__1(p, op->o_fields);
}
#ifdef PANDA4
static void um_obj_RowCollection__RowCollection(void *p, t_object *op) {
#else
static char *um_obj_RowCollection__RowCollection(char *p, t_object *op) {
#endif
    if (! op->o_fields) op->o_fields = m_malloc(sizeof(t_RowCollection__1));
#ifdef PANDA4
    um_RowCollection__1(p, op->o_fields);
#else
    return um_RowCollection__1(p, op->o_fields);
#endif
}
static void free_RowCollection__1(void *);
static obj_info oi_RowCollection__RowCollection = { sz_obj_RowCollection__RowCollection, ma_obj_RowCollection__RowCollection, um_obj_RowCollection__RowCollection, free_RowCollection__1, od_RowCollection__RowCollection };
tp_dscr td_RowCollection__RowCollection = { OBJECT, sizeof(t_RowCollection__RowCollection), 15, &td_RowCollection__1, 5, &oi_RowCollection__RowCollection};
#ifdef PANDA4
int sz_RowCollection__RowCollection(t_RowCollection__RowCollection *a) {
    int sz = 0;
    sz = o_rts_nbytes(a, &td_RowCollection__RowCollection);
    sz += sz_RowCollection__1(a->o_fields);
    return sz;
}

pan_iovec_p ma_RowCollection__RowCollection(pan_iovec_p p, t_RowCollection__RowCollection *a) {
    p = o_rts_marshall(p, a, &td_RowCollection__RowCollection);
    p = ma_RowCollection__1(p, a->o_fields);
    return p;
}

void um_RowCollection__RowCollection(void *p, t_RowCollection__RowCollection *a) {
    o_rts_unmarshall(p, a, &td_RowCollection__RowCollection);
    a->o_fields = m_malloc(sizeof(t_RowCollection__1));
    um_RowCollection__1(p, a->o_fields);
}

#else
int sz_RowCollection__RowCollection(t_RowCollection__RowCollection *a) {
    int sz;
    sz = o_rts_nbytes(a, &td_RowCollection__RowCollection);
    sz += sz_RowCollection__1(a->o_fields);
    return sz;
}

char *ma_RowCollection__RowCollection(char *p, t_RowCollection__RowCollection *a) {
    p = o_rts_marshall(p, a, &td_RowCollection__RowCollection);
    p = ma_RowCollection__1(p, a->o_fields);
    return p;
}

char *um_RowCollection__RowCollection(char *p, t_RowCollection__RowCollection *a) {
    p = o_rts_unmarshall(p, a, &td_RowCollection__RowCollection);
    a->o_fields = m_malloc(sizeof(t_RowCollection__1));
    p = um_RowCollection__1(p, a->o_fields);
    return p;
}

#endif
void free_RowCollection__RowCollection(void *d) {
    t_RowCollection__RowCollection *dst = d;
    if (dst->o_fields && o_free(dst)) {
        free_RowCollection__1(dst->o_fields);
        m_free(dst->o_fields);
    }
}
void ass_RowCollection__RowCollection(void *dd, void *ss) {
    t_RowCollection__RowCollection *dst = dd, *src = ss;
    int op_flags = 0;
    t_object tmp;
    void *argv[1];
    int src_local;
    int dst_local;

    if (dst == src) return;
    argv[0] = &tmp;
    if (! dst->o_fields) {
        dst->o_fields = m_malloc(sizeof(t_RowCollection__1));
        memset(dst->o_fields, 0, sizeof(t_RowCollection__1));
        o_init_rtsdep(dst, &td_RowCollection__RowCollection, (char *) 0);
    }
    src_local = ! o_isshared(src);
    dst_local = ! o_isshared(dst);
    if (dst_local && (src_local || o_start_read(src))) {
        ass_RowCollection__1(dst->o_fields, src->o_fields);
        if (! src_local) o_end_read(src);
        return;
    }
    if (src_local && (dst_local || o_start_write(dst))) {
        ass_RowCollection__1(dst->o_fields, src->o_fields);
        if (! dst_local) o_end_write(dst, 1);
        return;
    }
    tmp.o_fields = m_malloc(sizeof(t_RowCollection__1));
    memset(tmp.o_fields, 0, sizeof(t_RowCollection__1));
    o_init_rtsdep(&tmp, &td_RowCollection__RowCollection, (char *) 0);
    if (src_local || o_start_read(src)) {
        ass_RowCollection__1(tmp.o_fields, src->o_fields);
        if (! src_local) o_end_read(src);
    } else {
        DoOperation(src, &op_flags, &td_RowCollection__RowCollection, /* READOBJ */ 0, 0, argv);
    }
    if (dst_local || o_start_write(dst)) {
        ass_RowCollection__1(dst->o_fields, tmp.o_fields);
        if (! dst_local) o_end_write(dst, 1);
    } else {
        DoOperation(dst, &op_flags, &td_RowCollection__RowCollection, /* WRITEOBJ */ 1, 0, argv);
    }
    o_free(&tmp);
    m_free(tmp.o_fields);
}
char *fn_RowCollection__RowCollection = "RowCollect.imp";
void ow_RowCollection__init(t_RowCollection__RowCollection *v__obj, t_integer v_size) {
    t_RowCollection__collection v_tmp;
    t_RowCollection__1 *v__ofldp = v__obj->o_fields;
    batinit_RowCollection__collection(&v_tmp, 1, ((t_integer) 1L), v_size, "RowCollection.init.tmp");
    ass_RowCollection__collection((&(v__ofldp->f_tab)), (&v_tmp));
    free_RowCollection__collection(&v_tmp);
}
void ow_RowCollection__AddRow(t_RowCollection__RowCollection *v__obj, t_integer v_iter, t_RowCollection__RowType *v_R) {
    t_RowCollection__RowType *tmp_1;
    t_RowCollection__1 *v__ofldp = v__obj->o_fields;
    a_check((&(v__ofldp->f_tab)), v_iter, 0, fn_RowCollection__RowCollection, 20);
    tmp_1 = (&((t_RowCollection__RowType *)(&(v__ofldp->f_tab))->a_data)[v_iter]);
    ass_RowCollection__RowType(tmp_1, v_R);
}
void or_RowCollection__AwaitRow(int *op_flags, t_RowCollection__RowCollection *v__obj, t_integer v_iter, t_RowCollection__RowType *v__result) {
    t_RowCollection__1 *v__ofldp = v__obj->o_fields;
    a_check((&(v__ofldp->f_tab)), v_iter, 0, fn_RowCollection__RowCollection, 26);
    a_check((&(v__ofldp->f_tab)), v_iter, 0, fn_RowCollection__RowCollection, 26);
    if ((a_lb((&((t_RowCollection__RowType *)(&(v__ofldp->f_tab))->a_data)[v_iter]), 0)<=a_ub((&((t_RowCollection__RowType *)(&(v__ofldp->f_tab))->a_data)[v_iter]), 0))) {
        a_check((&(v__ofldp->f_tab)), v_iter, 0, fn_RowCollection__RowCollection, 27);
        ass_RowCollection__RowType((v__result), (&((t_RowCollection__RowType *)(&(v__ofldp->f_tab))->a_data)[v_iter]));
        goto retlab;
        m_trap(FALL_THROUGH, fn_RowCollection__RowCollection, 31);
        goto retlab;
    }
    *op_flags |= BLOCKING;
    goto blocking_oper;
    m_trap(FALL_THROUGH, fn_RowCollection__RowCollection, 31);
retlab:;
blocking_oper:;
}
void init_t_RowCollection__RowCollection(t_RowCollection__RowCollection *v__obj, char *obj_name) {
    int opflags = 0;
    int *op_flags = &opflags;
    t_RowCollection__1 *v__ofldp;
    v__obj->o_fields = m_malloc(sizeof(t_RowCollection__1));
    memset(v__obj->o_fields, 0, sizeof(t_RowCollection__1));
    o_init_rtsdep(v__obj, &td_RowCollection__RowCollection, obj_name);
    v__ofldp = v__obj->o_fields;
    a_initialize(&(v__ofldp->f_tab), "RowCollection.tab");
}
void (ini_RowCollection__RowCollection)(void) {
	static int done = 0;

	if (done) return;
	done = 1;
	td_registration(&td_RowCollection__RowCollection) = m_ptrregister((void *)&td_RowCollection__RowCollection);
	m_objdescr_reg(&td_RowCollection__RowCollection, 5, "RowCollection");
}
