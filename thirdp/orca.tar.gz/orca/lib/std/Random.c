/* Produced by the Orca-to-C compiler */

/* Orca-to-C compiler, main branch, date: Tue Jun 30 16:56:47 MET DST 1998. */

#include <interface.h>
#include "Random.h"
static tp_dscr td_Random__2;
typedef t_integer t_Random__2;
static par_dscr fa_Random__2[] = {
	{ OUT, &td_Random__Random, ass_Random__Random, free_Random__Random}
};
static tp_dscr td_Random__2 = { FUNCTION, sizeof(t_Random__2), 0, 0, 1, fa_Random__2};
static tp_dscr td_Random__3;
typedef t_integer t_Random__3;
static par_dscr fa_Random__3[] = {
	{ IN, &td_Random__Random, ass_Random__Random, free_Random__Random}
};
static tp_dscr td_Random__3 = { FUNCTION, sizeof(t_Random__3), 0, 0, 1, fa_Random__3};
static par_dscr fa_Random__val[] = {
	{ OUT, &td_integer, ass_integer, 0}
};
tp_dscr td_Random__val = { FUNCTION, sizeof(t_Random__val), 0, 0, 1, fa_Random__val};
static par_dscr fa_Random__val01[] = {
	{ OUT, &td_real, ass_real, 0}
};
tp_dscr td_Random__val01 = { FUNCTION, sizeof(t_Random__val01), 0, 0, 1, fa_Random__val01};
static par_dscr fa_Random__init[] = {
	{ IN, &td_integer, ass_integer, 0}
};
tp_dscr td_Random__init = { FUNCTION, sizeof(t_Random__init), 0, 0, 1, fa_Random__init};
static tp_dscr td_Random__float_ar;
typedef ARRAY_TYPE(1) t_Random__float_ar;
static tp_dscr *ar_Random__float_ar[] = {
	&td_integer
};
static tp_dscr td_Random__float_ar = { ARRAY, sizeof(t_Random__float_ar), 5, &td_real, 1, ar_Random__float_ar};
#undef batinit_Random__float_ar
#define batinit_Random__float_ar(p, nestinit, lb0, ub0, s) { \
		a_allocate(p, 1, sizeof(t_real), lb0, ub0); \
	}
#ifdef PANDA4
static int sz_Random__float_ar(t_Random__float_ar *a) {
    int sz = 0;
    if (a->a_sz <= 0) return 1;
    sz = 1;
    sz ++;
    return sz;
}

static pan_iovec_p ma_Random__float_ar(pan_iovec_p p, t_Random__float_ar *a) {
    t_real *s;
    p->data = (void *) a;
    p->len = sizeof(*a);
    p++;
    if (a->a_sz <= 0) return p;
    s = (t_real *) a->a_data + a->a_offset;
    p->data = (void *)s;
    p->len = a->a_sz * sizeof(t_real);
    p++;
    return p;
}

static void um_Random__float_ar(void *p, t_Random__float_ar *a) {
    t_real *s;
    pan_msg_consume(p, a, sizeof(*a));
    if (a->a_sz <= 0) { a->a_sz = 0; a->a_data = 0;  return; }
    s = (t_real *) m_malloc(a->a_sz * sizeof(t_real));
    a->a_data = s - a->a_offset;
    pan_msg_consume(p, s, a->a_sz * sizeof(t_real));
}

#else
static int sz_Random__float_ar(t_Random__float_ar *a) {
    int sz;
    sz = 2 * sizeof(a->a_dims[0].a_lwb);
    if (a->a_sz <= 0) return sz;
    sz += a->a_sz * sizeof(t_real);
    return sz;
}

static char *ma_Random__float_ar(char *p, t_Random__float_ar *a) {
    t_real *s;
    put_tp(a->a_dims[0].a_lwb, p);
    put_tp(a->a_dims[0].a_nel, p);
    if (a->a_sz <= 0) return p;
    s = (t_real *) a->a_data + a->a_offset;
    memcpy(p, s, a->a_sz * sizeof(t_real));
    p += a->a_sz * sizeof(t_real);
    return p;
}

static char *um_Random__float_ar(char *p, t_Random__float_ar *a) {
    t_real *s;
    a->a_offset = 0;
    get_tp(a->a_dims[0].a_lwb, p);
    get_tp(a->a_dims[0].a_nel, p);
    a->a_sz = a->a_dims[0].a_nel;
    a->a_offset = a->a_dims[0].a_lwb;
    if (a->a_sz <= 0) { a->a_sz = 0; a->a_data = 0;  return p; }
    s = (t_real *) m_malloc(a->a_sz * sizeof(t_real));
    a->a_data = s - a->a_offset;
    memcpy(s, p, a->a_sz * sizeof(t_real));
    p += a->a_sz * sizeof(t_real);
    return p;
}

#endif
static int cmp_Random__float_ar(void *aa, void *bb) {
    t_Random__float_ar *a=aa; t_Random__float_ar *b=bb;
    size_t off;
    if (a == b) return 1;
    if (a->a_sz <= 0) return b->a_sz <= 0;
    if (a_lb(a, 0) != a_lb(b, 0)) return 0;
    if (a_ne(a, 0) != a_ne(b, 0)) return 0;
    off = a->a_offset * sizeof(t_real);
    return memcmp((char *)(a->a_data) + off, (char *) (b->a_data) + off, sizeof(t_real) * a->a_sz) == 0;
}
static void free_Random__float_ar(void *d) {
    t_Random__float_ar *dst = d;
    if (dst->a_sz <= 0) return;
    m_free(((t_real *) (dst->a_data)) + dst->a_offset);
    dst->a_sz = 0;
}
static void ass_Random__float_ar(void *dd, void *ss) {
    t_Random__float_ar *dst = dd, *src = ss;
    size_t off = sizeof(t_real) * src->a_offset;
    t_real *p,*q = (void *)((char *)(src->a_data)+off);
    size_t sz = src->a_sz * sizeof(t_real);

    if (dst == src) return;
    if (dst->a_sz != src->a_sz) {
	void *m;
	if (dst->a_sz > 0) free_Random__float_ar(dst);
	dst->a_sz = src->a_sz;
	dst->a_offset = src->a_offset;
	dst->a_dims[0] = src->a_dims[0];
	if (src->a_sz <= 0) return;
	m = m_malloc(sz);
	dst->a_data = (char *)m - off;
    } else {
	dst->a_dims[0] = src->a_dims[0];
	dst->a_data = (t_real *)(dst->a_data) - (src->a_offset - dst->a_offset);
	dst->a_offset = src->a_offset;
    }
    if (src->a_sz <= 0) return;
    p = (void *)((char *)(dst->a_data) + off);
    memcpy(p, q, sz);
}
static tp_dscr td_Random__int_ar;
typedef ARRAY_TYPE(1) t_Random__int_ar;
static tp_dscr *ar_Random__int_ar[] = {
	&td_integer
};
static tp_dscr td_Random__int_ar = { ARRAY, sizeof(t_Random__int_ar), 5, &td_integer, 1, ar_Random__int_ar};
#undef batinit_Random__int_ar
#define batinit_Random__int_ar(p, nestinit, lb0, ub0, s) { \
		a_allocate(p, 1, sizeof(t_integer), lb0, ub0); \
	}
#ifdef PANDA4
static int sz_Random__int_ar(t_Random__int_ar *a) {
    int sz = 0;
    if (a->a_sz <= 0) return 1;
    sz = 1;
    sz ++;
    return sz;
}

static pan_iovec_p ma_Random__int_ar(pan_iovec_p p, t_Random__int_ar *a) {
    t_integer *s;
    p->data = (void *) a;
    p->len = sizeof(*a);
    p++;
    if (a->a_sz <= 0) return p;
    s = (t_integer *) a->a_data + a->a_offset;
    p->data = (void *)s;
    p->len = a->a_sz * sizeof(t_integer);
    p++;
    return p;
}

static void um_Random__int_ar(void *p, t_Random__int_ar *a) {
    t_integer *s;
    pan_msg_consume(p, a, sizeof(*a));
    if (a->a_sz <= 0) { a->a_sz = 0; a->a_data = 0;  return; }
    s = (t_integer *) m_malloc(a->a_sz * sizeof(t_integer));
    a->a_data = s - a->a_offset;
    pan_msg_consume(p, s, a->a_sz * sizeof(t_integer));
}

#else
static int sz_Random__int_ar(t_Random__int_ar *a) {
    int sz;
    sz = 2 * sizeof(a->a_dims[0].a_lwb);
    if (a->a_sz <= 0) return sz;
    sz += a->a_sz * sizeof(t_integer);
    return sz;
}

static char *ma_Random__int_ar(char *p, t_Random__int_ar *a) {
    t_integer *s;
    put_tp(a->a_dims[0].a_lwb, p);
    put_tp(a->a_dims[0].a_nel, p);
    if (a->a_sz <= 0) return p;
    s = (t_integer *) a->a_data + a->a_offset;
    memcpy(p, s, a->a_sz * sizeof(t_integer));
    p += a->a_sz * sizeof(t_integer);
    return p;
}

static char *um_Random__int_ar(char *p, t_Random__int_ar *a) {
    t_integer *s;
    a->a_offset = 0;
    get_tp(a->a_dims[0].a_lwb, p);
    get_tp(a->a_dims[0].a_nel, p);
    a->a_sz = a->a_dims[0].a_nel;
    a->a_offset = a->a_dims[0].a_lwb;
    if (a->a_sz <= 0) { a->a_sz = 0; a->a_data = 0;  return p; }
    s = (t_integer *) m_malloc(a->a_sz * sizeof(t_integer));
    a->a_data = s - a->a_offset;
    memcpy(s, p, a->a_sz * sizeof(t_integer));
    p += a->a_sz * sizeof(t_integer);
    return p;
}

#endif
static int cmp_Random__int_ar(void *aa, void *bb) {
    t_Random__int_ar *a=aa; t_Random__int_ar *b=bb;
    size_t off;
    if (a == b) return 1;
    if (a->a_sz <= 0) return b->a_sz <= 0;
    if (a_lb(a, 0) != a_lb(b, 0)) return 0;
    if (a_ne(a, 0) != a_ne(b, 0)) return 0;
    off = a->a_offset * sizeof(t_integer);
    return memcmp((char *)(a->a_data) + off, (char *) (b->a_data) + off, sizeof(t_integer) * a->a_sz) == 0;
}
static void free_Random__int_ar(void *d) {
    t_Random__int_ar *dst = d;
    if (dst->a_sz <= 0) return;
    m_free(((t_integer *) (dst->a_data)) + dst->a_offset);
    dst->a_sz = 0;
}
static void ass_Random__int_ar(void *dd, void *ss) {
    t_Random__int_ar *dst = dd, *src = ss;
    size_t off = sizeof(t_integer) * src->a_offset;
    t_integer *p,*q = (void *)((char *)(src->a_data)+off);
    size_t sz = src->a_sz * sizeof(t_integer);

    if (dst == src) return;
    if (dst->a_sz != src->a_sz) {
	void *m;
	if (dst->a_sz > 0) free_Random__int_ar(dst);
	dst->a_sz = src->a_sz;
	dst->a_offset = src->a_offset;
	dst->a_dims[0] = src->a_dims[0];
	if (src->a_sz <= 0) return;
	m = m_malloc(sz);
	dst->a_data = (char *)m - off;
    } else {
	dst->a_dims[0] = src->a_dims[0];
	dst->a_data = (t_integer *)(dst->a_data) - (src->a_offset - dst->a_offset);
	dst->a_offset = src->a_offset;
    }
    if (src->a_sz <= 0) return;
    p = (void *)((char *)(dst->a_data) + off);
    memcpy(p, q, sz);
}
static tp_dscr td_Random__1;
typedef struct t_Random__1 {
	t_Random__int_ar f_term;
	t_Random__int_ar f_fac;
	t_Random__int_ar f_mod;
	t_Random__float_ar f_inv_mod;
	t_Random__int_ar f_current;
	t_Random__float_ar f_table;
} t_Random__1;
static fld_dscr rf_Random__1[] = {
	{ offsetof(t_Random__1, f_term), &td_Random__int_ar},
	{ offsetof(t_Random__1, f_fac), &td_Random__int_ar},
	{ offsetof(t_Random__1, f_mod), &td_Random__int_ar},
	{ offsetof(t_Random__1, f_inv_mod), &td_Random__float_ar},
	{ offsetof(t_Random__1, f_current), &td_Random__int_ar},
	{ offsetof(t_Random__1, f_table), &td_Random__float_ar}
};
static tp_dscr td_Random__1 = { RECORD, sizeof(t_Random__1), 5, 0, 6, rf_Random__1};
#undef init_t_Random__1
#define init_t_Random__1(p, s) { \
		a_initialize(&((p)->f_term), s); \
		a_initialize(&((p)->f_fac), s); \
		a_initialize(&((p)->f_mod), s); \
batinit_Random__float_ar(&((p)->f_inv_mod), 1, ((t_integer) 1L), ((t_integer) 3L), s); \
batinit_Random__int_ar(&((p)->f_current), 1, ((t_integer) 1L), ((t_integer) 3L), s); \
batinit_Random__float_ar(&((p)->f_table), 1, ((t_integer) 1L), ((t_integer) 97L), s); \
	}
#ifdef PANDA4
static int sz_Random__1(t_Random__1 *a) {
    int sz = 0;
    sz += sz_Random__int_ar(&(a->f_term));
    sz += sz_Random__int_ar(&(a->f_fac));
    sz += sz_Random__int_ar(&(a->f_mod));
    sz += sz_Random__float_ar(&(a->f_inv_mod));
    sz += sz_Random__int_ar(&(a->f_current));
    sz += sz_Random__float_ar(&(a->f_table));
    return sz;
}

static pan_iovec_p ma_Random__1(pan_iovec_p p, t_Random__1 *a) {
    p = ma_Random__int_ar(p, &(a->f_term));
    p = ma_Random__int_ar(p, &(a->f_fac));
    p = ma_Random__int_ar(p, &(a->f_mod));
    p = ma_Random__float_ar(p, &(a->f_inv_mod));
    p = ma_Random__int_ar(p, &(a->f_current));
    p = ma_Random__float_ar(p, &(a->f_table));
    return p;
}

static void um_Random__1(void *p, t_Random__1 *a) {
    um_Random__int_ar(p, &(a->f_term));
    um_Random__int_ar(p, &(a->f_fac));
    um_Random__int_ar(p, &(a->f_mod));
    um_Random__float_ar(p, &(a->f_inv_mod));
    um_Random__int_ar(p, &(a->f_current));
    um_Random__float_ar(p, &(a->f_table));
}

#else
static int sz_Random__1(t_Random__1 *a) {
    int sz;
    sz = 0;
    sz += sz_Random__int_ar(&(a->f_term));
    sz += sz_Random__int_ar(&(a->f_fac));
    sz += sz_Random__int_ar(&(a->f_mod));
    sz += sz_Random__float_ar(&(a->f_inv_mod));
    sz += sz_Random__int_ar(&(a->f_current));
    sz += sz_Random__float_ar(&(a->f_table));
    return sz;
}

static char *ma_Random__1(char *p, t_Random__1 *a) {
    p = ma_Random__int_ar(p, &(a->f_term));
    p = ma_Random__int_ar(p, &(a->f_fac));
    p = ma_Random__int_ar(p, &(a->f_mod));
    p = ma_Random__float_ar(p, &(a->f_inv_mod));
    p = ma_Random__int_ar(p, &(a->f_current));
    p = ma_Random__float_ar(p, &(a->f_table));
    return p;
}

static char *um_Random__1(char *p, t_Random__1 *a) {
    p = um_Random__int_ar(p, &(a->f_term));
    p = um_Random__int_ar(p, &(a->f_fac));
    p = um_Random__int_ar(p, &(a->f_mod));
    p = um_Random__float_ar(p, &(a->f_inv_mod));
    p = um_Random__int_ar(p, &(a->f_current));
    p = um_Random__float_ar(p, &(a->f_table));
    return p;
}

#endif
static int cmp_Random__1(void *aa, void *bb) {
    t_Random__1 *a=aa; t_Random__1 *b=bb;
    if (! cmp_Random__int_ar(&(a->f_term), &(b->f_term))) return 0;
    if (! cmp_Random__int_ar(&(a->f_fac), &(b->f_fac))) return 0;
    if (! cmp_Random__int_ar(&(a->f_mod), &(b->f_mod))) return 0;
    if (! cmp_Random__float_ar(&(a->f_inv_mod), &(b->f_inv_mod))) return 0;
    if (! cmp_Random__int_ar(&(a->f_current), &(b->f_current))) return 0;
    if (! cmp_Random__float_ar(&(a->f_table), &(b->f_table))) return 0;
    return 1;
}
static void free_Random__1(void *d) {
    t_Random__1 *dst = d;
    free_Random__int_ar(&(dst->f_term));
    free_Random__int_ar(&(dst->f_fac));
    free_Random__int_ar(&(dst->f_mod));
    free_Random__float_ar(&(dst->f_inv_mod));
    free_Random__int_ar(&(dst->f_current));
    free_Random__float_ar(&(dst->f_table));
}
static void ass_Random__1(void *dd, void *ss) {
    t_Random__1 *dst = dd, *src = ss;
    if (dst == src) return;
    ass_Random__int_ar(&(dst->f_term), &(src->f_term));
    ass_Random__int_ar(&(dst->f_fac), &(src->f_fac));
    ass_Random__int_ar(&(dst->f_mod), &(src->f_mod));
    ass_Random__float_ar(&(dst->f_inv_mod), &(src->f_inv_mod));
    ass_Random__int_ar(&(dst->f_current), &(src->f_current));
    ass_Random__float_ar(&(dst->f_table), &(src->f_table));
}
static int or__Random__READ_(t_object *v_obj, void **v__args) {
    init_t_Random__Random((t_object *) (v__args[0]), "result");
    ass_Random__1(((t_object *) (v__args[0]))->o_fields, v_obj->o_fields);
    return 0;
}
static int ow__Random__WRITE_(t_object *v_obj, void **v__args) {
    ass_Random__1(v_obj->o_fields, ((t_object *) (v__args[0]))->o_fields);
    return 0;
}
t_integer ow_Random__val(t_Random__Random *v__obj);
static int ow__Random__val(t_object *v_obj, void **v__args) {
    *((t_integer *) v__args[0]) = ow_Random__val(v_obj);
    return 0;
}
t_real ow_Random__val01(t_Random__Random *v__obj);
static int ow__Random__val01(t_object *v_obj, void **v__args) {
    *((t_real *) v__args[0]) = ow_Random__val01(v_obj);
    return 0;
}
void ow_Random__init(t_Random__Random *v__obj, t_integer v_seed);
static int ow__Random__init(t_object *v_obj, void **v__args) {
    ow_Random__init(v_obj,*((t_integer *) v__args[0]));
    return 0;
}
#ifdef PANDA4
static int sz_call_Random__READ_(void **argv) {
	int sz = 0;
	return sz;
}
static pan_iovec_p ma_call_Random__READ_(pan_iovec_p p, void **argv) {
	return p;
}
static void um_call_Random__READ_(void *p, void ***ap) {
	struct {
		void *av[1];
		t_Random__Random arg1;
	} *argstruct;
	argstruct = m_malloc(sizeof(*argstruct));
	*ap = argstruct->av;
	argstruct->av[0] = &(argstruct->arg1);
	memset(&(argstruct->arg1), 0, sizeof(t_Random__Random));
}
static int sz_ret_Random__READ_(void **argv) {
	int sz = 0;
	sz += sz_Random__Random(argv[0]);
	return sz;
}
static pan_iovec_p ma_ret_Random__READ_(pan_iovec_p p, void **argv) {
	p = ma_Random__Random(p, argv[0]);
	return p;
}
static void um_ret_Random__READ_(void *p, void **argv) {
	free_Random__Random(argv[0]);
	um_Random__Random(p, argv[0]);
}
#else
static int sz_call_Random__READ_(void **argv) {
	int sz = 0;
	return sz;
}
static char *ma_call_Random__READ_(char *p, void **argv) {
	return p;
}
static char *um_call_Random__READ_(char *p, void ***ap) {
	struct {
		void *av[1];
		t_Random__Random arg1;
	} *argstruct;
	argstruct = m_malloc(sizeof(*argstruct));
	*ap = argstruct->av;
	argstruct->av[0] = &(argstruct->arg1);
	memset(&(argstruct->arg1), 0, sizeof(t_Random__Random));
	return p;
}
static int sz_ret_Random__READ_(void **argv) {
	int sz = 0;
	sz += sz_Random__Random(argv[0]);
	return sz;
}
static char *ma_ret_Random__READ_(char *p, void **argv) {
	p = ma_Random__Random(p, argv[0]);
	free_Random__Random(argv[0]);
	m_free((void *) argv);
	return p;
}
static char *um_ret_Random__READ_(char *p, void **argv) {
	free_Random__Random(argv[0]);
	p = um_Random__Random(p, argv[0]);
	return p;
}
#endif
static void fr_ret_Random__READ_(void **argv) {
	free_Random__Random(argv[0]);
	m_free((void *) argv);
}
#ifdef PANDA4
static int sz_call_Random__WRITE_(void **argv) {
	int sz = 0;
	sz += sz_Random__Random(argv[0]);
	return sz;
}
static pan_iovec_p ma_call_Random__WRITE_(pan_iovec_p p, void **argv) {
	p = ma_Random__Random(p, argv[0]);
	return p;
}
static void um_call_Random__WRITE_(void *p, void ***ap) {
	struct {
		void *av[1];
		t_Random__Random arg1;
	} *argstruct;
	argstruct = m_malloc(sizeof(*argstruct));
	*ap = argstruct->av;
	argstruct->av[0] = &(argstruct->arg1);
	um_Random__Random(p, &(argstruct->arg1));
}
static int sz_ret_Random__WRITE_(void **argv) {
	int sz = 0;
	return sz;
}
static pan_iovec_p ma_ret_Random__WRITE_(pan_iovec_p p, void **argv) {
	return p;
}
static void um_ret_Random__WRITE_(void *p, void **argv) {
}
#else
static int sz_call_Random__WRITE_(void **argv) {
	int sz = 0;
	sz += sz_Random__Random(argv[0]);
	return sz;
}
static char *ma_call_Random__WRITE_(char *p, void **argv) {
	p = ma_Random__Random(p, argv[0]);
	return p;
}
static char *um_call_Random__WRITE_(char *p, void ***ap) {
	struct {
		void *av[1];
		t_Random__Random arg1;
	} *argstruct;
	argstruct = m_malloc(sizeof(*argstruct));
	*ap = argstruct->av;
	argstruct->av[0] = &(argstruct->arg1);
	p = um_Random__Random(p, &(argstruct->arg1));
	return p;
}
static int sz_ret_Random__WRITE_(void **argv) {
	int sz = 0;
	return sz;
}
static char *ma_ret_Random__WRITE_(char *p, void **argv) {
	free_Random__Random(argv[0]);
	m_free((void *) argv);
	return p;
}
static char *um_ret_Random__WRITE_(char *p, void **argv) {
	return p;
}
#endif
static void fr_ret_Random__WRITE_(void **argv) {
	free_Random__Random(argv[0]);
	m_free((void *) argv);
}
#ifdef PANDA4
static int sz_call_Random__val(void **argv) {
	int sz = 0;
	return sz;
}
static pan_iovec_p ma_call_Random__val(pan_iovec_p p, void **argv) {
	return p;
}
static void um_call_Random__val(void *p, void ***ap) {
	struct {
		void *av[1];
		t_integer result;
	} *argstruct;
	argstruct = m_malloc(sizeof(*argstruct));
	*ap = argstruct->av;
	argstruct->av[0] = &(argstruct->result);
}
static int sz_ret_Random__val(void **argv) {
	int sz = 0;
	sz++;
	return sz;
}
static pan_iovec_p ma_ret_Random__val(pan_iovec_p p, void **argv) {
	p->data = argv[0];
	p->len = sizeof(t_integer);
	p++;
	return p;
}
static void um_ret_Random__val(void *p, void **argv) {
	pan_msg_consume(p, argv[0], sizeof(t_integer));
}
#else
static int sz_call_Random__val(void **argv) {
	int sz = 0;
	return sz;
}
static char *ma_call_Random__val(char *p, void **argv) {
	return p;
}
static char *um_call_Random__val(char *p, void ***ap) {
	struct {
		void *av[1];
		t_integer result;
	} *argstruct;
	argstruct = m_malloc(sizeof(*argstruct));
	*ap = argstruct->av;
	argstruct->av[0] = &(argstruct->result);
	return p;
}
static int sz_ret_Random__val(void **argv) {
	int sz = 0;
	sz += sizeof(t_integer);
	return sz;
}
static char *ma_ret_Random__val(char *p, void **argv) {
	memcpy(p, argv[0], sizeof(t_integer));
	p += sizeof(t_integer);
	m_free((void *) argv);
	return p;
}
static char *um_ret_Random__val(char *p, void **argv) {
	memcpy(argv[0], p, sizeof(t_integer));
	p += sizeof(t_integer);
	return p;
}
#endif
static void fr_ret_Random__val(void **argv) {
	m_free((void *) argv);
}
#ifdef PANDA4
static int sz_call_Random__val01(void **argv) {
	int sz = 0;
	return sz;
}
static pan_iovec_p ma_call_Random__val01(pan_iovec_p p, void **argv) {
	return p;
}
static void um_call_Random__val01(void *p, void ***ap) {
	struct {
		void *av[1];
		t_real result;
	} *argstruct;
	argstruct = m_malloc(sizeof(*argstruct));
	*ap = argstruct->av;
	argstruct->av[0] = &(argstruct->result);
}
static int sz_ret_Random__val01(void **argv) {
	int sz = 0;
	sz++;
	return sz;
}
static pan_iovec_p ma_ret_Random__val01(pan_iovec_p p, void **argv) {
	p->data = argv[0];
	p->len = sizeof(t_real);
	p++;
	return p;
}
static void um_ret_Random__val01(void *p, void **argv) {
	pan_msg_consume(p, argv[0], sizeof(t_real));
}
#else
static int sz_call_Random__val01(void **argv) {
	int sz = 0;
	return sz;
}
static char *ma_call_Random__val01(char *p, void **argv) {
	return p;
}
static char *um_call_Random__val01(char *p, void ***ap) {
	struct {
		void *av[1];
		t_real result;
	} *argstruct;
	argstruct = m_malloc(sizeof(*argstruct));
	*ap = argstruct->av;
	argstruct->av[0] = &(argstruct->result);
	return p;
}
static int sz_ret_Random__val01(void **argv) {
	int sz = 0;
	sz += sizeof(t_real);
	return sz;
}
static char *ma_ret_Random__val01(char *p, void **argv) {
	memcpy(p, argv[0], sizeof(t_real));
	p += sizeof(t_real);
	m_free((void *) argv);
	return p;
}
static char *um_ret_Random__val01(char *p, void **argv) {
	memcpy(argv[0], p, sizeof(t_real));
	p += sizeof(t_real);
	return p;
}
#endif
static void fr_ret_Random__val01(void **argv) {
	m_free((void *) argv);
}
#ifdef PANDA4
static int sz_call_Random__init(void **argv) {
	int sz = 0;
	sz++;
	return sz;
}
static pan_iovec_p ma_call_Random__init(pan_iovec_p p, void **argv) {
	p->data = argv[0];
	p->len = sizeof(t_integer);
	p++;
	return p;
}
static void um_call_Random__init(void *p, void ***ap) {
	struct {
		void *av[1];
		t_integer arg1;
	} *argstruct;
	argstruct = m_malloc(sizeof(*argstruct));
	*ap = argstruct->av;
	argstruct->av[0] = &(argstruct->arg1);
	pan_msg_consume(p, &(argstruct->arg1), sizeof(t_integer));
}
static int sz_ret_Random__init(void **argv) {
	int sz = 0;
	return sz;
}
static pan_iovec_p ma_ret_Random__init(pan_iovec_p p, void **argv) {
	return p;
}
static void um_ret_Random__init(void *p, void **argv) {
}
#else
static int sz_call_Random__init(void **argv) {
	int sz = 0;
	sz += sizeof(t_integer);
	return sz;
}
static char *ma_call_Random__init(char *p, void **argv) {
	memcpy(p, argv[0], sizeof(t_integer));
	p += sizeof(t_integer);
	return p;
}
static char *um_call_Random__init(char *p, void ***ap) {
	struct {
		void *av[1];
		t_integer arg1;
	} *argstruct;
	argstruct = m_malloc(sizeof(*argstruct));
	*ap = argstruct->av;
	argstruct->av[0] = &(argstruct->arg1);
	memcpy(&(argstruct->arg1), p, sizeof(t_integer));
	p += sizeof(t_integer);
	return p;
}
static int sz_ret_Random__init(void **argv) {
	int sz = 0;
	return sz;
}
static char *ma_ret_Random__init(char *p, void **argv) {
	m_free((void *) argv);
	return p;
}
static char *um_ret_Random__init(char *p, void **argv) {
	return p;
}
#endif
static void fr_ret_Random__init(void **argv) {
	m_free((void *) argv);
}
static op_dscr od_Random__Random[] = {
	{ or__Random__READ_, 0, &td_Random__2, 0, 0, "Random.READ_",
	  sz_call_Random__READ_, ma_call_Random__READ_, um_call_Random__READ_, sz_ret_Random__READ_, ma_ret_Random__READ_, um_ret_Random__READ_, fr_ret_Random__READ_},
	{ 0, ow__Random__WRITE_, &td_Random__3, 1, OP_PURE_WRITE, "Random.WRITE_",
	  sz_call_Random__WRITE_, ma_call_Random__WRITE_, um_call_Random__WRITE_, sz_ret_Random__WRITE_, ma_ret_Random__WRITE_, um_ret_Random__WRITE_, fr_ret_Random__WRITE_},
	{ 0, ow__Random__val, &td_Random__val, 2, 0, "Random.val",
	  sz_call_Random__val, ma_call_Random__val, um_call_Random__val, sz_ret_Random__val, ma_ret_Random__val, um_ret_Random__val, fr_ret_Random__val},
	{ 0, ow__Random__val01, &td_Random__val01, 3, 0, "Random.val01",
	  sz_call_Random__val01, ma_call_Random__val01, um_call_Random__val01, sz_ret_Random__val01, ma_ret_Random__val01, um_ret_Random__val01, fr_ret_Random__val01},
	{ 0, ow__Random__init, &td_Random__init, 4, OP_PURE_WRITE, "Random.init",
	  sz_call_Random__init, ma_call_Random__init, um_call_Random__init, sz_ret_Random__init, ma_ret_Random__init, um_ret_Random__init, fr_ret_Random__init}
};
static int sz_obj_Random__Random(t_object *op) {
    return sz_Random__1(op->o_fields);
}
#ifdef PANDA4
static pan_iovec_p ma_obj_Random__Random(pan_iovec_p p, t_object *op) {
#else
static char *ma_obj_Random__Random(char *p, t_object *op) {
#endif
    return ma_Random__1(p, op->o_fields);
}
#ifdef PANDA4
static void um_obj_Random__Random(void *p, t_object *op) {
#else
static char *um_obj_Random__Random(char *p, t_object *op) {
#endif
    if (! op->o_fields) op->o_fields = m_malloc(sizeof(t_Random__1));
#ifdef PANDA4
    um_Random__1(p, op->o_fields);
#else
    return um_Random__1(p, op->o_fields);
#endif
}
static void free_Random__1(void *);
static obj_info oi_Random__Random = { sz_obj_Random__Random, ma_obj_Random__Random, um_obj_Random__Random, free_Random__1, od_Random__Random };
tp_dscr td_Random__Random = { OBJECT, sizeof(t_Random__Random), 15, &td_Random__1, 5, &oi_Random__Random};
#ifdef PANDA4
int sz_Random__Random(t_Random__Random *a) {
    int sz = 0;
    sz = o_rts_nbytes(a, &td_Random__Random);
    sz += sz_Random__1(a->o_fields);
    return sz;
}

pan_iovec_p ma_Random__Random(pan_iovec_p p, t_Random__Random *a) {
    p = o_rts_marshall(p, a, &td_Random__Random);
    p = ma_Random__1(p, a->o_fields);
    return p;
}

void um_Random__Random(void *p, t_Random__Random *a) {
    o_rts_unmarshall(p, a, &td_Random__Random);
    a->o_fields = m_malloc(sizeof(t_Random__1));
    um_Random__1(p, a->o_fields);
}

#else
int sz_Random__Random(t_Random__Random *a) {
    int sz;
    sz = o_rts_nbytes(a, &td_Random__Random);
    sz += sz_Random__1(a->o_fields);
    return sz;
}

char *ma_Random__Random(char *p, t_Random__Random *a) {
    p = o_rts_marshall(p, a, &td_Random__Random);
    p = ma_Random__1(p, a->o_fields);
    return p;
}

char *um_Random__Random(char *p, t_Random__Random *a) {
    p = o_rts_unmarshall(p, a, &td_Random__Random);
    a->o_fields = m_malloc(sizeof(t_Random__1));
    p = um_Random__1(p, a->o_fields);
    return p;
}

#endif
void free_Random__Random(void *d) {
    t_Random__Random *dst = d;
    if (dst->o_fields && o_free(dst)) {
        free_Random__1(dst->o_fields);
        m_free(dst->o_fields);
    }
}
void ass_Random__Random(void *dd, void *ss) {
    t_Random__Random *dst = dd, *src = ss;
    int op_flags = 0;
    t_object tmp;
    void *argv[1];
    int src_local;
    int dst_local;

    if (dst == src) return;
    argv[0] = &tmp;
    if (! dst->o_fields) {
        dst->o_fields = m_malloc(sizeof(t_Random__1));
        memset(dst->o_fields, 0, sizeof(t_Random__1));
        o_init_rtsdep(dst, &td_Random__Random, (char *) 0);
    }
    src_local = ! o_isshared(src);
    dst_local = ! o_isshared(dst);
    if (dst_local && (src_local || o_start_read(src))) {
        ass_Random__1(dst->o_fields, src->o_fields);
        if (! src_local) o_end_read(src);
        return;
    }
    if (src_local && (dst_local || o_start_write(dst))) {
        ass_Random__1(dst->o_fields, src->o_fields);
        if (! dst_local) o_end_write(dst, 1);
        return;
    }
    tmp.o_fields = m_malloc(sizeof(t_Random__1));
    memset(tmp.o_fields, 0, sizeof(t_Random__1));
    o_init_rtsdep(&tmp, &td_Random__Random, (char *) 0);
    if (src_local || o_start_read(src)) {
        ass_Random__1(tmp.o_fields, src->o_fields);
        if (! src_local) o_end_read(src);
    } else {
        DoOperation(src, &op_flags, &td_Random__Random, /* READOBJ */ 0, 0, argv);
    }
    if (dst_local || o_start_write(dst)) {
        ass_Random__1(dst->o_fields, tmp.o_fields);
        if (! dst_local) o_end_write(dst, 1);
    } else {
        DoOperation(dst, &op_flags, &td_Random__Random, /* WRITEOBJ */ 1, 0, argv);
    }
    o_free(&tmp);
    m_free(tmp.o_fields);
}
char *fn_Random__Random = "Random.imp";
t_integer ow_Random__val(t_Random__Random *v__obj) {
    int opflags = NESTED;
    int *op_flags = &opflags;
    void *argtab[1];
    t_integer v__result = 0;
    t_Random__1 *v__ofldp = v__obj->o_fields;
    (v__result) = ((t_integer) (ow_Random__val01(v__obj)*((t_real) 2.147483648e+9)));
    goto retlab;
    m_trap(FALL_THROUGH, fn_Random__Random, 85);
retlab:;
    return v__result;
}
t_real ow_Random__val01(t_Random__Random *v__obj) {
    t_integer v_ix;
    t_real v_r;
    t_integer tmp_4;
    t_integer tmp_3;
    t_integer tmp_2;
    t_integer tmp_1;
    t_real v__result = 0;
    t_Random__1 *v__ofldp = v__obj->o_fields;
    a_check((&(v__ofldp->f_current)), ((t_integer) 1L), 0, fn_Random__Random, 45);
    a_check((&(v__ofldp->f_mod)), ((t_integer) 1L), 0, fn_Random__Random, 45);
    a_check((&(v__ofldp->f_term)), ((t_integer) 1L), 0, fn_Random__Random, 45);
    a_check((&(v__ofldp->f_current)), ((t_integer) 1L), 0, fn_Random__Random, 45);
    a_check((&(v__ofldp->f_fac)), ((t_integer) 1L), 0, fn_Random__Random, 45);
    tmp_1 = (*(&((t_integer *)(&(v__ofldp->f_mod))->a_data)[((t_integer) 1L)]));
    m_modcheck(tmp_1, fn_Random__Random, 45);
    (*(&((t_integer *)(&(v__ofldp->f_current))->a_data)[((t_integer) 1L)])) = m_mod((((*(&((t_integer *)(&(v__ofldp->f_fac))->a_data)[((t_integer) 1L)]))*(*(&((t_integer *)(&(v__ofldp->f_current))->a_data)[((t_integer) 1L)])))+(*(&((t_integer *)(&(v__ofldp->f_term))->a_data)[((t_integer) 1L)]))),tmp_1);
    a_check((&(v__ofldp->f_current)), ((t_integer) 2L), 0, fn_Random__Random, 46);
    a_check((&(v__ofldp->f_mod)), ((t_integer) 2L), 0, fn_Random__Random, 46);
    a_check((&(v__ofldp->f_term)), ((t_integer) 2L), 0, fn_Random__Random, 46);
    a_check((&(v__ofldp->f_current)), ((t_integer) 2L), 0, fn_Random__Random, 46);
    a_check((&(v__ofldp->f_fac)), ((t_integer) 2L), 0, fn_Random__Random, 46);
    tmp_2 = (*(&((t_integer *)(&(v__ofldp->f_mod))->a_data)[((t_integer) 2L)]));
    m_modcheck(tmp_2, fn_Random__Random, 46);
    (*(&((t_integer *)(&(v__ofldp->f_current))->a_data)[((t_integer) 2L)])) = m_mod((((*(&((t_integer *)(&(v__ofldp->f_fac))->a_data)[((t_integer) 2L)]))*(*(&((t_integer *)(&(v__ofldp->f_current))->a_data)[((t_integer) 2L)])))+(*(&((t_integer *)(&(v__ofldp->f_term))->a_data)[((t_integer) 2L)]))),tmp_2);
    a_check((&(v__ofldp->f_current)), ((t_integer) 3L), 0, fn_Random__Random, 47);
    a_check((&(v__ofldp->f_mod)), ((t_integer) 3L), 0, fn_Random__Random, 47);
    a_check((&(v__ofldp->f_term)), ((t_integer) 3L), 0, fn_Random__Random, 47);
    a_check((&(v__ofldp->f_current)), ((t_integer) 3L), 0, fn_Random__Random, 47);
    a_check((&(v__ofldp->f_fac)), ((t_integer) 3L), 0, fn_Random__Random, 47);
    tmp_3 = (*(&((t_integer *)(&(v__ofldp->f_mod))->a_data)[((t_integer) 3L)]));
    m_modcheck(tmp_3, fn_Random__Random, 47);
    (*(&((t_integer *)(&(v__ofldp->f_current))->a_data)[((t_integer) 3L)])) = m_mod((((*(&((t_integer *)(&(v__ofldp->f_fac))->a_data)[((t_integer) 3L)]))*(*(&((t_integer *)(&(v__ofldp->f_current))->a_data)[((t_integer) 3L)])))+(*(&((t_integer *)(&(v__ofldp->f_term))->a_data)[((t_integer) 3L)]))),tmp_3);
    a_check((&(v__ofldp->f_mod)), ((t_integer) 3L), 0, fn_Random__Random, 48);
    a_check((&(v__ofldp->f_current)), ((t_integer) 3L), 0, fn_Random__Random, 48);
    tmp_4 = (*(&((t_integer *)(&(v__ofldp->f_mod))->a_data)[((t_integer) 3L)]));
    m_divcheck(tmp_4, fn_Random__Random, 48);
    v_ix = (((t_integer) 1L)+m_div((((t_integer) 97L)*(*(&((t_integer *)(&(v__ofldp->f_current))->a_data)[((t_integer) 3L)]))),tmp_4));
    a_check((&(v__ofldp->f_table)), v_ix, 0, fn_Random__Random, 49);
    v_r = (*(&((t_real *)(&(v__ofldp->f_table))->a_data)[v_ix]));
    a_check((&(v__ofldp->f_table)), v_ix, 0, fn_Random__Random, 50);
    a_check((&(v__ofldp->f_inv_mod)), ((t_integer) 1L), 0, fn_Random__Random, 51);
    a_check((&(v__ofldp->f_inv_mod)), ((t_integer) 2L), 0, fn_Random__Random, 51);
    a_check((&(v__ofldp->f_current)), ((t_integer) 2L), 0, fn_Random__Random, 51);
    a_check((&(v__ofldp->f_current)), ((t_integer) 1L), 0, fn_Random__Random, 50);
    (*(&((t_real *)(&(v__ofldp->f_table))->a_data)[v_ix])) = ((((t_real) (*(&((t_integer *)(&(v__ofldp->f_current))->a_data)[((t_integer) 1L)])))+(((t_real) (*(&((t_integer *)(&(v__ofldp->f_current))->a_data)[((t_integer) 2L)])))*(*(&((t_real *)(&(v__ofldp->f_inv_mod))->a_data)[((t_integer) 2L)]))))*(*(&((t_real *)(&(v__ofldp->f_inv_mod))->a_data)[((t_integer) 1L)])));
    (v__result) = v_r;
    goto retlab;
    m_trap(FALL_THROUGH, fn_Random__Random, 85);
retlab:;
    return v__result;
}
void ow_Random__init(t_Random__Random *v__obj, t_integer v_seed) {
    t_integer tmp_9;
    t_integer tmp_8;
    t_integer tmp_7;
    t_integer tmp_6;
    t_integer tmp_5;
    t_integer tmp_4;
    t_integer tmp_3;
    t_real tmp_2;
    t_integer tmp_1;
    t_Random__1 *v__ofldp = v__obj->o_fields;
    free_Random__int_ar((&(v__ofldp->f_term)));
    a_allocate((&(v__ofldp->f_term)), 1, sizeof(t_integer), 1, 3);
    ((t_integer *)(&(v__ofldp->f_term))->a_data)[1] = ((t_integer) 54773L);
    ((t_integer *)(&(v__ofldp->f_term))->a_data)[2] = ((t_integer) 28411L);
    ((t_integer *)(&(v__ofldp->f_term))->a_data)[3] = ((t_integer) 51349L);
    free_Random__int_ar((&(v__ofldp->f_fac)));
    a_allocate((&(v__ofldp->f_fac)), 1, sizeof(t_integer), 1, 3);
    ((t_integer *)(&(v__ofldp->f_fac))->a_data)[1] = ((t_integer) 7141L);
    ((t_integer *)(&(v__ofldp->f_fac))->a_data)[2] = ((t_integer) 8121L);
    ((t_integer *)(&(v__ofldp->f_fac))->a_data)[3] = ((t_integer) 4561L);
    free_Random__int_ar((&(v__ofldp->f_mod)));
    a_allocate((&(v__ofldp->f_mod)), 1, sizeof(t_integer), 1, 3);
    ((t_integer *)(&(v__ofldp->f_mod))->a_data)[1] = ((t_integer) 259200L);
    ((t_integer *)(&(v__ofldp->f_mod))->a_data)[2] = ((t_integer) 134456L);
    ((t_integer *)(&(v__ofldp->f_mod))->a_data)[3] = ((t_integer) 243000L);
    m_assert((v_seed>=((t_integer) 0L)), fn_Random__Random, 63);
    tmp_1 = ((t_integer) 1L);
    for (;;) {
        m_rts();
        a_check((&(v__ofldp->f_inv_mod)), tmp_1, 0, fn_Random__Random, 65);
        a_check((&(v__ofldp->f_mod)), tmp_1, 0, fn_Random__Random, 65);
        tmp_2 = ((t_real) (*(&((t_integer *)(&(v__ofldp->f_mod))->a_data)[tmp_1])));
        m_divcheck(tmp_2, fn_Random__Random, 65);
        (*(&((t_real *)(&(v__ofldp->f_inv_mod))->a_data)[tmp_1])) = (((t_real) 1.0)/tmp_2);
        if (tmp_1 == ((t_integer) 3L)) break;
        tmp_1++;
    }
    a_check((&(v__ofldp->f_current)), ((t_integer) 1L), 0, fn_Random__Random, 68);
    a_check((&(v__ofldp->f_mod)), ((t_integer) 1L), 0, fn_Random__Random, 68);
    a_check((&(v__ofldp->f_term)), ((t_integer) 1L), 0, fn_Random__Random, 68);
    tmp_3 = (*(&((t_integer *)(&(v__ofldp->f_mod))->a_data)[((t_integer) 1L)]));
    m_modcheck(tmp_3, fn_Random__Random, 68);
    (*(&((t_integer *)(&(v__ofldp->f_current))->a_data)[((t_integer) 1L)])) = m_mod(((*(&((t_integer *)(&(v__ofldp->f_term))->a_data)[((t_integer) 1L)]))+v_seed),tmp_3);
    a_check((&(v__ofldp->f_current)), ((t_integer) 1L), 0, fn_Random__Random, 69);
    a_check((&(v__ofldp->f_mod)), ((t_integer) 1L), 0, fn_Random__Random, 69);
    a_check((&(v__ofldp->f_term)), ((t_integer) 1L), 0, fn_Random__Random, 69);
    a_check((&(v__ofldp->f_current)), ((t_integer) 1L), 0, fn_Random__Random, 69);
    a_check((&(v__ofldp->f_fac)), ((t_integer) 1L), 0, fn_Random__Random, 69);
    tmp_4 = (*(&((t_integer *)(&(v__ofldp->f_mod))->a_data)[((t_integer) 1L)]));
    m_modcheck(tmp_4, fn_Random__Random, 69);
    (*(&((t_integer *)(&(v__ofldp->f_current))->a_data)[((t_integer) 1L)])) = m_mod((((*(&((t_integer *)(&(v__ofldp->f_fac))->a_data)[((t_integer) 1L)]))*(*(&((t_integer *)(&(v__ofldp->f_current))->a_data)[((t_integer) 1L)])))+(*(&((t_integer *)(&(v__ofldp->f_term))->a_data)[((t_integer) 1L)]))),tmp_4);
    a_check((&(v__ofldp->f_current)), ((t_integer) 2L), 0, fn_Random__Random, 70);
    a_check((&(v__ofldp->f_mod)), ((t_integer) 2L), 0, fn_Random__Random, 70);
    a_check((&(v__ofldp->f_current)), ((t_integer) 1L), 0, fn_Random__Random, 70);
    tmp_5 = (*(&((t_integer *)(&(v__ofldp->f_mod))->a_data)[((t_integer) 2L)]));
    m_modcheck(tmp_5, fn_Random__Random, 70);
    (*(&((t_integer *)(&(v__ofldp->f_current))->a_data)[((t_integer) 2L)])) = m_mod((*(&((t_integer *)(&(v__ofldp->f_current))->a_data)[((t_integer) 1L)])),tmp_5);
    a_check((&(v__ofldp->f_current)), ((t_integer) 1L), 0, fn_Random__Random, 71);
    a_check((&(v__ofldp->f_mod)), ((t_integer) 1L), 0, fn_Random__Random, 71);
    a_check((&(v__ofldp->f_term)), ((t_integer) 1L), 0, fn_Random__Random, 71);
    a_check((&(v__ofldp->f_current)), ((t_integer) 1L), 0, fn_Random__Random, 71);
    a_check((&(v__ofldp->f_fac)), ((t_integer) 1L), 0, fn_Random__Random, 71);
    tmp_6 = (*(&((t_integer *)(&(v__ofldp->f_mod))->a_data)[((t_integer) 1L)]));
    m_modcheck(tmp_6, fn_Random__Random, 71);
    (*(&((t_integer *)(&(v__ofldp->f_current))->a_data)[((t_integer) 1L)])) = m_mod((((*(&((t_integer *)(&(v__ofldp->f_fac))->a_data)[((t_integer) 1L)]))*(*(&((t_integer *)(&(v__ofldp->f_current))->a_data)[((t_integer) 1L)])))+(*(&((t_integer *)(&(v__ofldp->f_term))->a_data)[((t_integer) 1L)]))),tmp_6);
    a_check((&(v__ofldp->f_current)), ((t_integer) 3L), 0, fn_Random__Random, 72);
    a_check((&(v__ofldp->f_mod)), ((t_integer) 3L), 0, fn_Random__Random, 72);
    a_check((&(v__ofldp->f_current)), ((t_integer) 1L), 0, fn_Random__Random, 72);
    tmp_7 = (*(&((t_integer *)(&(v__ofldp->f_mod))->a_data)[((t_integer) 3L)]));
    m_modcheck(tmp_7, fn_Random__Random, 72);
    (*(&((t_integer *)(&(v__ofldp->f_current))->a_data)[((t_integer) 3L)])) = m_mod((*(&((t_integer *)(&(v__ofldp->f_current))->a_data)[((t_integer) 1L)])),tmp_7);
    tmp_1 = ((t_integer) 1L);
    for (;;) {
        m_rts();
        a_check((&(v__ofldp->f_current)), ((t_integer) 1L), 0, fn_Random__Random, 75);
        a_check((&(v__ofldp->f_mod)), ((t_integer) 1L), 0, fn_Random__Random, 75);
        a_check((&(v__ofldp->f_term)), ((t_integer) 1L), 0, fn_Random__Random, 75);
        a_check((&(v__ofldp->f_current)), ((t_integer) 1L), 0, fn_Random__Random, 75);
        a_check((&(v__ofldp->f_fac)), ((t_integer) 1L), 0, fn_Random__Random, 75);
        tmp_8 = (*(&((t_integer *)(&(v__ofldp->f_mod))->a_data)[((t_integer) 1L)]));
        m_modcheck(tmp_8, fn_Random__Random, 75);
        (*(&((t_integer *)(&(v__ofldp->f_current))->a_data)[((t_integer) 1L)])) = m_mod((((*(&((t_integer *)(&(v__ofldp->f_fac))->a_data)[((t_integer) 1L)]))*(*(&((t_integer *)(&(v__ofldp->f_current))->a_data)[((t_integer) 1L)])))+(*(&((t_integer *)(&(v__ofldp->f_term))->a_data)[((t_integer) 1L)]))),tmp_8);
        a_check((&(v__ofldp->f_current)), ((t_integer) 2L), 0, fn_Random__Random, 76);
        a_check((&(v__ofldp->f_mod)), ((t_integer) 2L), 0, fn_Random__Random, 76);
        a_check((&(v__ofldp->f_term)), ((t_integer) 2L), 0, fn_Random__Random, 76);
        a_check((&(v__ofldp->f_current)), ((t_integer) 2L), 0, fn_Random__Random, 76);
        a_check((&(v__ofldp->f_fac)), ((t_integer) 2L), 0, fn_Random__Random, 76);
        tmp_9 = (*(&((t_integer *)(&(v__ofldp->f_mod))->a_data)[((t_integer) 2L)]));
        m_modcheck(tmp_9, fn_Random__Random, 76);
        (*(&((t_integer *)(&(v__ofldp->f_current))->a_data)[((t_integer) 2L)])) = m_mod((((*(&((t_integer *)(&(v__ofldp->f_fac))->a_data)[((t_integer) 2L)]))*(*(&((t_integer *)(&(v__ofldp->f_current))->a_data)[((t_integer) 2L)])))+(*(&((t_integer *)(&(v__ofldp->f_term))->a_data)[((t_integer) 2L)]))),tmp_9);
        a_check((&(v__ofldp->f_table)), tmp_1, 0, fn_Random__Random, 77);
        a_check((&(v__ofldp->f_inv_mod)), ((t_integer) 1L), 0, fn_Random__Random, 78);
        a_check((&(v__ofldp->f_inv_mod)), ((t_integer) 2L), 0, fn_Random__Random, 78);
        a_check((&(v__ofldp->f_current)), ((t_integer) 2L), 0, fn_Random__Random, 78);
        a_check((&(v__ofldp->f_current)), ((t_integer) 1L), 0, fn_Random__Random, 77);
        (*(&((t_real *)(&(v__ofldp->f_table))->a_data)[tmp_1])) = ((((t_real) (*(&((t_integer *)(&(v__ofldp->f_current))->a_data)[((t_integer) 1L)])))+(((t_real) (*(&((t_integer *)(&(v__ofldp->f_current))->a_data)[((t_integer) 2L)])))*(*(&((t_real *)(&(v__ofldp->f_inv_mod))->a_data)[((t_integer) 2L)]))))*(*(&((t_real *)(&(v__ofldp->f_inv_mod))->a_data)[((t_integer) 1L)])));
        if (tmp_1 == ((t_integer) 97L)) break;
        tmp_1++;
    }
}
void init_t_Random__Random(t_Random__Random *v__obj, char *obj_name) {
    int opflags = 0;
    int *op_flags = &opflags;
    void *argtab[1];
    t_Random__1 *v__ofldp;
    v__obj->o_fields = m_malloc(sizeof(t_Random__1));
    memset(v__obj->o_fields, 0, sizeof(t_Random__1));
    o_init_rtsdep(v__obj, &td_Random__Random, obj_name);
    v__ofldp = v__obj->o_fields;
    a_initialize(&(v__ofldp->f_term), "Random.term");
    a_initialize(&(v__ofldp->f_fac), "Random.fac");
    a_initialize(&(v__ofldp->f_mod), "Random.mod");
    batinit_Random__float_ar(&(v__ofldp->f_inv_mod), 1, ((t_integer) 1L), ((t_integer) 3L), "Random.inv_mod");
    batinit_Random__int_ar(&(v__ofldp->f_current), 1, ((t_integer) 1L), ((t_integer) 3L), "Random.current");
    batinit_Random__float_ar(&(v__ofldp->f_table), 1, ((t_integer) 1L), ((t_integer) 97L), "Random.table");
    ow_Random__init(v__obj, ((t_integer) 1L));
}
void (ini_Random__Random)(void) {
	static int done = 0;

	if (done) return;
	done = 1;
	td_registration(&td_Random__Random) = m_ptrregister((void *)&td_Random__Random);
	m_objdescr_reg(&td_Random__Random, 5, "Random");
}
