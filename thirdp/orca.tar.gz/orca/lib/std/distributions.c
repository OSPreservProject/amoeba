/* Produced by the Orca-to-C compiler */

/* Orca-to-C compiler, main branch, date: Tue Jun 30 16:56:47 MET DST 1998. */

#include <interface.h>
#include "distributions.h"
static tp_dscr *ar_distributions__CPUListType[] = {
	&td_integer
};
tp_dscr td_distributions__CPUListType = { ARRAY, sizeof(t_distributions__CPUListType), 5, &td_integer, 1, ar_distributions__CPUListType};
#ifdef PANDA4
int sz_distributions__CPUListType(t_distributions__CPUListType *a) {
    int sz = 0;
    if (a->a_sz <= 0) return 1;
    sz = 1;
    sz ++;
    return sz;
}

pan_iovec_p ma_distributions__CPUListType(pan_iovec_p p, t_distributions__CPUListType *a) {
    t_integer *s;
    p->data = (void *) a;
    p->len = sizeof(*a);
    p++;
    if (a->a_sz <= 0) return p;
    s = (t_integer *) a->a_data + a->a_offset;
    p->data = (void *)s;
    p->len = a->a_sz * sizeof(t_integer);
    p++;
    return p;
}

void um_distributions__CPUListType(void *p, t_distributions__CPUListType *a) {
    t_integer *s;
    pan_msg_consume(p, a, sizeof(*a));
    if (a->a_sz <= 0) { a->a_sz = 0; a->a_data = 0;  return; }
    s = (t_integer *) m_malloc(a->a_sz * sizeof(t_integer));
    a->a_data = s - a->a_offset;
    pan_msg_consume(p, s, a->a_sz * sizeof(t_integer));
}

#else
int sz_distributions__CPUListType(t_distributions__CPUListType *a) {
    int sz;
    sz = 2 * sizeof(a->a_dims[0].a_lwb);
    if (a->a_sz <= 0) return sz;
    sz += a->a_sz * sizeof(t_integer);
    return sz;
}

char *ma_distributions__CPUListType(char *p, t_distributions__CPUListType *a) {
    t_integer *s;
    put_tp(a->a_dims[0].a_lwb, p);
    put_tp(a->a_dims[0].a_nel, p);
    if (a->a_sz <= 0) return p;
    s = (t_integer *) a->a_data + a->a_offset;
    memcpy(p, s, a->a_sz * sizeof(t_integer));
    p += a->a_sz * sizeof(t_integer);
    return p;
}

char *um_distributions__CPUListType(char *p, t_distributions__CPUListType *a) {
    t_integer *s;
    a->a_offset = 0;
    get_tp(a->a_dims[0].a_lwb, p);
    get_tp(a->a_dims[0].a_nel, p);
    a->a_sz = a->a_dims[0].a_nel;
    a->a_offset = a->a_dims[0].a_lwb;
    if (a->a_sz <= 0) { a->a_sz = 0; a->a_data = 0;  return p; }
    s = (t_integer *) m_malloc(a->a_sz * sizeof(t_integer));
    a->a_data = s - a->a_offset;
    memcpy(s, p, a->a_sz * sizeof(t_integer));
    p += a->a_sz * sizeof(t_integer);
    return p;
}

#endif
int cmp_distributions__CPUListType(void *aa, void *bb) {
    t_distributions__CPUListType *a=aa; t_distributions__CPUListType *b=bb;
    size_t off;
    if (a == b) return 1;
    if (a->a_sz <= 0) return b->a_sz <= 0;
    if (a_lb(a, 0) != a_lb(b, 0)) return 0;
    if (a_ne(a, 0) != a_ne(b, 0)) return 0;
    off = a->a_offset * sizeof(t_integer);
    return memcmp((char *)(a->a_data) + off, (char *) (b->a_data) + off, sizeof(t_integer) * a->a_sz) == 0;
}
void free_distributions__CPUListType(void *d) {
    t_distributions__CPUListType *dst = d;
    if (dst->a_sz <= 0) return;
    m_free(((t_integer *) (dst->a_data)) + dst->a_offset);
    dst->a_sz = 0;
}
void ass_distributions__CPUListType(void *dd, void *ss) {
    t_distributions__CPUListType *dst = dd, *src = ss;
    size_t off = sizeof(t_integer) * src->a_offset;
    t_integer *p,*q = (void *)((char *)(src->a_data)+off);
    size_t sz = src->a_sz * sizeof(t_integer);

    if (dst == src) return;
    if (dst->a_sz != src->a_sz) {
	void *m;
	if (dst->a_sz > 0) free_distributions__CPUListType(dst);
	dst->a_sz = src->a_sz;
	dst->a_offset = src->a_offset;
	dst->a_dims[0] = src->a_dims[0];
	if (src->a_sz <= 0) return;
	m = m_malloc(sz);
	dst->a_data = (char *)m - off;
    } else {
	dst->a_dims[0] = src->a_dims[0];
	dst->a_data = (t_integer *)(dst->a_data) - (src->a_offset - dst->a_offset);
	dst->a_offset = src->a_offset;
    }
    if (src->a_sz <= 0) return;
    p = (void *)((char *)(dst->a_data) + off);
    memcpy(p, q, sz);
}
static tp_dscr *ar_distributions__DistributionType[] = {
	&td_integer
};
tp_dscr td_distributions__DistributionType = { ARRAY, sizeof(t_distributions__DistributionType), 5, &td_integer, 1, ar_distributions__DistributionType};
#ifdef PANDA4
int sz_distributions__DistributionType(t_distributions__DistributionType *a) {
    int sz = 0;
    if (a->a_sz <= 0) return 1;
    sz = 1;
    sz ++;
    return sz;
}

pan_iovec_p ma_distributions__DistributionType(pan_iovec_p p, t_distributions__DistributionType *a) {
    t_integer *s;
    p->data = (void *) a;
    p->len = sizeof(*a);
    p++;
    if (a->a_sz <= 0) return p;
    s = (t_integer *) a->a_data + a->a_offset;
    p->data = (void *)s;
    p->len = a->a_sz * sizeof(t_integer);
    p++;
    return p;
}

void um_distributions__DistributionType(void *p, t_distributions__DistributionType *a) {
    t_integer *s;
    pan_msg_consume(p, a, sizeof(*a));
    if (a->a_sz <= 0) { a->a_sz = 0; a->a_data = 0;  return; }
    s = (t_integer *) m_malloc(a->a_sz * sizeof(t_integer));
    a->a_data = s - a->a_offset;
    pan_msg_consume(p, s, a->a_sz * sizeof(t_integer));
}

#else
int sz_distributions__DistributionType(t_distributions__DistributionType *a) {
    int sz;
    sz = 2 * sizeof(a->a_dims[0].a_lwb);
    if (a->a_sz <= 0) return sz;
    sz += a->a_sz * sizeof(t_integer);
    return sz;
}

char *ma_distributions__DistributionType(char *p, t_distributions__DistributionType *a) {
    t_integer *s;
    put_tp(a->a_dims[0].a_lwb, p);
    put_tp(a->a_dims[0].a_nel, p);
    if (a->a_sz <= 0) return p;
    s = (t_integer *) a->a_data + a->a_offset;
    memcpy(p, s, a->a_sz * sizeof(t_integer));
    p += a->a_sz * sizeof(t_integer);
    return p;
}

char *um_distributions__DistributionType(char *p, t_distributions__DistributionType *a) {
    t_integer *s;
    a->a_offset = 0;
    get_tp(a->a_dims[0].a_lwb, p);
    get_tp(a->a_dims[0].a_nel, p);
    a->a_sz = a->a_dims[0].a_nel;
    a->a_offset = a->a_dims[0].a_lwb;
    if (a->a_sz <= 0) { a->a_sz = 0; a->a_data = 0;  return p; }
    s = (t_integer *) m_malloc(a->a_sz * sizeof(t_integer));
    a->a_data = s - a->a_offset;
    memcpy(s, p, a->a_sz * sizeof(t_integer));
    p += a->a_sz * sizeof(t_integer);
    return p;
}

#endif
int cmp_distributions__DistributionType(void *aa, void *bb) {
    t_distributions__DistributionType *a=aa; t_distributions__DistributionType *b=bb;
    size_t off;
    if (a == b) return 1;
    if (a->a_sz <= 0) return b->a_sz <= 0;
    if (a_lb(a, 0) != a_lb(b, 0)) return 0;
    if (a_ne(a, 0) != a_ne(b, 0)) return 0;
    off = a->a_offset * sizeof(t_integer);
    return memcmp((char *)(a->a_data) + off, (char *) (b->a_data) + off, sizeof(t_integer) * a->a_sz) == 0;
}
void free_distributions__DistributionType(void *d) {
    t_distributions__DistributionType *dst = d;
    if (dst->a_sz <= 0) return;
    m_free(((t_integer *) (dst->a_data)) + dst->a_offset);
    dst->a_sz = 0;
}
void ass_distributions__DistributionType(void *dd, void *ss) {
    t_distributions__DistributionType *dst = dd, *src = ss;
    size_t off = sizeof(t_integer) * src->a_offset;
    t_integer *p,*q = (void *)((char *)(src->a_data)+off);
    size_t sz = src->a_sz * sizeof(t_integer);

    if (dst == src) return;
    if (dst->a_sz != src->a_sz) {
	void *m;
	if (dst->a_sz > 0) free_distributions__DistributionType(dst);
	dst->a_sz = src->a_sz;
	dst->a_offset = src->a_offset;
	dst->a_dims[0] = src->a_dims[0];
	if (src->a_sz <= 0) return;
	m = m_malloc(sz);
	dst->a_data = (char *)m - off;
    } else {
	dst->a_dims[0] = src->a_dims[0];
	dst->a_data = (t_integer *)(dst->a_data) - (src->a_offset - dst->a_offset);
	dst->a_offset = src->a_offset;
    }
    if (src->a_sz <= 0) return;
    p = (void *)((char *)(dst->a_data) + off);
    memcpy(p, q, sz);
}
char *fn_distributions__distributions = "distributions.imp";
void f_distributions__block(t_integer v_npart, t_integer v_ncpus, t_distributions__DistributionType *v__result) {
    t_distributions__DistributionType v_rval;
    t_integer v_parts_per_cpu;
    t_integer v_parts_left;
    t_integer v_p;
    t_integer tmp_5;
    t_integer tmp_4;
    t_integer tmp_3;
    t_integer tmp_2;
    t_integer tmp_1;
    tmp_1 = (v_npart-((t_integer) 1L));
    batinit_distributions__DistributionType(&v_rval, 1, ((t_integer) 0L), tmp_1, "distributions.block.rval");
    m_rts();
    v_p = ((t_integer) 0L);
    m_divcheck(v_ncpus, fn_distributions__distributions, 9);
    v_parts_per_cpu = m_div(v_npart,v_ncpus);
    m_modcheck(v_ncpus, fn_distributions__distributions, 10);
    v_parts_left = m_mod(v_npart,v_ncpus);
    tmp_2 = (v_ncpus-((t_integer) 1L));
    tmp_3 = ((t_integer) 0L);
    if (tmp_3 <= tmp_2) {
        for (;;) {
            m_rts();
            tmp_4 = v_parts_per_cpu;
            tmp_5 = ((t_integer) 1L);
            if (tmp_5 <= tmp_4) {
                for (;;) {
                    m_rts();
                    a_check((&v_rval), v_p, 0, fn_distributions__distributions, 13);
                    (*(&((t_integer *)(&v_rval)->a_data)[v_p])) = tmp_3;
                    v_p += ((t_integer) 1L);
                    if (tmp_5 == tmp_4) break;
                    tmp_5++;
                }
            }
            if ((v_parts_left!=((t_integer) 0L))) {
                a_check((&v_rval), v_p, 0, fn_distributions__distributions, 17);
                (*(&((t_integer *)(&v_rval)->a_data)[v_p])) = tmp_3;
                v_p += ((t_integer) 1L);
                v_parts_left -= ((t_integer) 1L);
            }
            if (tmp_3 == tmp_2) break;
            tmp_3++;
        }
    }
    free_distributions__DistributionType((v__result));
    *v__result = v_rval;
    (void) memset((void *) &v_rval, 0, (size_t) sizeof(t_distributions__DistributionType));
    goto retlab;
    m_trap(FALL_THROUGH, fn_distributions__distributions, 41);
retlab:;
    free_distributions__DistributionType(&v_rval);
}
void f_distributions__cyclic(t_integer v_npart, t_integer v_ncpus, t_distributions__DistributionType *v__result) {
    t_distributions__DistributionType v_rval;
    t_integer v_p;
    t_integer tmp_3;
    t_integer tmp_2;
    t_integer tmp_1;
    tmp_1 = (v_npart-((t_integer) 1L));
    batinit_distributions__DistributionType(&v_rval, 1, ((t_integer) 0L), tmp_1, "distributions.cyclic.rval");
    m_rts();
    v_p = ((t_integer) 0L);
    tmp_2 = (v_npart-((t_integer) 1L));
    tmp_3 = ((t_integer) 0L);
    if (tmp_3 <= tmp_2) {
        for (;;) {
            m_rts();
            a_check((&v_rval), tmp_3, 0, fn_distributions__distributions, 31);
            (*(&((t_integer *)(&v_rval)->a_data)[tmp_3])) = v_p;
            v_p += ((t_integer) 1L);
            if ((v_p==v_ncpus)) {
                v_p = ((t_integer) 0L);
            }
            if (tmp_3 == tmp_2) break;
            tmp_3++;
        }
    }
    free_distributions__DistributionType((v__result));
    *v__result = v_rval;
    (void) memset((void *) &v_rval, 0, (size_t) sizeof(t_distributions__DistributionType));
    goto retlab;
    m_trap(FALL_THROUGH, fn_distributions__distributions, 41);
retlab:;
    free_distributions__DistributionType(&v_rval);
}
void (ini_distributions__distributions)(void) {
	static int done = 0;

	if (done) return;
	done = 1;
}
