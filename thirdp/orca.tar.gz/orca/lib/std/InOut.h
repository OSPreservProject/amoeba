/* Produced by the Orca-to-C compiler */

/* Orca-to-C compiler, main branch, date: Tue Jun 30 16:56:47 MET DST 1998. */

#ifndef InOut____SEEN
#define InOut____SEEN
extern tp_dscr td_InOut__BufferingKind;
typedef t_enum t_InOut__BufferingKind;
extern char *fn_InOut__InOut;
void f_InOut__WriteChar(t_char v_c);
void f_InOut__WriteInt(t_integer v_i);
void f_InOut__WriteLongInt(t_longint v_i);
void f_InOut__WriteShortInt(t_integer v_i);
void f_InOut__WriteReal(t_real v_r);
void f_InOut__WriteLongReal(t_longreal v_r);
void f_InOut__WriteLn(void);
void f_InOut__WriteString(t_string *v_str);
void f_InOut__ReadChar(t_char *ov_c);
void f_InOut__ReadInt(t_integer *ov_i);
void f_InOut__ReadLongInt(t_longint *ov_i);
void f_InOut__ReadShortInt(t_shortint *ov_i);
void f_InOut__ReadReal(t_real *ov_r);
void f_InOut__ReadLongReal(t_longreal *ov_r);
void f_InOut__ReadShortReal(t_shortreal *ov_r);
void f_InOut__ReadString(t_string *ov_s);
t_char f_InOut__Ahead(void);
t_boolean f_InOut__Eof(void);
t_boolean f_InOut__Eoln(void);
t_boolean f_InOut__OpenInputFile(t_string *v_f);
t_boolean f_InOut__OpenOutputFile(t_string *v_f);
t_boolean f_InOut__AppendOutputFile(t_string *v_f);
void f_InOut__CloseInput(void);
void f_InOut__CloseOutput(void);
void f_InOut__SetBuffering(t_InOut__BufferingKind v_kind);
void f_InOut__Flush(void);
void ini_InOut__InOut(void);
#endif
