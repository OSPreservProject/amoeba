/* Produced by the Orca-to-C compiler */

/* Orca-to-C compiler, main branch, date: Tue Jun 30 16:56:47 MET DST 1998. */

#ifndef Random____SEEN
#define Random____SEEN
extern tp_dscr td_Random__Random;
typedef t_object t_Random__Random;
extern tp_dscr td_Random__val;
typedef t_integer t_Random__val;
extern tp_dscr td_Random__val01;
typedef t_integer t_Random__val01;
extern tp_dscr td_Random__init;
typedef t_integer t_Random__init;
extern int sz_Random__Random(t_Random__Random *);
#ifdef PANDA4
extern pan_iovec_p ma_Random__Random(pan_iovec_p , t_Random__Random *);
void um_Random__Random(void *, t_Random__Random *);
#else
extern char *ma_Random__Random(char *, t_Random__Random *);
extern char *um_Random__Random(char *, t_Random__Random *);
#endif
void free_Random__Random(void *);
void ass_Random__Random(void *a, void *b);
extern char *fn_Random__Random;
t_integer ow_Random__val(t_Random__Random *v__obj);
t_real ow_Random__val01(t_Random__Random *v__obj);
void ow_Random__init(t_Random__Random *v__obj, t_integer v_seed);
void init_t_Random__Random(t_Random__Random *v__obj, char *obj_name);
void ini_Random__Random(void);
#endif
