#!/bin/sh
#
# Create a hierarchy of directories
#
# Usage: ammkdirhier binary-directory directories ...
#
abin=$1
shift

#
# Default soap mask for directories
#
SPMASK=0xFF:2:4
export SPMASK

#
# All the references to /profile... are changed in /super...
#
for f in $*; do
    parts=`echo $f | sed 's,\(.\)/\(.\),\1 \2,g' | sed 's,/$,,'`;
    path="";
    for p in $parts; do
	if [ x"$path" = x ]; then
	    if [ x$p = x/profile ]; then
		dir=/super
	    else
		dir=$p;
	    fi
	else
	    dir=$path/$p;
	fi;
	if $abin/std_info $dir >/dev/null 2>&1; then
	    : nothing
	else
	    echo + mkd $dir; 
	    $abin/mkd $dir;
	fi
	path=$dir;
    done;
done

