/* $XFree86: xc/programs/Xserver/hw/xfree86/accel/et4000w32/w32/w32blt.h,v 3.1 1994/09/19 13:42:33 dawes Exp $ */
/*******************************************************************************
                        Copyright 1994 by Glenn G. Lai

                        All Rights Reserved

Permission to use, copy, modify, and distribute this software and its
documentation for any purpose and without fee is hereby granted,
provided that the above copyr notice appear in all copies and that
both that copyr notice and this permission notice appear in
supporting documentation, and that the name of Glenn G. Lai not be
used in advertising or publicity pertaining to distribution of the
software without specific, written prior permission.

Glenn G. Lai DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE, INCLUDING
ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL
DIGITAL BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OR
ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS,
WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION,
ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
SOFTWARE.

Glenn G. Lai
P.O. Box 4314
Austin, Tx 78765
glenn@cs.utexas.edu)
4/6/94
*******************************************************************************/
#ifndef W32BLT_H
#define W32BLT_H

#include "w32.h"


/* initizliae a bitblt operation */
#define W32_INIT_BLT(OP, MASK, SRC_OFFSET, DST_OFFSET, XDIR, YDIR) \
{ \
    int i; \
\
    *ACL_SOURCE_WRAP	= 0x77; \
    if (MASK == 0xffffffff) \
    { \
	*ACL_FOREGROUND_RASTER_OPERATION	= W32OpTable[OP]; \
    } \
    else \
    { /* w32p only */ \
	*ACL_FOREGROUND_RASTER_OPERATION	= \
	    (0xf0 & W32OpTable[OP]) | 0x0a; \
	*ACL_PATTERN_WRAP			= 0x02; \
	*ACL_PATTERN_Y_OFFSET			= 0x3; \
	*MBP0 					= W32Pattern; \
	*(LongP)W32Buffer 			= MASK; \
    } \
    i = 0; \
    if (XDIR == -1) \
    { \
	i |= 0x1; \
    } \
    if (YDIR == -1) \
    { \
	i |= 0x2; \
    } \
    *ACL_XY_DIRECTION			= i; \
    *ACL_DESTINATION_Y_OFFSET		= DST_OFFSET; \
    *ACL_SOURCE_Y_OFFSET		= SRC_OFFSET; \
    *ACL_ROUTING_CONTROL 		= 0x0; \
}


#define W32_BLT(SRC, DST, X, Y) \
if (((X) | (Y) != 0)) \
{ \
    SET_XY(X, Y) \
    *(ACL_SOURCE_ADDRESS) = SRC; \
    START_ACL(DST) \
}


#endif /* W32BLT_H */
