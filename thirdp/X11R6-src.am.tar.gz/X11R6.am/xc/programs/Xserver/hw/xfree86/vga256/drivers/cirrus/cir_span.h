/* $XFree86: xc/programs/Xserver/hw/xfree86/vga256/drivers/cirrus/cir_span.h,v 3.0 1994/08/20 07:36:37 dawes Exp $ */

/*
 * Definitions for span functions in cir_span.s
 */

extern void CirrusColorExpandWriteSpans();
extern void CirrusColorExpandWriteStippleSpans();
extern void CirrusLatchWriteSpans();
